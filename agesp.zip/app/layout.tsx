import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { applySiteConfig } from "@/lib/site/theme";
import "./globals.css";

const inter = Inter({ subsets: ["latin"] });

// TODO(AGENTE-3/4): el sitio debe construir `metadata` + variables CSS
// desde `site_config` (branding editable, SEO dinámico — SDD §5 M1/M6).
export const metadata: Metadata = {
  title: "AGESP",
  description: "Plataforma web AGESP — Mipyme Estatal Socialista",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  // TODO(AGENTE-3): reemplazar por llamada real al adaptador (lib/db) y
  // aplicar los colores del branding en la etiqueta <html estilo>:
  // applySiteConfig(config) devuelve el atributo style con las variables CSS.
  return (
    <html lang="es" suppressHydrationWarning>
      <body className={inter.className}>{children}</body>
    </html>
  );
}
