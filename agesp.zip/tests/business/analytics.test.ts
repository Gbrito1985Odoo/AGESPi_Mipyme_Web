/** Tests de analytics (M4): media/mediana, distribución de opciones, series. */
import {
  calcularAnalytics,
  serieTemporal,
} from "../../lib/business/analytics";
import { crearRepositorioMock } from "./repositorioMock";
import { ErrorValidacion } from "../../lib/business/errores";

const SURVEY = "11111111-1111-1111-1111-111111111111";
const P_NUM = "22222222-2222-2222-2222-222222222222";
const P_SEL = "33333333-3333-3333-3333-333333333333";
const P_MLTI = "44444444-4444-4444-4444-444444444444";

function repositorioConEncuesta() {
  const repo = crearRepositorioMock();

  repo.sembrar("surveys", [
    { id: SURVEY, titulo: "Demo", activa: true, publicada: true, creado_en: "2026-01-01T00:00:00Z" },
  ]);
  repo.sembrar("questions", [
    {
      id: P_NUM,
      survey_id: SURVEY,
      posicion: 1,
      seccion: "general",
      tipo: "numerica" as const,
      texto: "¿Cuántos guardias necesita?",
      obligatoria: false,
      metadata: {},
    },
    {
      id: P_SEL,
      survey_id: SURVEY,
      posicion: 2,
      seccion: "general",
      tipo: "seleccion" as const,
      texto: "Tipo de entidad",
      obligatoria: false,
      metadata: {},
    },
    {
      id: P_MLTI,
      survey_id: SURVEY,
      posicion: 3,
      seccion: "general",
      tipo: "seleccion_multiple" as const,
      texto: "Medios disponibles",
      obligatoria: false,
      metadata: {},
    },
  ]);
  repo.sembrar("question_options", [
    { id: "opt-1", question_id: P_SEL, valor: "mipyme_estatal", etiqueta: "Mipyme estatal", orden: 1 },
    { id: "opt-2", question_id: P_SEL, valor: "mipyme_privada", etiqueta: "Mipyme privada", orden: 2 },
    { id: "opt-3", question_id: P_MLTI, valor: "camaras", etiqueta: "Cámaras", orden: 1 },
    { id: "opt-4", question_id: P_MLTI, valor: "alarmas", etiqueta: "Alarmas", orden: 2 },
  ]);
  repo.sembrar("responses", [
    {
      id: "r1",
      survey_id: SURVEY,
      customer_id: null,
      datos: { [P_NUM]: 4, [P_SEL]: "mipyme_estatal", [P_MLTI]: ["camaras", "alarmas"] } as Record<string, unknown>,
      consent_log: { aceptado: true, fecha: "2026-01-05T10:00:00Z" },
      creado_en: "2026-01-05T10:00:00Z",
    },
    {
      id: "r2",
      survey_id: SURVEY,
      customer_id: null,
      datos: { [P_NUM]: 6, [P_SEL]: "mipyme_estatal", [P_MLTI]: [] } as Record<string, unknown>,
      consent_log: { aceptado: true, fecha: "2026-01-07T11:00:00Z" },
      creado_en: "2026-01-07T11:00:00Z",
    },
    {
      id: "r3",
      survey_id: SURVEY,
      customer_id: null,
      datos: { [P_NUM]: 2, [P_SEL]: "mipyme_privada", [P_MLTI]: ["camaras"] } as Record<string, unknown>,
      consent_log: { aceptado: true, fecha: "2026-01-12T12:00:00Z" },
      creado_en: "2026-01-12T12:00:00Z",
    },
  ];
  return repo;
}

describe("analytics — agregados M4", () => {
  it("calcula media, mediana y extremos para pregunta numérica", async () => {
    const repo = repositorioConEncuesta();
    const r = await calcularAnalytics(repo, { survey_id: SURVEY });
    const num = r.por_pregunta.find((p) => p.pregunta_id === P_NUM);
    if (!num || num.tipo !== "numerica") return fail("Se esperaba agregado numérico");
    // valores 4, 6, 2 → media 4, mediana 4
    expect(num.media).toBe(4);
    expect(num.mediana).toBe(4);
    expect(num.min).toBe(2);
    expect(num.max).toBe(6);
    expect(r.total_respuestas).toBe(3);
  });

  it("calcula distribución con etiquetas para seleccion", async () => {
    const repo = repositorioConEncuesta();
    const r = await calcularAnalytics(repo, { survey_id: SURVEY });
    const sel = r.por_pregunta.find((p) => p.pregunta_id === P_SEL);
    if (!sel || sel.tipo !== "seleccion") return fail("Se esperaba agregado de selección");
    expect(sel.distribucion["mipyme_estatal"]).toMatchObject({ etiqueta: "Mipyme estatal", conteo: 2 });
    expect(sel.distribucion["mipyme_privada"]).toMatchObject({ etiqueta: "Mipyme privada", conteo: 1 });
  });

  it("cuenta sin_respuesta para seleccion_multiple vacía", async () => {
    const repo = repositorioConEncuesta();
    const r = await calcularAnalytics(repo, { survey_id: SURVEY });
    const mlti = r.por_pregunta.find((p) => p.pregunta_id === P_MLTI);
    if (!mlti || mlti.tipo !== "seleccion_multiple") return fail("Se esperaba agregado múltiple");
    expect(mlti.distribucion["camaras"]).toMatchObject({ conteo: 2 });
    expect(mlti.distribucion["alarmas"]).toMatchObject({ conteo: 1 });
    expect(mlti.sinRespuesta).toBe(1); // r2 respondió [] sin medios: no abandono, sin_eleccion
  });

  it("respeta filtros de fecha (desde)", async () => {
    const repo = repositorioConEncuesta();
    const r = await calcularAnalytics(repo, {
      survey_id: SURVEY,
      desde: "2026-01-07T00:00:00Z",
    });
    expect(r.total_respuestas).toBe(2);
  });

  it("filtra por pregunta concreta (pregunta_id)", async () => {
    const repo = repositorioConEncuesta();
    const r = await calcularAnalytics(repo, {
      survey_id: SURVEY,
      pregunta_id: P_MLTI,
    });
    expect(r.por_pregunta).toHaveLength(1);
    expect(r.por_pregunta[0].pregunta_id).toBe(P_MLTI);
  });

  it("rechaza filtros inválidos con detalle en español", async () => {
    const repo = repositorioConEncuesta();
    await expect(calcularAnalytics(repo, { survey_id: "mal-uuid" })).rejects.toThrow(
      ErrorValidacion
    );
  });

  it("serie temporal cuenta por día ISO", () => {
    const serie = serieTemporal([
      { creado_en: "2026-01-05T10:00:00Z" },
      { creado_en: "2026-01-05T18:00:00Z" },
      { creado_en: "2026-01-12T09:00:00Z" },
    ]);
    expect(serie).toEqual([
      { fecha: "2026-01-05", respuestas: 2 },
      { fecha: "2026-01-12", respuestas: 1 },
    ]);
  });
});

function fail(msg: string): never {
  throw new Error(msg);
}
