/**
 * Repositorio en memoria para tests de /lib/business (brief AGENTE-2 §5):
 * sin red ni PostgreSQL. Implementa la interfaz `Repositorio` como lo hacen
 * lib/db/localClient y lib/db/supabaseClient en producción.
 */
import {
  type Repositorio,
  type FiltrosSeleccionar,
} from "../../lib/business/repositorio";

export interface RepositorioMockOpciones {
  /** Secuencia de respuestaSequencia de insertar() para probar fallos puntuales. */
  fallosInsertar?: string[]; // nombres de tabla que fallarán en el próximo insert
}

export function crearRepositorioMock(): Repositorio & { /* inspection hooks */ } {
  const tablas: Record<string, Record<string, unknown>[]> = {};
  const fallosInsertar = new Set<string>();

  function eqMatches(fila: Record<string, unknown>, eq: Record<string, unknown>): boolean {
    return Object.entries(eq).every(([k, v]) => fila[k] === v);
  }

  const repo: Repositorio = {
    target: "mock",
    async seleccionar<T>(tabla: string, opts?: FiltrosSeleccionar): Promise<T[]> {
      const filas = tablas[tabla] ?? [];
      let out = filas.slice();
      if (opts?.eq) out = out.filter((f) => eqMatches(f, opts.eq!));
      if (opts?.ordenarPor) {
        const { columna, asc = true } = opts.ordenarPor;
        out.sort((a, b) => {
          const av = (a as Record<string, unknown>)[columna];
          const bv = (b as Record<string, unknown>)[columna];
          const cmp =
            typeof av === "number" && typeof bv === "number"
              ? av - bv
              : String(av ?? "").localeCompare(String(bv ?? ""));
          return asc ? cmp : -cmp;
        });
      }
      if (opts?.limite !== undefined) out = out.slice(0, opts.limite);
      return out as T[];
    },
    async insertar<T>(tabla: string, fila: Record<string, unknown>): Promise<T> {
      if (fallosInsertar.has(tabla)) {
        fallosInsertar.delete(tabla);
        throw new Error(`Error simulado al insertar en ${tabla}`);
      }
      const completa: Record<string, unknown> = {
        id: `id-${tabla}-${Math.floor(Math.random() * 1e9).toString()}`,
        ...fila,
      };
      (tablas[tabla] ??= []).push(completa);
      return completa as T;
    },
    async actualizar<T>(
      tabla: string,
      valores: Record<string, unknown>,
      eq: Record<string, unknown>
    ): Promise<T[]> {
      const filas = tablas[tabla] ?? [];
      const afectadas = filas.filter((f) => eqMatches(f, eq));
      for (const f of afectadas) Object.assign(f, valores);
      return afectadas as T[];
    },
    async transaccion<T>(fn: (trx: Repositorio) => Promise<T>): Promise<T> {
      // En memoria la transacción es simplemente la referencia al mismo repo.
      return fn(repo);
    },
  };

  /** Utilidades de inspección para los tests. */
  const extras = {
    /** Filas actuales de una tabla (copia). */
    filas(tabla: string): Record<string, unknown>[] {
      return (tablas[tabla] ?? []).slice();
    },
    /** Programa un fallo en el próximo insert en la tabla dada. */
    falloProximoInsert(tabla: string): void {
      fallosInsertar.add(tabla);
    },
    contar(tabla: string): number {
      return (tablas[tabla] ?? []).length;
    },
    /** Siembra filas iniciales en una tabla (para arreglo del test). */
    sembrar(tabla: string, filas: Record<string, unknown>[]): void {
      tablas[tabla] ??= [];
      tablas[tabla].push(...filas);
    },
  };

  return Object.assign(repo, extras);
}

/** Datos base reutilizados en varios tests. */
export function productoDemo(sobre: Partial<Record<string, unknown>> = {}): Record<string, unknown> {
  return {
    id: sobre.id ?? "prod-1",
    codigo: "PRD-001",
    nombre: "Guardia de seguridad mensual",
    precio: 1500,
    moneda: "CUP",
    unidad: "mes",
    disponible: true,
    tiempo_entrega: "5 días hábiles",
    destacado: false,
    stock: 10,
    stock_minimo: 3,
    ...sobre,
  };
}

export function pedidoDemo(sobre: Partial<Record<string, unknown>> = {}): Record<string, unknown> {
  return {
    id: sobre.id ?? "pedido-1",
    customer_id: null,
    moneda: "CUP",
    estado: "pendiente",
    total: 3000,
    ...sobre,
  };
}
