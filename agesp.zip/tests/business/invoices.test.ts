/** Tests de facturación (M5): numeración secuencial, guardas de estado, UNIQUE. */
import { emitirFactura, listarFacturas } from "../../lib/business/invoices";
import { crearRepositorioMock, pedidoDemo } from "./repositorioMock";
import { ErrorNegocio, ErrorValidacion } from "../../lib/business/errores";

const PEDIDO = "22222222-2222-2222-2222-222222222222";
const USUARIO = "33333333-3333-3333-3333-333333333333";

function repoFase1ConPedido(): any {
  const repo = crearRepositorioMock();
  repo.sembrar("orders", [pedidoDemo({ id: PEDIDO, estado: "pagado", total: 3000, moneda: "CUP" })]);
  return repo;
}

describe("invoices — facturación M5", () => {
  it("número secuencial: primera factura serie A número 1", async () => {
    const repo = repoFase1ConPedido();

    const f1 = await emitirFactura(repo, {
      pedido_id: PEDIDO,
      serie: "A",
      datos_fiscales: { nombre: "Entidad X" },
      usuario_id: USUARIO,
    });
    expect(f1.factura.serie).toBe("A");
    expect(f1.factura.numero).toBe(1);
    expect(f1.factura.datos_fiscales).toMatchObject({ nombre: "Entidad X" });
  });

  it("aumenta el consecutivo al emitir por segunda vez (misma serie)", async () => {
    const repo = repoFase1ConPedido();
    // Primera emisión manual en el repo (simula la existente).
    repo.sembrar("invoices", [
      {
        id: "fact-0",
        pedido_id: "99999999-9999-9999-9999-999999999999",
        serie: "A",
        numero: 7,
        customer_id: null,
        moneda: "CUP",
        total: 100,
        datos_fiscales: {},
        creado_en: "2026-01-01T00:00:00Z",
      },
    ]);
    const f = await emitirFactura(repo, { pedido_id: PEDIDO, serie: "A" });
    expect(f.factura.numero).toBe(8);
  });

  it("no factura por duplicado el mismo pedido", async () => {
    const repo = repoFase1ConPedido();
    await emitirFactura(repo, { pedido_id: PEDIDO, serie: "A" });
    await expect(emitirFactura(repo, { pedido_id: PEDIDO, serie: "A" })).rejects.toThrow(
      /ya tiene factura/
    );
  });

  it("solo factura pedidos pagados o entregados", async () => {
    const repo = crearRepositorioMock();
    repo.sembrar("orders", [pedidoDemo({ id: PEDIDO, estado: "pendiente" })]);
    await expect(emitirFactura(repo, { pedido_id: PEDIDO, serie: "A" })).rejects.toThrow(
      /pagado o entregado/
    );
  });

  it("entrada inválida lanza ErrorValidacion", async () => {
    const repo = repoFase1ConPedido();
    await expect(emitirFactura(repo, { pedido_id: "no-uuid" })).rejects.toThrow(ErrorValidacion);
  });

  it("listarFacturas filtra por serie y pedido", async () => {
    const repo = repoFase1ConPedido();
    repo.sembrar("invoices", [
      {
        id: "fact-1",
        pedido_id: PEDIDO,
        serie: "A",
        numero: 1,
        moneda: "CUP",
        total: 3000,
        datos_fiscales: {},
        creado_en: "2026-01-02T00:00:00Z",
      },
      {
        id: "fact-2",
        pedido_id: "44444444-4444-4444-4444-444444444444",
        serie: "B",
        numero: 1,
        moneda: "USD",
        total: 10,
        datos_fiscales: {},
        creado_en: "2026-01-03T00:00:00Z",
      },
    ]);
    const serieA = await listarFacturas(repo, { serie: "A" });
    expect(serieA).toHaveLength(1);
    const delPedido = await listarFacturas(repo, { pedido_id: PEDIDO });
    expect(delPedido[0].id).toBe("fact-1");
  });
});
