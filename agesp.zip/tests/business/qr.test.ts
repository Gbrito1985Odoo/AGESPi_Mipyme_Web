/** Tests del QR de tarjetas (M3): URL, PNG data-URL y SVG (paquete qrcode real). */
import { generarQRTarjeta, urlTarjeta } from "../../lib/business/qr";
import { ErrorValidacion } from "../../lib/business/errores";

const BASE = "https://agesp.example.cu";
const UUID = "123e4567-e89b-12d3-a456-426614174000";

describe("qr — tarjetas M3", () => {
  it("construye la URL de la tarjeta sin barra final duplicada", () => {
    expect(urlTarjeta(BASE, UUID)).toBe(`${BASE}/card/${UUID}`);
    expect(urlTarjeta(`${BASE}/`, UUID)).toBe(`${BASE}/card/${UUID}`);
  });

  it("genera PNG data-URL y SVG con corrección alta", async () => {
    const r = await generarQRTarjeta({ base_url: BASE, uuid: UUID });
    expect(r.url).toContain(`/card/${UUID}`);
    expect(r.png_data_url.startsWith("data:image/png;base64,")).toBe(true);
    expect(r.svg.startsWith("<?xml")).toBe(true);
    // Ancho de data-URL razonable para una tarjeta (no vacío/degenerado)
    expect(r.png_data_url.length).toBeGreaterThan(500);
  });

  it("rechaza base_url no válida o uuid malformado (Zod → ErrorValidacion)", async () => {
    await expect(generarQRTarjeta({ base_url: "no-es-url", uuid: UUID })).rejects.toThrow(
      ErrorValidacion
    );
    await expect(generarQRTarjeta({ base_url: BASE, uuid: "mal-uuid" })).rejects.toThrow(
      ErrorValidacion
    );
  });
});
