/** Tests de pedidos (M2/M5): alta desde carrito, máquina de estados, stock. */
import {
  crearPedidoDesdeCarrito,
  cambiarEstadoPedido,
  obtenerPedido,
} from "../../lib/business/orders";
import { CARRITO_VACIO, agregarItem } from "../../lib/business/cart";
import { crearRepositorioMock, productoDemo, pedidoDemo } from "./repositorioMock";
import { ErrorNegocio, ErrorValidacion } from "../../lib/business/errores";

const PID = "11111111-1111-1111-1111-111111111111";

const carritoConProducto = () => crearRepositorioMock();

describe("orders — pedidos M2/M5", () => {
  it("crea pedido pendiente a partir del carrito con snapshot de precio", async () => {
    const repo = crearRepositorioMock();
    let carrito = CARRITO_VACIO;
    carrito = agregarItem(carrito, {
      producto_id: PID,
      nombre: "Guardia",
      precio: 1500,
      moneda: "CUP",
      cantidad: 2,
    });
    const r = await crearPedidoDesdeCarrito(repo, carrito, { customer_id: null });
    expect(r.pedido.estado).toBe("pendiente");
    expect(r.pedido.total).toBe(3000);
    expect(r.items).toHaveLength(1);
    expect(r.items[0]).toMatchObject({
      nombre_snapshot: "Guardia",
      precio_snapshot: 1500,
      cantidad: 2,
      moneda: "CUP",
    });

    const pedidosEnRepo = (repo as any).filas("orders") as Record<string, unknown>[];
    expect(pedidosEnRepo).toHaveLength(1);
  });

  it("rechaza crear pedido con carrito inválido (vacío)", async () => {
    const repo = crearRepositorioMock();
    await expect(crearPedidoDesdeCarrito(repo, CARRITO_VACIO)).rejects.toThrow(ErrorNegocio);
  });

  it("valida la entrada con Zod → ErrorValidacion", async () => {
    const repo = crearRepositorioMock();
    await expect(
      crearPedidoDesdeCarrito(repo, CARRITO_VACIO, { customer_id: "no-uuid" })
    ).rejects.toThrow(ErrorValidacion);
  });

  it("confirmar un pedido descuenta stock y genera alerta si cae bajo mínimo", async () => {
    const repo = carritoConProducto();
    // pedido + producto + order_item tal como quedarían tras crear el pedido.
    await (repo as any).insertar("orders", pedidoDemo({ estado: "pendiente", total: 21000 }));
    await (repo as any).insertar("products", productoDemo({ stock: 5, stock_minimo: 3 }));
    await (repo as any).insertar("order_items", {
      pedido_id: "pedido-1",
      producto_id: "prod-1",
      nombre_snapshot: "Guardia",
      precio_snapshot: 7000,
      moneda: "CUP",
      cantidad: 3,
    });

    const { pedido, alertas } = await cambiarEstadoPedido(repo, "pedido-1", "confirmado");
    expect(pedido.estado).toBe("confirmado");

    const productos = (repo as any).filas("products") as Record<string, unknown>[];
    expect(productos[0].stock).toBe(2); // 5 - 3
    expect(alertas).toHaveLength(1); // 2 < stock_minimo (3)
  });

  it("rechaza confirmar si el stock es insuficiente", async () => {
    const repo = carritoConProducto();
    await (repo as any).insertar("orders", pedidoDemo({ estado: "pendiente" }));
    await (repo as any).insertar("products", productoDemo({ stock: 1 }));
    await (repo as any).insertar("order_items", {
      pedido_id: "pedido-1",
      producto_id: "prod-1",
      nombre_snapshot: "Guardia",
      precio_snapshot: 1500,
      moneda: "CUP",
      cantidad: 2,
    });
    await expect(cambiarEstadoPedido(repo, "pedido-1", "confirmado")).rejects.toThrow(
      /Stock insuficiente/
    );
  });

  it("cancelar un confirmado devuelve el stock", async () => {
    const repo = carritoConProducto();
    await (repo as any).insertar("orders", pedidoDemo({ estado: "confirmado" }));
    await (repo as any).insertar("products", productoDemo({ stock: 2 }));
    await (repo as any).insertar("order_items", {
      pedido_id: "pedido-1",
      producto_id: "prod-1",
      nombre_snapshot: "Guardia",
      precio_snapshot: 1500,
      moneda: "CUP",
      cantidad: 3,
    });
    const { pedido } = await cambiarEstadoPedido(repo, "pedido-1", "cancelado");
    expect(pedido.estado).toBe("cancelado");
    const productos = (repo as any).filas("products") as Record<string, unknown>[];
    expect(productos[0].stock).toBe(5); // 2 + 3 devuelto
  });

  it("prohíbe transiciones inválidas (pendiente → entregado) con mensaje claro", async () => {
    const repo = carritoConProducto();
    await (repo as any).insertar("orders", pedidoDemo({ estado: "pendiente" }));
    await expect(
      cambiarEstadoPedido(repo, "pedido-1", "entregado")
    ).rejects.toThrow(/Transición de estado no permitida/);
  });

  it("estado final (entregado) es inmutable", async () => {
    const repo = carritoConProducto();
    await (repo as any).insertar("orders", pedidoDemo({ estado: "entregado" }));
    await expect(
      cambiarEstadoPedido(repo, "pedido-1", "cancelado")
    ).rejects.toThrow(/estado final, inmutable|Transición/);
  });

  it("obtenerPedido lanza ErrorNoEncontrado con id", async () => {
    const repo = carritoConProducto();
    await expect(obtenerPedido(repo, "pedido-404")).rejects.toThrow(/no encontrado/);
  });
});
