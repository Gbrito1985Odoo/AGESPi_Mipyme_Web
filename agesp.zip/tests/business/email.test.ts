/** Tests de correo (M3/M5): render con sanitización de HTML y log de errores. */
import {
  renderizarPlantilla,
  renderizarAsunto,
  escaparHtml,
  enviarCorreo,
} from "../../lib/business/email";
import { crearRepositorioMock } from "./repositorioMock";
import type { RegistroCorreo } from "../../lib/types";

describe("email — render de plantillas", () => {
  it("sustituye variables {{clave}} y escapa HTML de los valores (§7)", () => {
    expect(
      renderizarPlantilla("Hola {{nombre}}, su tarjeta: {{url_tarjeta}}", {
        nombre: "Ana<script>",
        url_tarjeta: "https://x/card/1",
      })
    ).toBe("Hola Ana&lt;script&gt;, su tarjeta: https://x/card/1");
  });

  it("deja intactas las claves sin valor (no silencia descuidos)", () => {
    expect(renderizarPlantilla("Hola {{nombre}} y {{desconocida}}", { nombre: "Ana" })).toBe(
      "Hola Ana y {{desconocida}}"
    );
  });

  it("escapa caracteres críticos de intención XSS", () => {
    expect(escaparHtml('<img src=x onerror="1">')).toBe(
      "&lt;img src=x onerror=&quot;1&quot;&gt;"
    );
  });

  it("el asunto se sustituye sin escape (es texto plano)", () => {
    expect(renderizarAsunto("Factura {{pedido_id}} lista", { pedido_id: "abc" })).toBe(
      "Factura abc lista"
    );
  });
});

describe("email — envío y log (sin red)", () => {
  const plantilla = {
    id: "tpl-1",
    clave: "bienvenida_qr",
    asunto: "Bienvenida {{nombre}}",
    html: "<p>Hola {{nombre}}, tarjeta: {{url_tarjeta}}</p>",
    variables: ["{{nombre}}", "{{url_tarjeta}}"],
    actualizado_en: "2026-01-01T00:00:00Z",
  };

  beforeEach(() => {
    delete process.env.RESEND_API_KEY;
    delete process.env.RESEND_FROM;
  });

  function repositorioConPlantilla() {
    const repo = crearRepositorioMock();
    repo.sembrar("email_templates", [plantilla as unknown as Record<string, unknown>]);
    return repo;
  }

  it("sin RESEND_API_KEY registra estado 'error' en email_log sin crashear", async () => {
    const repo = repositorioConPlantilla();
    const log = await enviarCorreo(repo, {
      plantilla: "bienvenida_qr",
      destinatario: "ana@cliente.cu",
      variables: { nombre: "Ana", url_tarjeta: "https://x/card/1" },
    });
    const registro = log as unknown as RegistroCorreo;
    expect(registro.estado).toBe("error");
    expect(registro.detalle_error).toContain("RESEND_API_KEY");
    expect(repo.contar("email_log")).toBe(1);
  });

  it("plantilla inexistente también se registra como error", async () => {
    const repo = crearRepositorioMock();
    const log = (await enviarCorreo(repo, {
      plantilla: "no_existe",
      destinatario: "ana@cliente.cu",
      variables: {},
    })) as unknown as RegistroCorreo;
    expect(log.estado).toBe("error");
    expect(log.detalle_error).toContain("no_existe");
  });

  it("entrada inválida (correo malformado) lanza ErrorValidacion", async () => {
    const repo = repositorioConPlantilla();
    await expect(
      enviarCorreo(repo, {
        plantilla: "bienvenida_qr",
        destinatario: "no-es-correo",
        variables: {},
      })
    ).rejects.toThrow(/correo/);
  });
});
