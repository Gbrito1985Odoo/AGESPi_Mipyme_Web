/** Tests de la lógica de saltos (§8.2): casos de referencia P6/P9. */
import {
  valoresEquivalentes,
  estaVisible,
  preguntasVisibles,
  aplicarReglasSaltosAGESP,
  siguientePregunta,
  obligatoriasPendientes,
} from "../../lib/business/surveyLogic";
import type { Pregunta } from "../../lib/types";

function pregunta(p: Partial<Pregunta> & { id: string }): Pregunta {
  return {
    survey_id: "11111111-1111-1111-1111-111111111111",
    posicion: 1,
    seccion: "general",
    tipo: "si_no",
    texto: `Texto de ${p.id}`,
    obligatoria: false,
    metadata: {},
    ...p,
  } as Pregunta;
}

describe("surveyLogic — saltos §8.2", () => {
  const P5 = pregunta({ id: "P5", posicion: 1, texto: "¿Cuenta con personal de seguridad?" });
  const P6 = pregunta({
    id: "P6",
    posicion: 2,
    texto: "¿Cuántos fiscales?",
    metadata: { show_if: { pregunta_id: "P5", valor: "si" } },
  });
  const P9 = pregunta({ id: "P9", posicion: 3, texto: "¿Medios técnicos?" });

  it("valoresEquivalentes normaliza 'si'/'no' y booleanos", () => {
    expect(valoresEquivalentes(true, "si")).toBe(true);
    expect(valoresEquivalentes("SI", "si")).toBe(true);
    expect(valoresEquivalentes(false, "no")).toBe(true);
    expect(valoresEquivalentes("no", "si")).toBe(false);
    expect(valoresEquivalentes(["a", "b"], ["a"])).toBe(true); // contiene todos los esperados
    expect(valoresEquivalentes(null, null)).toBe(true);
  });

  it("P6 se oculta si P5 = 'no' y se muestra si P5 = 'si'", () => {
    expect(estaVisible(P6, {})).toBe(false); // sin responder P5: show_if no se cumple
    expect(estaVisible(P6, { P5: "no" })).toBe(false);
    expect(estaVisible(P6, { P5: true })).toBe(true); // booleano 'si'
  });

  it("P9 sin show_if es siempre visible", () => {
    expect(estaVisible(P9, {})).toBe(true);
    expect(estaVisible(P9, { P5: "no" })).toBe(true);
  });

  it("preguntasVisibles respeta el orden de posición y el salto", () => {
    const visibles = preguntasVisibles([P6, P5, P9], { P5: "si" });
    expect(visibles.map((p) => p.id)).toEqual(["P5", "P6", "P9"]);
    const sinPersonal = preguntasVisibles([P6, P5, P9], { P5: "no" });
    expect(sinPersonal.map((p) => p.id)).toEqual(["P5", "P9"]);
  });

  it("siguientePregunta devuelve la primera visible sin responder", () => {
    expect(siguientePregunta([P5, P6, P9], { P5: "si", P6: 3 })).toMatchObject({ id: "P9" });
    expect(siguientePregunta([P5, P6, P9], { P5: "no" })).toMatchObject({ id: "P9" });
    expect(siguientePregunta([P5, P6, P9], { P5: "si", P6: 2, P9: 1 })).toBeNull();
  });

  it("obligatoriasPendientes solo mira preguntas visibles", () => {
    const oblig = pregunta({ id: "P6b", posicion: 2, obligatoria: true, metadata: { show_if: { pregunta_id: "P5", valor: "si" } } });
    expect(obligatoriasPendientes([P5, oblig], { P5: "no" })).toEqual([]);
    expect(obligatoriasPendientes([P5, oblig], { P5: "si" })).toEqual([oblig.texto]);
  });

  it("aplicarReglasSaltosAGESP replica P6/P9 inclusive sin metadata del seed", () => {
    const sinMetadata = [
      pregunta({ id: "P5", texto: "¿Personal?" }),
      pregunta({ id: "P6", texto: "¿Fiscales?" }),
      pregunta({ id: "P9", texto: "¿Medios?" }),
    ];
    const sal = aplicarReglasSaltosAGESP(sinMetadata, { P5: "no" });
    expect(sal.map((p) => p.id)).toEqual(["P5", "P9"]); // P6 oculto sin personal
    expect(sal.find((p) => p.id === "P9")?.metadata?.mostrar_igualmente).toBe(true); // P9 forzado
  });
});
