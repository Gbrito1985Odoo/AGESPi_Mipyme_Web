/** Tests del carrito (M2): totales, moneda única, cantidades. */
import {
  agregarItem,
  actualizarCantidad,
  quitarItem,
  calcularTotal,
  validarCarrito,
  carritoAPedido,
  CARRITO_VACIO,
} from "../../lib/business/cart";
import { ErrorNegocio } from "../../lib/business/errores";

describe("cart — carrito M2", () => {
  it("agrega un ítem y calcula su total de línea", () => {
    const c = agregarItem(CARRITO_VACIO, {
      producto_id: "11111111-1111-1111-1111-111111111111",
      nombre: "Guardia",
      precio: 1500,
      moneda: "CUP",
      cantidad: 2,
    });
    expect(c.items[0].total).toBe(3000);
    expect(c.moneda).toBe("CUP");
    expect(calcularTotal(c)).toBe(3000);
  });

  it("acumula cantidad del mismo producto", () => {
    let c = agregarItem(CARRITO_VACIO, {
      producto_id: "11111111-1111-1111-1111-111111111111",
      nombre: "Guardia",
      precio: 1500,
      moneda: "CUP",
      cantidad: 1,
    });
    c = agregarItem(c, {
      producto_id: "11111111-1111-1111-1111-111111111111",
      nombre: "Guardia",
      precio: 1500,
      moneda: "CUP",
      cantidad: 2,
    });
    expect(c.items).toHaveLength(1);
    expect(c.items[0].cantidad).toBe(3);
    expect(calcularTotal(c)).toBe(4500);
  });

  it("rechaza mezclar monedas por pedido (regla M2)", () => {
    const c = agregarItem(CARRITO_VACIO, {
      producto_id: "11111111-1111-1111-1111-111111111111",
      nombre: "Guardia",
      precio: 1500,
      moneda: "CUP",
      cantidad: 1,
    });
    expect(() =>
      agregarItem(c, {
        producto_id: "22222222-2222-2222-2222-222222222222",
        nombre: "Auditoría",
        precio: 9800,
        moneda: "MLC",
        cantidad: 1,
      })
    ).toThrow(ErrorNegocio);
  });

  it("actualiza cantidad y quita con 0", () => {
    const pid = "11111111-1111-1111-1111-111111111111";
    let c = agregarItem(CARRITO_VACIO, {
      producto_id: pid,
      nombre: "Guardia",
      precio: 1500,
      moneda: "CUP",
      cantidad: 2,
    });
    c = actualizarCantidad(c, pid, 1);
    expect(c.items[0].cantidad).toBe(1);
    c = actualizarCantidad(c, pid, 0);
    expect(c.items).toHaveLength(0);
    expect(c.moneda).toBeNull(); // carrito vacío vuelve a moneda null
  });

  it("validación y conversión a pedido detectan problemas en español", () => {
    expect(validarCarrito(CARRITO_VACIO)).toContain("El carrito está vacío");

    const c = agregarItem(CARRITO_VACIO, {
      producto_id: "11111111-1111-1111-1111-111111111111",
      nombre: "Guardia",
      precio: 1500.555,
      moneda: "CUP",
      cantidad: 2,
    });
    const pedido = carritoAPedido(c);
    // Redondeo monetario a 2 decimales (cart.redondearMonto)
    expect(pedido.total).toBeCloseTo(3001.11, 2);
    expect(pedido.moneda).toBe("CUP");
    expect(pedido.items[0]).toMatchObject({ nombre: "Guardia", precio: 1500.555 });
  });
});
