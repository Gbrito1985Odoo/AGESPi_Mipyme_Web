import type { Config } from "tailwindcss";

/**
 * Paleta «diplomática» por defecto de AGESP.
 * REGLA DURA (SDD §2): los valores aquí son el FALLBACK por defecto.
 * En runtime los colores reales se leen de `site_config` y se inyectan
 * como variables CSS desde el layout raíz. No hardcodear los hex en los
 * componentes: usar siempre las clases basadas en tokens (primary, accent…).
 */
const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: "rgb(var(--color-primary) / <alpha-value>)", // Azul diplomático #0B2E59
        accent: "rgb(var(--color-accent) / <alpha-value>)", // Amarillo #F4C430
        secondary: "rgb(var(--color-secondary) / <alpha-value>)", // Gris diplomático #4A5568
        muted: "rgb(var(--color-muted) / <alpha-value>)", // Gris claro #E2E8F0
        surface: "rgb(var(--color-surface) / <alpha-value>)", // Blanco #FFFFFF
      },
      fontFamily: {
        sans: ["Inter", "ui-sans-serif", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
