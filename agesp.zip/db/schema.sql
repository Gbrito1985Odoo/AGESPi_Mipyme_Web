-- ============================================================================
-- AGESP — db/schema.sql — SNAPSHOT del esquema (decisión D10 del SDD §9/D)
-- ⚠️  ARCHIVO GENERADO — NO EDITAR A MANO.
--     Fuente de verdad: db/migrations/*.sql + db/rls/*.sql.
--     Para regenerar: aplicar migraciones y políticas, luego volcar el DDL
--     (equivalente a `pg_dump --schema-only` tras `npm run db:local:init`).
--     Este snapshot existe para revisión humana y para proyectos nuevos sin
--     sistema de migraciones (SDD: migraciones = fuente de verdad, snapshot =
--     solo lectura).
-- Contenido: DDL de 18 tablas + funciones puente/rol + RLS + triggers.
-- Fase 1 · AGENTE-1. Idioma: español (D9).
-- ============================================================================
-- ============================================================================
-- AGESP — Migración 000_init.sql
-- Fuente de verdad del esquema (decisión D10 del SDD §9/D).
-- Fase 1 · AGENTE-1 (Fundación DB). Idioma: español (D9).
--
-- Reglas del SDD aplicadas aquí:
--   §4.1  Esquema canónico portable: Supabase (auth.users) / PostgreSQL local.
--   §7    RLS en todas las tablas → se definen en db/rls/*.sql (guard dual).
--   D7    audit_log append-only (trigger + sin UPDATE/DELETE).
--   D11   Idempotencia defensiva: IF NOT EXISTS / CREATE OR REPLACE / DO $$ guard.
--
-- Ejecución recomendada (en orden):
--   1) db/migrations/*.sql  (este archivo primero)
--   2) db/rls/*.sql         (funciones puente + políticas por target)
--   3) db/seed.sql          (datos demo)
--   → `npm run db:local:init` (scripts/db-local-init.cjs) hace este orden.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 0) Extensiones y funciones puente de identidad (SDD §4.1)
-- ----------------------------------------------------------------------------

-- Cifrado en reposo para customers.tax_id (§7, pgcrypto).
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ----------------------------------------------------------------------
-- Puente de identidad local: current_user_id()
-- El cliente local (lib/db/localClient.ts) hace `SET LOCAL app.user_id`
-- (set_config('app.user_id', $1, true)) dentro de la transacción.
-- En Supabase no se usa: el guard dual deriva a auth.uid().
-- ----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.current_user_id() RETURNS uuid
LANGUAGE plpgsql STABLE AS $fn$
DECLARE
  v text;
BEGIN
  v := current_setting('app.user_id', true);
  IF v IS NULL OR v = '' THEN
    RETURN NULL;
  END IF;
  RETURN v::uuid;
EXCEPTION WHEN OTHERS THEN
  RETURN NULL; -- valor no-uuid o entorno sin GUC: tratar como anónimo
END;
$fn$;

-- ----------------------------------------------------------------------
-- usuario_actual(): router dual de identidad.
--   - En Supabase (detectado por la tabla real auth.users) → auth.uid().
--   - Local → current_user_id() (GUC app.user_id).
-- Todas las políticas RLS (db/rls/*.sql) pasan por aquí para no duplicar lógica.
-- ----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.usuario_actual() RETURNS uuid
LANGUAGE plpgsql STABLE AS $fn$
BEGIN
  IF to_regclass('auth.users') IS NOT NULL THEN
    RETURN auth.uid();
  END IF;
  RETURN public.current_user_id();
EXCEPTION WHEN OTHERS THEN
  RETURN NULL;
END;
$fn$;

-- ----------------------------------------------------------------------
-- Mock del esquema auth para portabilidad local (brief AGENTE-1 §1).
-- Solo se crea si NO existe el esquema real de Supabase; nunca toca el
-- auth authenticator de Supabase (guard DO $$ ... END $$, D11).
-- En local, auth.uid() devuelve el mismo valor que current_user_id().
-- ----------------------------------------------------------------------
DO $do$
BEGIN
  IF to_regclass('auth.users') IS NULL THEN
    IF NOT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = 'auth') THEN
      CREATE SCHEMA auth;
    END IF;
    IF NOT EXISTS (
      SELECT 1
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname = 'auth' AND p.proname = 'uid'
    ) THEN
      CREATE FUNCTION auth.uid() RETURNS uuid
      LANGUAGE sql STABLE AS $fn$ SELECT public.current_user_id() $fn$;
    END IF;
  END IF;
END;
$do$;

-- Wrapper de políticas (brief §3): TRUE si el uuid dado coincide con el
-- usuario autenticado en el target actual (Supabase o local).
CREATE OR REPLACE FUNCTION public.is_auth(u uuid) RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT u IS NOT NULL AND u = public.usuario_actual() $fn$;

-- ----------------------------------------------------------------------------
-- Helpers de cifrado de tax_id (carné/NIT) con pgcrypto (§7, brief §1)
-- La clave se lee de la variable de sesión 'app.tax_key'. Si no está definida
-- se usa una-clave-por-defecto SOLO para desarrollo (documentado en
-- docs/DB/README-DB.md). En producción se fija con: SET app.tax_key = '…';
-- o por transacción: SELECT set_config('app.tax_key', $1, true);
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.encrypt_tax_id(texto text) RETURNS bytea
LANGUAGE sql STABLE AS $fn$
  SELECT pgp_sym_encrypt(
    texto,
    coalesce(current_setting('app.tax_key', true),
             'AGESP-clave-fiscales-DESARROLLO-cambiar-en-produccion')
  )
$fn$;

CREATE OR REPLACE FUNCTION public.decrypt_tax_id(dato bytea) RETURNS text
LANGUAGE sql STABLE AS $fn$
  SELECT pgp_sym_decrypt(
    dato,
    coalesce(current_setting('app.tax_key', true),
             'AGESP-clave-fiscales-DESARROLLO-cambiar-en-produccion')
  )
$fn$;

-- ----------------------------------------------------------------------------
-- 1) Tablas (18, SDD §4.2). Nombres de columna = nombres de campo de
--    lib/types/index.ts (snake_case en ambos lados; mapeo completo en db/schema.md).
-- ----------------------------------------------------------------------------

-- ----------------------------------------------------------------------------
-- 1.1) M1/M2 — Catálogo
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS categories (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre      text NOT NULL,
  slug        text NOT NULL UNIQUE,
  descripcion text,
  orden       integer,
  creado_en   timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE categories IS 'Categorías del catálogo (M2). Trazabilidad: §5 M2.';

CREATE TABLE IF NOT EXISTS products (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  codigo         text NOT NULL UNIQUE,          -- «ID» visible del catálogo (M2 / Art. 5 Res. 35/2020)
  nombre         text NOT NULL,
  descripcion    text,
  imagen_url     text,                          -- Supabase Storage
  precio         numeric(12,2) NOT NULL DEFAULT 0 CHECK (precio >= 0),
  moneda         text NOT NULL DEFAULT 'CUP' CHECK (moneda IN ('CUP','MLC','USD')),
  unidad         text NOT NULL DEFAULT 'unidad',-- unidad de venta: unidad/kg/mes/servicio…
  disponible     boolean NOT NULL DEFAULT true,
  tiempo_entrega text NOT NULL DEFAULT '',      -- obligatorio declarar (Art. 5 Res. 35/2020)
  destacado      boolean NOT NULL DEFAULT false,
  categoria_id   uuid REFERENCES categories(id) ON DELETE SET NULL,
  stock          integer NOT NULL DEFAULT 0 CHECK (stock >= 0),      -- M5 inventario
  stock_minimo   integer NOT NULL DEFAULT 0 CHECK (stock_minimo >= 0), -- alertas bajo inventario (M5)
  creado_en      timestamptz NOT NULL DEFAULT now(),
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE products IS 'Productos/servicios de la vitrina y tienda (M1/M2). Trazabilidad: §5 M1, M2, M5 (stock/art. 5 Res. 35/2020).';

CREATE INDEX IF NOT EXISTS idx_products_categoria ON products(categoria_id);
CREATE INDEX IF NOT EXISTS idx_products_destacado ON products(destacado) WHERE destacado;
CREATE INDEX IF NOT EXISTS idx_products_disponible ON products(disponible);

-- ----------------------------------------------------------------------------
-- 1.2) M3 — Directorio de clientes (tarjetas QR, cifrado tax_id)
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS customers (
  id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  -- UUID público para la tarjeta: https://{dominio}/card/{uuid} (M3)
  uuid                    uuid NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  usuario_id              uuid,                 -- dueño de la fila (para RLS de rol customer); extra fuera del contrato TS
  nombre                  text NOT NULL,
  tipo_entidad            text NOT NULL DEFAULT 'persona'
                          CHECK (tipo_entidad IN ('mipyme_estatal','mipyme_privada','persona','otro')),
  tax_id_cifrado          bytea NOT NULL,       -- carné/NIT cifrado con pgcrypto (encrypt_tax_id)
  domicilio               text,
  codigo_postal           text,
  telefono                text,
  correo                  text,
  credencial              text,
  consentimiento_aceptado boolean NOT NULL DEFAULT false, -- consentimiento explícito (§7, Ley 149)
  creado_en               timestamptz NOT NULL DEFAULT now(),
  actualizado_en          timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE customers IS 'Directorio de clientes (M3). tax_id cifrado en reposo (pgcrypto). FK opcional profiles(id)→auth.users solo en Supabase (ver README-DB).';

CREATE INDEX IF NOT EXISTS idx_customers_usuario ON customers(usuario_id);
CREATE INDEX IF NOT EXISTS idx_customers_tipo_entidad ON customers(tipo_entidad);

-- ----------------------------------------------------------------------------
-- 1.3) M2/M5 — Pedidos y facturación
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS orders (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id    uuid REFERENCES customers(id) ON DELETE SET NULL,
  moneda         text NOT NULL DEFAULT 'CUP' CHECK (moneda IN ('CUP','MLC','USD')),
  estado         text NOT NULL DEFAULT 'pendiente'
                 CHECK (estado IN ('pendiente','confirmado','pagado','entregado','cancelado')),
  total          numeric(12,2) NOT NULL DEFAULT 0 CHECK (total >= 0),
  creado_en      timestamptz NOT NULL DEFAULT now(),
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);

CREATE TABLE IF NOT EXISTS order_items (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id       uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  producto_id     uuid REFERENCES products(id) ON DELETE SET NULL,
  nombre_snapshot text NOT NULL,                -- snapshot histórico del pedido (M5)
  precio_snapshot numeric(12,2) NOT NULL CHECK (precio_snapshot >= 0),
  moneda          text NOT NULL DEFAULT 'CUP' CHECK (moneda IN ('CUP','MLC','USD')),
  cantidad        integer NOT NULL DEFAULT 1 CHECK (cantidad > 0)
);

CREATE INDEX IF NOT EXISTS idx_order_items_pedido ON order_items(pedido_id);

CREATE TABLE IF NOT EXISTS invoices (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id      uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  serie          text NOT NULL DEFAULT 'A',     -- numeración secuencial (M5)
  numero         integer NOT NULL CHECK (numero > 0),
  customer_id    uuid REFERENCES customers(id) ON DELETE SET NULL,
  moneda         text NOT NULL DEFAULT 'CUP' CHECK (moneda IN ('CUP','MLC','USD')),
  total          numeric(12,2) NOT NULL DEFAULT 0 CHECK (total >= 0),
  datos_fiscales jsonb NOT NULL DEFAULT '{}'::jsonb,  -- datos fiscales del PDF (M5)
  pdf_url        text,
  creado_en      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (serie, numero)
);

CREATE INDEX IF NOT EXISTS idx_invoices_pedido ON invoices(pedido_id);

-- ----------------------------------------------------------------------------
-- 1.4) M4 — Encuestas dinámicas
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS surveys (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo      text NOT NULL,
  descripcion text,
  activa      boolean NOT NULL DEFAULT false,
  publicada   boolean NOT NULL DEFAULT false,
  creado_en   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS questions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  survey_id   uuid NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  posicion    integer NOT NULL DEFAULT 1,
  seccion     text NOT NULL DEFAULT 'general',  -- agrupación visual (§8.1)
  tipo        text NOT NULL CHECK (tipo IN
              ('texto','seleccion','seleccion_multiple','likert','escala','fecha','numerica','si_no')),
  texto       text NOT NULL,
  ayuda       text,                             -- términos explicados (§8.2)
  obligatoria boolean NOT NULL DEFAULT false,
  metadata    jsonb DEFAULT '{}'::jsonb         -- lógica de salto: {"show_if":{"pregunta_id","valor"}}
);

CREATE INDEX IF NOT EXISTS idx_questions_survey ON questions(survey_id, posicion);

CREATE TABLE IF NOT EXISTS question_options (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  valor       text NOT NULL,
  etiqueta    text NOT NULL,
  orden       integer NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_question_options_question ON question_options(question_id, orden);

CREATE TABLE IF NOT EXISTS responses (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  survey_id   uuid NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  datos       jsonb NOT NULL DEFAULT '{}'::jsonb,
  consent_log jsonb,                            -- log de consentimiento §7
  creado_en   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_responses_survey ON responses(survey_id);
CREATE INDEX IF NOT EXISTS idx_responses_customer ON responses(customer_id);

CREATE TABLE IF NOT EXISTS survey_assignments (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  survey_id   uuid NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  token       uuid NOT NULL UNIQUE DEFAULT gen_random_uuid(), -- enlace público cuando no hay login
  estado      text NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','completada')),
  creado_en   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_survey_assignments_survey ON survey_assignments(survey_id);

-- ----------------------------------------------------------------------------
-- 1.5) M5 — CRM
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS leads (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre         text NOT NULL,
  correo         text,
  telefono       text,
  pipeline       text NOT NULL DEFAULT 'nuevo'
                 CHECK (pipeline IN ('nuevo','contactado','propuesta','negociacion','ganado','perdido')),
  origen         text,
  notas          text,
  creado_en      timestamptz NOT NULL DEFAULT now(),
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_leads_pipeline ON leads(pipeline);

CREATE TABLE IF NOT EXISTS interactions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entidad_tipo text NOT NULL CHECK (entidad_tipo IN ('lead','customer')),
  entidad_id  uuid NOT NULL,                    -- polimórfica: leads.id o customers.id
  canal       text NOT NULL CHECK (canal IN ('web','correo','telefono','presencial')),
  resumen     text NOT NULL,
  creado_por  uuid REFERENCES profiles(id) ON DELETE SET NULL, -- nota: profiles se crea en 1.6
  creado_en   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_interactions_entidad ON interactions(entidad_tipo, entidad_id);

-- ----------------------------------------------------------------------------
-- 1.6) M6 — Admin, configuración, correo y auditoría
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS profiles (
  id             uuid PRIMARY KEY,              -- = auth.users.id en Supabase (FK condicional abajo)
  correo         text NOT NULL UNIQUE,
  nombre         text,
  rol            text NOT NULL DEFAULT 'customer'
                 CHECK (rol IN ('super_admin','admin','editor','customer')),  -- M6 roles (RLS)
  mfa_habilitado boolean NOT NULL DEFAULT false, -- MFA TOTP super_admin (M6, D3)
  creado_en      timestamptz NOT NULL DEFAULT now()
);

-- FK profiles.id → auth.users(id) SOLO en Supabase (la tabla real auth.users existe ahí;
-- en local el mock no crea esa tabla y este bloque queda inerte — guard dual, D11).
DO $do$
BEGIN
  IF to_regclass('auth.users') IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint WHERE conname = 'fk_profiles_auth_users'
    ) THEN
      ALTER TABLE profiles
        ADD CONSTRAINT fk_profiles_auth_users
        FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;
    END IF;
  END IF;
END;
$do$;

CREATE TABLE IF NOT EXISTS site_config (
  clave          text PRIMARY KEY,              -- "colors.primary", "texto.hero_titulo"…
  valor          jsonb NOT NULL,
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE site_config IS 'Configuración editable en runtime: paleta diplomática, textos del hero, SEO (M1/M6). Regla dura: no hardcodear colores (§2).';

CREATE TABLE IF NOT EXISTS email_templates (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clave          text NOT NULL UNIQUE,          -- p. ej. "bienvenida_qr"
  asunto         text NOT NULL,
  html           text NOT NULL,
  variables      text[] NOT NULL DEFAULT '{}',  -- {{nombre}}, {{url_tarjeta}}…
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_log (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  destinatario   text NOT NULL,
  plantilla_clave text,
  asunto         text NOT NULL,
  estado         text NOT NULL CHECK (estado IN ('enviado','error')),
  detalle_error  text,
  creado_en      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_email_log_creado ON email_log(creado_en);

CREATE TABLE IF NOT EXISTS audit_log (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid REFERENCES profiles(id) ON DELETE SET NULL,
  accion     text NOT NULL,                     -- "login", "cambio_precio", "export"…
  entidad    text,
  entidad_id text,
  detalle    jsonb,
  creado_en  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_log_creado ON audit_log(creado_en);
CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id);

COMMENT ON TABLE audit_log IS 'AUDIT LOG APPEND-ONLY (D7). UPDATE/DELETE prohibidos por trigger. La única excepción documentada es que un superusuario real de PostgreSQL (rol con BYPASSRLS, p. ej. postgres) puede saltarse el trigger; la aplicación nunca expone esa vía. Ver docs/DB/README-DB.md.';

-- ----------------------------------------------------------------------------
-- 2) Funciones de rol para RLS (M6). DEFINER para que las políticas no
--    causen recursión con la propia RLS de profiles.
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.rol_actual() RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $fn$
  SELECT p.rol FROM public.profiles p WHERE p.id = public.usuario_actual() LIMIT 1
$fn$;

CREATE OR REPLACE FUNCTION public.es_staff() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() IN ('super_admin','admin','editor') $fn$;

CREATE OR REPLACE FUNCTION public.es_admin() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() IN ('super_admin','admin') $fn$;

CREATE OR REPLACE FUNCTION public.es_super() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() = 'super_admin' $fn$;

-- ----------------------------------------------------------------------------
-- 3) Triggers utilitarios
-- ----------------------------------------------------------------------------

-- actualizado_en automático en tablas con esa columna
CREATE OR REPLACE FUNCTION public.mantener_actualizado_en() RETURNS trigger
LANGUAGE plpgsql AS $fn$
BEGIN
  NEW.actualizado_en := now();
  RETURN NEW;
END;
$fn$;

DO $do$
DECLARE
  t text;
BEGIN
  -- lista literal de tablas con actualizado_en (idempotente)
  FOREACH t IN ARRAY ARRAY['customers','products','orders','leads','site_config','email_templates']
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_actualizado_en ON %I', t);
    EXECUTE format(
      'CREATE TRIGGER trg_actualizado_en BEFORE UPDATE ON %I
       FOR EACH ROW EXECUTE FUNCTION public.mantener_actualizado_en()', t);
  END LOOP;
END;
$do$;

-- ----------------------------------------------------------------------------
-- 4) audit_log APPEND-ONLY (D7): trigger que rechaza UPDATE/DELETE.
--    Sectores/proveedores: ver supuesto de excepción documentado en
--    docs/DB/README-DB.md (única vía: superusuario de PostgreSQL con BYPASSRLS).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.audit_log_append_only() RETURNS trigger
LANGUAGE plpgsql AS $fn$
BEGIN
  -- Excepción única y documentada (D7): un superusuario real de PostgreSQL
  -- podría desactivar el trigger manualmente, pero la aplicación jamás lo hace.
  RAISE EXCEPTION 'audit_log es append-only (D7): las operaciones UPDATE/DELETE están prohibidas.';
END;
$fn$;

DROP TRIGGER IF EXISTS trg_audit_log_append_only ON audit_log;
CREATE TRIGGER trg_audit_log_append_only
  BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION public.audit_log_append_only();

-- ----------------------------------------------------------------------------
-- Fin de 000_init.sql — continúa: db/rls/*.sql (RLS) → db/seed.sql (datos demo)
-- ----------------------------------------------------------------------------

-- ============================================================================
-- AGESP — db/rls/00_funciones_puente.sql
-- Funciones puente de identidad + habilitación de RLS en TODAS las tablas (§7).
--
-- Guard dual (SDD §4.1, brief AGENTE-1 §3):
--   - Supabase: auth.uid() (tabla real auth.users presente).
--   - Local:    current_user_id() leyendo current_setting('app.user_id', true)
--               (el cliente local hace SET LOCAL app.user_id).
-- La migración 000_init.sql ya crea estas funciones; aquí se redefinen con
-- CREATE OR REPLACE como idempotencia defensiva (D11) para que este paquete
-- RLS también funcione aplicado aislado.
-- ============================================================================

-- Puente local ---------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.current_user_id() RETURNS uuid
LANGUAGE plpgsql STABLE AS $fn$
DECLARE v text;
BEGIN
  v := current_setting('app.user_id', true);
  IF v IS NULL OR v = '' THEN RETURN NULL; END IF;
  RETURN v::uuid;
EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;
$fn$;

-- Router dual ----------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.usuario_actual() RETURNS uuid
LANGUAGE plpgsql STABLE AS $fn$
BEGIN
  IF to_regclass('auth.users') IS NOT NULL THEN RETURN auth.uid(); END IF;
  RETURN public.current_user_id();
EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;
$fn$;

-- Wrapper para políticas (brief §3) -------------------------------------------
CREATE OR REPLACE FUNCTION public.is_auth(u uuid) RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT u IS NOT NULL AND u = public.usuario_actual() $fn$;

-- Roles (M6) -----------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.rol_actual() RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $fn$
  SELECT p.rol FROM public.profiles p WHERE p.id = public.usuario_actual() LIMIT 1
$fn$;

CREATE OR REPLACE FUNCTION public.es_staff() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() IN ('super_admin','admin','editor') $fn$;

CREATE OR REPLACE FUNCTION public.es_admin() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() IN ('super_admin','admin') $fn$;

CREATE OR REPLACE FUNCTION public.es_super() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() = 'super_admin' $fn$;

-- ----------------------------------------------------------------------------
-- Habilitar RLS en las 18 tablas (idempotente en cualquier target)
-- ----------------------------------------------------------------------------
ALTER TABLE IF EXISTS profiles            ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS customers           ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS products            ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS categories          ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS orders              ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS order_items         ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS surveys             ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS questions           ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS question_options    ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS responses           ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS leads               ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS interactions        ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS invoices            ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS audit_log           ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS site_config         ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_templates     ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_log             ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS survey_assignments  ENABLE ROW LEVEL SECURITY;

-- ============================================================================
-- AGESP — db/rls/01_politicas.sql
-- Políticas RLS para TODAS las tablas (SDD §7, brief AGENTE-1 §3).
--
-- Roles (M6): super_admin > admin > editor > customer. Funciones de rol ya
-- creadas en 000_init.sql / 00_funciones_puente.sql:
--   usuario_actual(), is_auth(u), rol_actual(), es_staff(), es_admin(), es_super()
--
-- Paridad dual (sustituida por el SDD §4.1):
--   - Supabase → usuario_actual() = auth.uid().
--   - Local    → usuario_actual() = current_user_id() (GUC app.user_id, que
--                lib/db/localClient.ts fija con SET LOCAL app.user_id).
--
-- Idioma: español (D9). Idempotencia defensiva: DROP POLICY IF EXISTS +
-- guard DO $$ ... END $$ por tabla (D11). Las políticas se crean sin cláusula
-- TO (aplica a PUBLIC en local y a anon/authenticated en Supabase): el control
-- real se hace en USING/WITH CHECK por identidad y rol.
--
-- Nota de supervisión (D7): audit_log NO tiene políticas de UPDATE/DELETE:
-- la fila es inmutable para la aplicación. La excepción única documentada es
-- un superusuario real de PostgreSQL (BYPASSRLS); nunca una vía de la app.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- profiles (M6): cada usuario ve y edita su fila; super_admin gestiona todas.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_profiles_select ON profiles;
DROP POLICY IF EXISTS pol_profiles_insert ON profiles;
DROP POLICY IF EXISTS pol_profiles_update ON profiles;

CREATE POLICY pol_profiles_select ON profiles
  FOR SELECT USING (public.is_auth(id) OR public.es_admin());

CREATE POLICY pol_profiles_insert ON profiles
  FOR INSERT WITH CHECK (
    public.is_auth(id)
    -- Un usuario nuevo solo puede crear SU perfil con rol customer;
    -- la elevación de rol es exclusiva del super_admin.
    AND (rol = 'customer' OR public.es_super())
  );

CREATE POLICY pol_profiles_update ON profiles
  FOR UPDATE USING (public.is_auth(id) OR public.es_super())
  WITH CHECK (public.is_auth(id) OR public.es_super());

-- Defensa en profundidad: un usuario autenticado nunca puede auto-elevar su
-- rol por UPDATE propio (la capa app nunca lo necesita; M6/D3).
CREATE OR REPLACE FUNCTION public.profiles_bloqueo_autoelevacion() RETURNS trigger
LANGUAGE plpgsql AS $fn$
BEGIN
  IF public.usuario_actual() IS NOT NULL
     AND OLD.id = public.usuario_actual()
     AND NEW.rol IS DISTINCT FROM OLD.rol
     AND public.rol_actual() <> 'super_admin'
  THEN
    RAISE EXCEPTION 'profiles: un usuario no puede cambiar su propio rol (M6). Solo super_admin.';
  END IF;
  RETURN NEW;
END;
$fn$;

DO $b$ BEGIN
  IF to_regclass('public.profiles') IS NOT NULL THEN
    EXECUTE 'DROP TRIGGER IF EXISTS trg_profiles_autoelevacion ON profiles';
    EXECUTE 'CREATE TRIGGER trg_profiles_autoelevacion
             BEFORE UPDATE ON profiles
             FOR EACH ROW EXECUTE FUNCTION public.profiles_bloqueo_autoelevacion()';
  END IF;
END $b$;

-- ----------------------------------------------------------------------------
-- customers (M3): dueño (usuario_id) ve/edita sus filas; staff ve todas.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_customers_select ON customers;
DROP POLICY IF EXISTS pol_customers_insert ON customers;
DROP POLICY IF EXISTS pol_customers_update ON customers;
DROP POLICY IF EXISTS pol_customers_delete ON customers;

CREATE POLICY pol_customers_select ON customers
  FOR SELECT USING (public.is_auth(usuario_id) OR public.es_staff());

CREATE POLICY pol_customers_insert ON customers
  FOR INSERT WITH CHECK (public.is_auth(usuario_id) OR public.es_staff());

CREATE POLICY pol_customers_update ON customers
  FOR UPDATE USING (public.is_auth(usuario_id) OR public.es_staff())
  WITH CHECK (public.is_auth(usuario_id) OR public.es_staff());

CREATE POLICY pol_customers_delete ON customers
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- categories + products (M1/M2/M5): catálogo público de lectura; staff edita.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_categories_select ON categories;
DROP POLICY IF EXISTS pol_categories_insert ON categories;
DROP POLICY IF EXISTS pol_categories_update ON categories;
DROP POLICY IF EXISTS pol_categories_delete ON categories;

CREATE POLICY pol_categories_select ON categories FOR SELECT USING (true);
CREATE POLICY pol_categories_insert ON categories
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_categories_update ON categories
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_categories_delete ON categories
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_products_select ON products;
DROP POLICY IF EXISTS pol_products_insert ON products;
DROP POLICY IF EXISTS pol_products_update ON products;
DROP POLICY IF EXISTS pol_products_delete ON products;

CREATE POLICY pol_products_select ON products FOR SELECT USING (true);
COMMENT ON POLICY pol_products_select ON products IS 'Catálogo público (M1/M2): cualquiera puede ver (incluye anónimos).';

CREATE POLICY pol_products_insert ON products
  FOR INSERT WITH CHECK (public.es_staff());     -- editor/admin (M2 CRUD)
CREATE POLICY pol_products_update ON products
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff()); -- cambio de precio auditable (M6 audit)
CREATE POLICY pol_products_delete ON products
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- orders + order_items (M2/M5): dueño (vía customers.usuario_id) y staff.
--   Las transiciones de estado (pendiente→confirmado→…→cancelado) se
--   validan en lib/business/orders.ts (la política solo garantiza propiedad).
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_orders_select ON orders;
DROP POLICY IF EXISTS pol_orders_insert ON orders;
DROP POLICY IF EXISTS pol_orders_update ON orders;
DROP POLICY IF EXISTS pol_orders_delete ON orders;

CREATE POLICY pol_orders_select ON orders
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = orders.customer_id AND public.is_auth(c.usuario_id)
    )
  );

CREATE POLICY pol_orders_insert ON orders
  FOR INSERT WITH CHECK (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = orders.customer_id AND public.is_auth(c.usuario_id)
    )
  );

CREATE POLICY pol_orders_update ON orders
  FOR UPDATE USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = orders.customer_id AND public.is_auth(c.usuario_id)
    )
  ) WITH CHECK (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = orders.customer_id AND public.is_auth(c.usuario_id)
    )
  );

CREATE POLICY pol_orders_delete ON orders
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_order_items_select ON order_items;
DROP POLICY IF EXISTS pol_order_items_insert ON order_items;
DROP POLICY IF EXISTS pol_order_items_update ON order_items;
DROP POLICY IF EXISTS pol_order_items_delete ON order_items;

-- El ítem se ve si se ve su pedido (políticas del padre mediante subconsulta).
CREATE POLICY pol_order_items_select ON order_items
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_items.pedido_id
        AND EXISTS (
          SELECT 1 FROM customers c
          WHERE c.id = o.customer_id AND public.is_auth(c.usuario_id)
        )
    )
  );

CREATE POLICY pol_order_items_insert ON order_items
  FOR INSERT WITH CHECK (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM orders o WHERE o.id = order_items.pedido_id
        AND EXISTS (
          SELECT 1 FROM customers c
          WHERE c.id = o.customer_id AND public.is_auth(c.usuario_id)
        )
    )
  );

CREATE POLICY pol_order_items_update ON order_items
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());

CREATE POLICY pol_order_items_delete ON order_items
  FOR DELETE USING (public.es_staff());

-- ----------------------------------------------------------------------------
-- surveys (M4): catálogo público para encuestas activas+publicadas;
-- editor+ las gestiona.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_surveys_select ON surveys;
DROP POLICY IF EXISTS pol_surveys_insert ON surveys;
DROP POLICY IF EXISTS pol_surveys_update ON surveys;
DROP POLICY IF EXISTS pol_surveys_delete ON surveys;

CREATE POLICY pol_surveys_select ON surveys
  FOR SELECT USING (public.es_staff() OR (activa AND publicada));
CREATE POLICY pol_surveys_insert ON surveys
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_surveys_update ON surveys
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_surveys_delete ON surveys
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_questions_select ON questions;
DROP POLICY IF EXISTS pol_questions_insert ON questions;
DROP POLICY IF EXISTS pol_questions_update ON questions;
DROP POLICY IF EXISTS pol_questions_delete ON questions;

CREATE POLICY pol_questions_select ON questions
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM surveys s
      WHERE s.id = questions.survey_id AND s.activa AND s.publicada
    )
  );
CREATE POLICY pol_questions_insert ON questions
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_questions_update ON questions
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_questions_delete ON questions
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_question_options_select ON question_options;
DROP POLICY IF EXISTS pol_question_options_insert ON question_options;
DROP POLICY IF EXISTS pol_question_options_update ON question_options;
DROP POLICY IF EXISTS pol_question_options_delete ON question_options;

CREATE POLICY pol_question_options_select ON question_options
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1
      FROM questions q
      JOIN surveys s ON s.id = q.survey_id
      WHERE q.id = question_options.question_id AND s.activa AND s.publicada
    )
  );
CREATE POLICY pol_question_options_insert ON question_options
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_question_options_update ON question_options
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_question_options_delete ON question_options
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- responses (M4/§7): el público ENVIA (INSERT); staff lee para minería;
-- el dueño (customer) lee sus respuestas. Editor no borra datos personales.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_responses_select ON responses;
DROP POLICY IF EXISTS pol_responses_insert ON responses;
DROP POLICY IF EXISTS pol_responses_update ON responses;
DROP POLICY IF EXISTS pol_responses_delete ON responses;

CREATE POLICY pol_responses_select ON responses
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = responses.customer_id AND public.is_auth(c.usuario_id)
    )
  );
CREATE POLICY pol_responses_insert ON responses
  FOR INSERT WITH CHECK (true);  -- público: enviar encuesta no requiere login (M4)
CREATE POLICY pol_responses_update ON responses
  FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());
CREATE POLICY pol_responses_delete ON responses
  -- ARCO-erase (§7): el borrado real es una decisión de la capa app/admin.
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_survey_assignments_select ON survey_assignments;
DROP POLICY IF EXISTS pol_survey_assignments_insert ON survey_assignments;
DROP POLICY IF EXISTS pol_survey_assignments_update ON survey_assignments;
DROP POLICY IF EXISTS pol_survey_assignments_delete ON survey_assignments;

CREATE POLICY pol_survey_assignments_select ON survey_assignments
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = survey_assignments.customer_id AND public.is_auth(c.usuario_id)
    )
  );
CREATE POLICY pol_survey_assignments_insert ON survey_assignments
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_survey_assignments_update ON survey_assignments
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_survey_assignments_delete ON survey_assignments
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- leads + interactions (M5 CRM): solo staff.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_leads_select ON leads;
DROP POLICY IF EXISTS pol_leads_insert ON leads;
DROP POLICY IF EXISTS pol_leads_update ON leads;
DROP POLICY IF EXISTS pol_leads_delete ON leads;

CREATE POLICY pol_leads_select   ON leads FOR SELECT USING (public.es_staff());
CREATE POLICY pol_leads_insert   ON leads FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_leads_update   ON leads FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_leads_delete   ON leads FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_interactions_select ON interactions;
DROP POLICY IF EXISTS pol_interactions_insert ON interactions;
DROP POLICY IF EXISTS pol_interactions_update ON interactions;
DROP POLICY IF EXISTS pol_interactions_delete ON interactions;

CREATE POLICY pol_interactions_select ON interactions FOR SELECT USING (public.es_staff());
CREATE POLICY pol_interactions_insert ON interactions FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_interactions_update ON interactions FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());
CREATE POLICY pol_interactions_delete ON interactions FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- invoices (M5): dueño y staff leen; staff emite; admin corrige; super borra.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_invoices_select ON invoices;
DROP POLICY IF EXISTS pol_invoices_insert ON invoices;
DROP POLICY IF EXISTS pol_invoices_update ON invoices;
DROP POLICY IF EXISTS pol_invoices_delete ON invoices;

CREATE POLICY pol_invoices_select ON invoices
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = invoices.customer_id AND public.is_auth(c.usuario_id)
    )
  );
CREATE POLICY pol_invoices_insert ON invoices
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_invoices_update ON invoices
  FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());
CREATE POLICY pol_invoices_delete ON invoices
  FOR DELETE USING (public.es_super());

-- ----------------------------------------------------------------------------
-- audit_log (D7): append-only. Solo INSERT (staff) y SELECT (admin).
-- SIN políticas UPDATE/DELETE → inmutable para la aplicación.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_audit_log_select ON audit_log;
DROP POLICY IF EXISTS pol_audit_log_insert ON audit_log;

CREATE POLICY pol_audit_log_select ON audit_log FOR SELECT USING (public.es_admin());
CREATE POLICY pol_audit_log_insert ON audit_log FOR INSERT WITH CHECK (public.es_staff());
COMMENT ON POLICY pol_audit_log_insert ON audit_log IS 'D7: append-only. Inserta la capa servidor (service role/Express). Excepción única documentada: superusuario PostgreSQL con BYPASSRLS (ver docs/DB/README-DB.md).';

-- ----------------------------------------------------------------------------
-- site_config (§2): pública de lectura (paleta/textos/SEO del sitio);
-- solo admin escribe (branding M6).
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_site_config_select ON site_config;
DROP POLICY IF EXISTS pol_site_config_insert ON site_config;
DROP POLICY IF EXISTS pol_site_config_update ON site_config;

CREATE POLICY pol_site_config_select ON site_config FOR SELECT USING (true);
CREATE POLICY pol_site_config_insert ON site_config
  FOR INSERT WITH CHECK (public.es_admin());
CREATE POLICY pol_site_config_update ON site_config
  FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());

-- ----------------------------------------------------------------------------
-- email_templates (M6): plantillas funcionales de la app; staff lee,
-- admin escribe (M6 «plantillas editables»).
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_email_templates_select ON email_templates;
DROP POLICY IF EXISTS pol_email_templates_insert ON email_templates;
DROP POLICY IF EXISTS pol_email_templates_update ON email_templates;
DROP POLICY IF EXISTS pol_email_templates_delete ON email_templates;

CREATE POLICY pol_email_templates_select ON email_templates
  FOR SELECT USING (public.es_staff());
CREATE POLICY pol_email_templates_insert ON email_templates
  FOR INSERT WITH CHECK (public.es_admin());
CREATE POLICY pol_email_templates_update ON email_templates
  FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());
CREATE POLICY pol_email_templates_delete ON email_templates
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- email_log (M6): operativo; admin.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_email_log_select ON email_log;
DROP POLICY IF EXISTS pol_email_log_insert ON email_log;

CREATE POLICY pol_email_log_select ON email_log FOR SELECT USING (public.es_admin());
CREATE POLICY pol_email_log_insert ON email_log FOR INSERT WITH CHECK (public.es_staff());

-- ----------------------------------------------------------------------------
-- Fin 01_politicas.sql — continúa: db/seed.sql (datos demo, Fase 1).
-- ============================================================================
