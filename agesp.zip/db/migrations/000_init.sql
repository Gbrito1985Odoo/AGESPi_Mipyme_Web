-- ============================================================================
-- AGESP — Migración 000_init.sql
-- Fuente de verdad del esquema (decisión D10 del SDD §9/D).
-- Fase 1 · AGENTE-1 (Fundación DB). Idioma: español (D9).
--
-- Reglas del SDD aplicadas aquí:
--   §4.1  Esquema canónico portable: Supabase (auth.users) / PostgreSQL local.
--   §7    RLS en todas las tablas → se definen en db/rls/*.sql (guard dual).
--   D7    audit_log append-only (trigger + sin UPDATE/DELETE).
--   D11   Idempotencia defensiva: IF NOT EXISTS / CREATE OR REPLACE / DO $$ guard.
--
-- Ejecución recomendada (en orden):
--   1) db/migrations/*.sql  (este archivo primero)
--   2) db/rls/*.sql         (funciones puente + políticas por target)
--   3) db/seed.sql          (datos demo)
--   → `npm run db:local:init` (scripts/db-local-init.cjs) hace este orden.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 0) Extensiones y funciones puente de identidad (SDD §4.1)
-- ----------------------------------------------------------------------------

-- Cifrado en reposo para customers.tax_id (§7, pgcrypto).
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- ----------------------------------------------------------------------
-- Puente de identidad local: current_user_id()
-- El cliente local (lib/db/localClient.ts) hace `SET LOCAL app.user_id`
-- (set_config('app.user_id', $1, true)) dentro de la transacción.
-- En Supabase no se usa: el guard dual deriva a auth.uid().
-- ----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.current_user_id() RETURNS uuid
LANGUAGE plpgsql STABLE AS $fn$
DECLARE
  v text;
BEGIN
  v := current_setting('app.user_id', true);
  IF v IS NULL OR v = '' THEN
    RETURN NULL;
  END IF;
  RETURN v::uuid;
EXCEPTION WHEN OTHERS THEN
  RETURN NULL; -- valor no-uuid o entorno sin GUC: tratar como anónimo
END;
$fn$;

-- ----------------------------------------------------------------------
-- usuario_actual(): router dual de identidad.
--   - En Supabase (detectado por la tabla real auth.users) → auth.uid().
--   - Local → current_user_id() (GUC app.user_id).
-- Todas las políticas RLS (db/rls/*.sql) pasan por aquí para no duplicar lógica.
-- ----------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.usuario_actual() RETURNS uuid
LANGUAGE plpgsql STABLE AS $fn$
BEGIN
  IF to_regclass('auth.users') IS NOT NULL THEN
    RETURN auth.uid();
  END IF;
  RETURN public.current_user_id();
EXCEPTION WHEN OTHERS THEN
  RETURN NULL;
END;
$fn$;

-- ----------------------------------------------------------------------
-- Mock del esquema auth para portabilidad local (brief AGENTE-1 §1).
-- Solo se crea si NO existe el esquema real de Supabase; nunca toca el
-- auth authenticator de Supabase (guard DO $$ ... END $$, D11).
-- En local, auth.uid() devuelve el mismo valor que current_user_id().
-- ----------------------------------------------------------------------
DO $do$
BEGIN
  IF to_regclass('auth.users') IS NULL THEN
    IF NOT EXISTS (SELECT 1 FROM pg_namespace WHERE nspname = 'auth') THEN
      CREATE SCHEMA auth;
    END IF;
    IF NOT EXISTS (
      SELECT 1
      FROM pg_proc p
      JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname = 'auth' AND p.proname = 'uid'
    ) THEN
      CREATE FUNCTION auth.uid() RETURNS uuid
      LANGUAGE sql STABLE AS $fn$ SELECT public.current_user_id() $fn$;
    END IF;
  END IF;
END;
$do$;

-- Wrapper de políticas (brief §3): TRUE si el uuid dado coincide con el
-- usuario autenticado en el target actual (Supabase o local).
CREATE OR REPLACE FUNCTION public.is_auth(u uuid) RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT u IS NOT NULL AND u = public.usuario_actual() $fn$;

-- ----------------------------------------------------------------------------
-- Helpers de cifrado de tax_id (carné/NIT) con pgcrypto (§7, brief §1)
-- La clave se lee de la variable de sesión 'app.tax_key'. Si no está definida
-- se usa una-clave-por-defecto SOLO para desarrollo (documentado en
-- docs/DB/README-DB.md). En producción se fija con: SET app.tax_key = '…';
-- o por transacción: SELECT set_config('app.tax_key', $1, true);
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.encrypt_tax_id(texto text) RETURNS bytea
LANGUAGE sql STABLE AS $fn$
  SELECT pgp_sym_encrypt(
    texto,
    coalesce(current_setting('app.tax_key', true),
             'AGESP-clave-fiscales-DESARROLLO-cambiar-en-produccion')
  )
$fn$;

CREATE OR REPLACE FUNCTION public.decrypt_tax_id(dato bytea) RETURNS text
LANGUAGE sql STABLE AS $fn$
  SELECT pgp_sym_decrypt(
    dato,
    coalesce(current_setting('app.tax_key', true),
             'AGESP-clave-fiscales-DESARROLLO-cambiar-en-produccion')
  )
$fn$;

-- ----------------------------------------------------------------------------
-- 1) Tablas (18, SDD §4.2). Nombres de columna = nombres de campo de
--    lib/types/index.ts (snake_case en ambos lados; mapeo completo en db/schema.md).
-- ----------------------------------------------------------------------------

-- ----------------------------------------------------------------------------
-- 1.1) M1/M2 — Catálogo
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS categories (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre      text NOT NULL,
  slug        text NOT NULL UNIQUE,
  descripcion text,
  orden       integer,
  creado_en   timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE categories IS 'Categorías del catálogo (M2). Trazabilidad: §5 M2.';

CREATE TABLE IF NOT EXISTS products (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  codigo         text NOT NULL UNIQUE,          -- «ID» visible del catálogo (M2 / Art. 5 Res. 35/2020)
  nombre         text NOT NULL,
  descripcion    text,
  imagen_url     text,                          -- Supabase Storage
  precio         numeric(12,2) NOT NULL DEFAULT 0 CHECK (precio >= 0),
  moneda         text NOT NULL DEFAULT 'CUP' CHECK (moneda IN ('CUP','MLC','USD')),
  unidad         text NOT NULL DEFAULT 'unidad',-- unidad de venta: unidad/kg/mes/servicio…
  disponible     boolean NOT NULL DEFAULT true,
  tiempo_entrega text NOT NULL DEFAULT '',      -- obligatorio declarar (Art. 5 Res. 35/2020)
  destacado      boolean NOT NULL DEFAULT false,
  categoria_id   uuid REFERENCES categories(id) ON DELETE SET NULL,
  stock          integer NOT NULL DEFAULT 0 CHECK (stock >= 0),      -- M5 inventario
  stock_minimo   integer NOT NULL DEFAULT 0 CHECK (stock_minimo >= 0), -- alertas bajo inventario (M5)
  creado_en      timestamptz NOT NULL DEFAULT now(),
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE products IS 'Productos/servicios de la vitrina y tienda (M1/M2). Trazabilidad: §5 M1, M2, M5 (stock/art. 5 Res. 35/2020).';

CREATE INDEX IF NOT EXISTS idx_products_categoria ON products(categoria_id);
CREATE INDEX IF NOT EXISTS idx_products_destacado ON products(destacado) WHERE destacado;
CREATE INDEX IF NOT EXISTS idx_products_disponible ON products(disponible);

-- ----------------------------------------------------------------------------
-- 1.2) M3 — Directorio de clientes (tarjetas QR, cifrado tax_id)
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS customers (
  id                      uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  -- UUID público para la tarjeta: https://{dominio}/card/{uuid} (M3)
  uuid                    uuid NOT NULL UNIQUE DEFAULT gen_random_uuid(),
  usuario_id              uuid,                 -- dueño de la fila (para RLS de rol customer); extra fuera del contrato TS
  nombre                  text NOT NULL,
  tipo_entidad            text NOT NULL DEFAULT 'persona'
                          CHECK (tipo_entidad IN ('mipyme_estatal','mipyme_privada','persona','otro')),
  tax_id_cifrado          bytea NOT NULL,       -- carné/NIT cifrado con pgcrypto (encrypt_tax_id)
  domicilio               text,
  codigo_postal           text,
  telefono                text,
  correo                  text,
  credencial              text,
  consentimiento_aceptado boolean NOT NULL DEFAULT false, -- consentimiento explícito (§7, Ley 149)
  creado_en               timestamptz NOT NULL DEFAULT now(),
  actualizado_en          timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE customers IS 'Directorio de clientes (M3). tax_id cifrado en reposo (pgcrypto). FK opcional profiles(id)→auth.users solo en Supabase (ver README-DB).';

CREATE INDEX IF NOT EXISTS idx_customers_usuario ON customers(usuario_id);
CREATE INDEX IF NOT EXISTS idx_customers_tipo_entidad ON customers(tipo_entidad);

-- ----------------------------------------------------------------------------
-- 1.3) M2/M5 — Pedidos y facturación
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS orders (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_id    uuid REFERENCES customers(id) ON DELETE SET NULL,
  moneda         text NOT NULL DEFAULT 'CUP' CHECK (moneda IN ('CUP','MLC','USD')),
  estado         text NOT NULL DEFAULT 'pendiente'
                 CHECK (estado IN ('pendiente','confirmado','pagado','entregado','cancelado')),
  total          numeric(12,2) NOT NULL DEFAULT 0 CHECK (total >= 0),
  creado_en      timestamptz NOT NULL DEFAULT now(),
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);

CREATE TABLE IF NOT EXISTS order_items (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id       uuid NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  producto_id     uuid REFERENCES products(id) ON DELETE SET NULL,
  nombre_snapshot text NOT NULL,                -- snapshot histórico del pedido (M5)
  precio_snapshot numeric(12,2) NOT NULL CHECK (precio_snapshot >= 0),
  moneda          text NOT NULL DEFAULT 'CUP' CHECK (moneda IN ('CUP','MLC','USD')),
  cantidad        integer NOT NULL DEFAULT 1 CHECK (cantidad > 0)
);

CREATE INDEX IF NOT EXISTS idx_order_items_pedido ON order_items(pedido_id);

CREATE TABLE IF NOT EXISTS invoices (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  pedido_id      uuid NOT NULL REFERENCES orders(id) ON DELETE RESTRICT,
  serie          text NOT NULL DEFAULT 'A',     -- numeración secuencial (M5)
  numero         integer NOT NULL CHECK (numero > 0),
  customer_id    uuid REFERENCES customers(id) ON DELETE SET NULL,
  moneda         text NOT NULL DEFAULT 'CUP' CHECK (moneda IN ('CUP','MLC','USD')),
  total          numeric(12,2) NOT NULL DEFAULT 0 CHECK (total >= 0),
  datos_fiscales jsonb NOT NULL DEFAULT '{}'::jsonb,  -- datos fiscales del PDF (M5)
  pdf_url        text,
  creado_en      timestamptz NOT NULL DEFAULT now(),
  UNIQUE (serie, numero)
);

CREATE INDEX IF NOT EXISTS idx_invoices_pedido ON invoices(pedido_id);

-- ----------------------------------------------------------------------------
-- 1.4) M4 — Encuestas dinámicas
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS surveys (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo      text NOT NULL,
  descripcion text,
  activa      boolean NOT NULL DEFAULT false,
  publicada   boolean NOT NULL DEFAULT false,
  creado_en   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS questions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  survey_id   uuid NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  posicion    integer NOT NULL DEFAULT 1,
  seccion     text NOT NULL DEFAULT 'general',  -- agrupación visual (§8.1)
  tipo        text NOT NULL CHECK (tipo IN
              ('texto','seleccion','seleccion_multiple','likert','escala','fecha','numerica','si_no')),
  texto       text NOT NULL,
  ayuda       text,                             -- términos explicados (§8.2)
  obligatoria boolean NOT NULL DEFAULT false,
  metadata    jsonb DEFAULT '{}'::jsonb         -- lógica de salto: {"show_if":{"pregunta_id","valor"}}
);

CREATE INDEX IF NOT EXISTS idx_questions_survey ON questions(survey_id, posicion);

CREATE TABLE IF NOT EXISTS question_options (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question_id uuid NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  valor       text NOT NULL,
  etiqueta    text NOT NULL,
  orden       integer NOT NULL DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_question_options_question ON question_options(question_id, orden);

CREATE TABLE IF NOT EXISTS responses (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  survey_id   uuid NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES customers(id) ON DELETE SET NULL,
  datos       jsonb NOT NULL DEFAULT '{}'::jsonb,
  consent_log jsonb,                            -- log de consentimiento §7
  creado_en   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_responses_survey ON responses(survey_id);
CREATE INDEX IF NOT EXISTS idx_responses_customer ON responses(customer_id);

CREATE TABLE IF NOT EXISTS survey_assignments (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  survey_id   uuid NOT NULL REFERENCES surveys(id) ON DELETE CASCADE,
  customer_id uuid REFERENCES customers(id) ON DELETE CASCADE,
  token       uuid NOT NULL UNIQUE DEFAULT gen_random_uuid(), -- enlace público cuando no hay login
  estado      text NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente','completada')),
  creado_en   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_survey_assignments_survey ON survey_assignments(survey_id);

-- ----------------------------------------------------------------------------
-- 1.5) M5 — CRM
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS leads (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre         text NOT NULL,
  correo         text,
  telefono       text,
  pipeline       text NOT NULL DEFAULT 'nuevo'
                 CHECK (pipeline IN ('nuevo','contactado','propuesta','negociacion','ganado','perdido')),
  origen         text,
  notas          text,
  creado_en      timestamptz NOT NULL DEFAULT now(),
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_leads_pipeline ON leads(pipeline);

CREATE TABLE IF NOT EXISTS interactions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  entidad_tipo text NOT NULL CHECK (entidad_tipo IN ('lead','customer')),
  entidad_id  uuid NOT NULL,                    -- polimórfica: leads.id o customers.id
  canal       text NOT NULL CHECK (canal IN ('web','correo','telefono','presencial')),
  resumen     text NOT NULL,
  creado_por  uuid REFERENCES profiles(id) ON DELETE SET NULL, -- nota: profiles se crea en 1.6
  creado_en   timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_interactions_entidad ON interactions(entidad_tipo, entidad_id);

-- ----------------------------------------------------------------------------
-- 1.6) M6 — Admin, configuración, correo y auditoría
-- ----------------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS profiles (
  id             uuid PRIMARY KEY,              -- = auth.users.id en Supabase (FK condicional abajo)
  correo         text NOT NULL UNIQUE,
  nombre         text,
  rol            text NOT NULL DEFAULT 'customer'
                 CHECK (rol IN ('super_admin','admin','editor','customer')),  -- M6 roles (RLS)
  mfa_habilitado boolean NOT NULL DEFAULT false, -- MFA TOTP super_admin (M6, D3)
  creado_en      timestamptz NOT NULL DEFAULT now()
);

-- FK profiles.id → auth.users(id) SOLO en Supabase (la tabla real auth.users existe ahí;
-- en local el mock no crea esa tabla y este bloque queda inerte — guard dual, D11).
DO $do$
BEGIN
  IF to_regclass('auth.users') IS NOT NULL THEN
    IF NOT EXISTS (
      SELECT 1 FROM pg_constraint WHERE conname = 'fk_profiles_auth_users'
    ) THEN
      ALTER TABLE profiles
        ADD CONSTRAINT fk_profiles_auth_users
        FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;
    END IF;
  END IF;
END;
$do$;

CREATE TABLE IF NOT EXISTS site_config (
  clave          text PRIMARY KEY,              -- "colors.primary", "texto.hero_titulo"…
  valor          jsonb NOT NULL,
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE site_config IS 'Configuración editable en runtime: paleta diplomática, textos del hero, SEO (M1/M6). Regla dura: no hardcodear colores (§2).';

CREATE TABLE IF NOT EXISTS email_templates (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  clave          text NOT NULL UNIQUE,          -- p. ej. "bienvenida_qr"
  asunto         text NOT NULL,
  html           text NOT NULL,
  variables      text[] NOT NULL DEFAULT '{}',  -- {{nombre}}, {{url_tarjeta}}…
  actualizado_en timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS email_log (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  destinatario   text NOT NULL,
  plantilla_clave text,
  asunto         text NOT NULL,
  estado         text NOT NULL CHECK (estado IN ('enviado','error')),
  detalle_error  text,
  creado_en      timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_email_log_creado ON email_log(creado_en);

CREATE TABLE IF NOT EXISTS audit_log (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid REFERENCES profiles(id) ON DELETE SET NULL,
  accion     text NOT NULL,                     -- "login", "cambio_precio", "export"…
  entidad    text,
  entidad_id text,
  detalle    jsonb,
  creado_en  timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_audit_log_creado ON audit_log(creado_en);
CREATE INDEX IF NOT EXISTS idx_audit_log_user ON audit_log(user_id);

COMMENT ON TABLE audit_log IS 'AUDIT LOG APPEND-ONLY (D7). UPDATE/DELETE prohibidos por trigger. La única excepción documentada es que un superusuario real de PostgreSQL (rol con BYPASSRLS, p. ej. postgres) puede saltarse el trigger; la aplicación nunca expone esa vía. Ver docs/DB/README-DB.md.';

-- ----------------------------------------------------------------------------
-- 2) Funciones de rol para RLS (M6). DEFINER para que las políticas no
--    causen recursión con la propia RLS de profiles.
-- ----------------------------------------------------------------------------

CREATE OR REPLACE FUNCTION public.rol_actual() RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $fn$
  SELECT p.rol FROM public.profiles p WHERE p.id = public.usuario_actual() LIMIT 1
$fn$;

CREATE OR REPLACE FUNCTION public.es_staff() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() IN ('super_admin','admin','editor') $fn$;

CREATE OR REPLACE FUNCTION public.es_admin() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() IN ('super_admin','admin') $fn$;

CREATE OR REPLACE FUNCTION public.es_super() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() = 'super_admin' $fn$;

-- ----------------------------------------------------------------------------
-- 3) Triggers utilitarios
-- ----------------------------------------------------------------------------

-- actualizado_en automático en tablas con esa columna
CREATE OR REPLACE FUNCTION public.mantener_actualizado_en() RETURNS trigger
LANGUAGE plpgsql AS $fn$
BEGIN
  NEW.actualizado_en := now();
  RETURN NEW;
END;
$fn$;

DO $do$
DECLARE
  t text;
BEGIN
  -- lista literal de tablas con actualizado_en (idempotente)
  FOREACH t IN ARRAY ARRAY['customers','products','orders','leads','site_config','email_templates']
  LOOP
    EXECUTE format('DROP TRIGGER IF EXISTS trg_actualizado_en ON %I', t);
    EXECUTE format(
      'CREATE TRIGGER trg_actualizado_en BEFORE UPDATE ON %I
       FOR EACH ROW EXECUTE FUNCTION public.mantener_actualizado_en()', t);
  END LOOP;
END;
$do$;

-- ----------------------------------------------------------------------------
-- 4) audit_log APPEND-ONLY (D7): trigger que rechaza UPDATE/DELETE.
--    Sectores/proveedores: ver supuesto de excepción documentado en
--    docs/DB/README-DB.md (única vía: superusuario de PostgreSQL con BYPASSRLS).
-- ----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.audit_log_append_only() RETURNS trigger
LANGUAGE plpgsql AS $fn$
BEGIN
  -- Excepción única y documentada (D7): un superusuario real de PostgreSQL
  -- podría desactivar el trigger manualmente, pero la aplicación jamás lo hace.
  RAISE EXCEPTION 'audit_log es append-only (D7): las operaciones UPDATE/DELETE están prohibidas.';
END;
$fn$;

DROP TRIGGER IF EXISTS trg_audit_log_append_only ON audit_log;
CREATE TRIGGER trg_audit_log_append_only
  BEFORE UPDATE OR DELETE ON audit_log
  FOR EACH ROW EXECUTE FUNCTION public.audit_log_append_only();

-- ----------------------------------------------------------------------------
-- Fin de 000_init.sql — continúa: db/rls/*.sql (RLS) → db/seed.sql (datos demo)
-- ----------------------------------------------------------------------------
