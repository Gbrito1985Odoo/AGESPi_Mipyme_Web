-- ============================================================================
-- AGESP — db/seed.sql
-- Datos de arranque (SDD §4.1): 3 productos, 2 clientes demo, 1 encuesta demo
-- de 4 preguntas (+ opciones), site_config con la paleta diplomática y textos
-- del hero, y la plantilla de correo mínima "bienvenida_qr".
--
-- NO incluye la encuesta AGESP de 20 preguntas (Fase 4.5, decisión D5).
--
-- Idempotencia: ON CONFLICT DO NOTHING (claves únicas) + guard DO $$ … END $$
-- para las tablas sin clave de negocio. Idioma: español (D9).
-- Nota RLS: el seed se aplica con un superusuario (postgres / db:local:init),
-- que por diseño de PostgreSQL omite RLS; en Supabase no se aplica seed
-- automático (solo migraciones con `supabase db push`).
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1) Categorías (M2)
-- ----------------------------------------------------------------------------
INSERT INTO categories (nombre, slug, descripcion, orden) VALUES
  ('Servicios de seguridad física', 'seguridad-fisica',
   'Guardias, patrullaje, CCTV y señalética para instalaciones.', 1),
  ('Ciberseguridad', 'ciberseguridad',
   'Auditorías, SOC (Centro de Operaciones de Seguridad),respaldo de datos y firma digital.', 2),
  ('Asesoría y consultoría', 'asesoria',
   'Diagnóstico, cumplimiento normativo y capacitación (Mincom, Res. 35/2020, Ley 149).', 3)
ON CONFLICT (slug) DO NOTHING;

-- ----------------------------------------------------------------------------
-- 2) Productos demo (M1 vitrina destacados / M2 catálogo) — 3 productos
-- ----------------------------------------------------------------------------
INSERT INTO products
  (codigo, nombre, descripcion, precio, moneda, unidad, disponible,
   tiempo_entrega, destacado, categoria_id, stock, stock_minimo)
VALUES
  ('PRD-001', 'Guardia de seguridad (turno 12h)',
   'Servicio de guardia presencial en instalaciones diplomáticas y oficiales, con reporte diario de novedades.',
   1500.00, 'CUP', 'turno', true, '2 días hábiles desde la confirmación', true,
   (SELECT id FROM categories WHERE slug = 'seguridad-fisica'), 20, 5),

  ('PRD-002', 'Auditoría básica de ciberseguridad',
   'Diagnóstico de riesgos digitales, revisión de respaldo (backup) y recomendaciones de firmas digitales y control de accesos.',
   9800.00, 'MLC', 'servicio', true, '7 días hábiles desde la confirmación', true,
   (SELECT id FROM categories WHERE slug = 'ciberseguridad'), 4, 2),

  ('PRD-003', 'Plan de asesoría normativa mensual',
   'Acompañamiento continuo en cumplimiento (Res. 35/2020, Ley 149, Res. 58/2022) con informes mensuales.',
   12500.00, 'USD', 'mes', true, '3 días hábiles para el arranque', true,
   (SELECT id FROM categories WHERE slug = 'asesoria'), 10, 3)
ON CONFLICT (codigo) DO NOTHING;

-- ----------------------------------------------------------------------------
-- 3) Clientes demo (M3) — tax_id cifrado con pgcrypto (§7)
--    usuario_id NULL: los demo no tienen cuenta; solo el staff los ve (RLS).
-- ----------------------------------------------------------------------------
DO $b$
DECLARE
  v_clientes integer;
BEGIN
  SELECT count(*) INTO v_clientes FROM customers
  WHERE nombre IN ('Compañía Demo de Gestión S.A.', 'Mipyme Demo de Servicios Ltda.');

  IF v_clientes < 2 THEN
    INSERT INTO customers
      (usuario_id, nombre, tipo_entidad, tax_id_cifrado, domicilio,
       codigo_postal, telefono, correo, credencial, consentimiento_aceptado)
    VALUES
      (NULL, 'Compañía Demo de Gestión S.A.', 'mipyme_estatal',
       public.encrypt_tax_id('NIT-DEMO-12345678'),
       'Calle Diplomática #58, Vedado, La Habana', '10400',
       '+53 5 000 0000', 'demo1@agesp.cu', 'credencial-demo-001', true),
      (NULL, 'Mipyme Demo de Servicios Ltda.', 'mipyme_privada',
       public.encrypt_tax_id('NIT-DEMO-87654321'),
       'Avenida Seguridad #120, Playa, La Habana', '11300',
       '+53 5 111 1111', 'demo2@agesp.cu', 'credencial-demo-002', true);
  END IF;
END $b$;

-- ----------------------------------------------------------------------------
-- 4) Encuesta demo (M4) — 4 preguntas con opciones y un salto lógico de
--    ejemplo (metadata.show_if, §8.2). Se crea solo si no existe.
-- ----------------------------------------------------------------------------
DO $b$
DECLARE
  v_survey  uuid;
  v_q       uuid;
BEGIN
  SELECT id INTO v_survey FROM surveys WHERE titulo = 'Encuesta demo AGESP (Fase 1)';

  IF v_survey IS NULL THEN
    INSERT INTO surveys (titulo, descripcion, activa, publicada)
    VALUES ('Encuesta demo AGESP (Fase 1)',
            'Encuesta de prueba para validar el constructor y la minería (M4).',
            true, true)
    RETURNING id INTO v_survey;

    -- P1 texto
    INSERT INTO questions (survey_id, posicion, seccion, tipo, texto, ayuda, obligatoria)
    VALUES (v_survey, 1, 'Empresa', 'texto',
            '¿Cuál es el nombre de su entidad?', NULL, true)
    RETURNING id INTO v_q;
    NULL;

    -- P2 selección (tipo de entidad)
    INSERT INTO questions (survey_id, posicion, seccion, tipo, texto, ayuda, obligatoria)
    VALUES (v_survey, 2, 'Empresa', 'seleccion',
            '¿Qué tipo de entidad representa?',
            'Mipyme Estatal, Mipyme Privada, Trabajador por cuenta propia, Otra', true)
    RETURNING id INTO v_q;
    INSERT INTO question_options (question_id, valor, etiqueta, orden) VALUES
      (v_q, 'mipyme_estatal', 'Mipyme Estatal', 1),
      (v_q, 'mipyme_privada', 'Mipyme Privada', 2),
      (v_q, 'cuenta_propia',  'Trabajador por cuenta propia', 3),
      (v_q, 'otro',           'Otra', 4);

    -- P3 sí/no con salto lógico: P4 solo se muestra si "Sí tiene vigilancia"
    INSERT INTO questions (survey_id, posicion, seccion, tipo, texto, ayuda, obligatoria, metadata)
    VALUES (v_survey, 3, 'Seguridad', 'si_no',
            '¿Su entidad cuenta con vigilancia privada o pública?',
            'Vigilancia: personal o medios que protegen la instalación.', true,
            '{"salto":{"si":"P4"}}'::jsonb)
    RETURNING id INTO v_q;
    INSERT INTO question_options (question_id, valor, etiqueta, orden) VALUES
      (v_q, 'si', 'Sí', 1),
      (v_q, 'no', 'No', 2);

    -- P4 selección múltiple (condicionada por P3 vía show_if)
    INSERT INTO questions (survey_id, posicion, seccion, tipo, texto, ayuda, obligatoria, metadata)
    VALUES (v_survey, 4, 'Seguridad', 'seleccion_multiple',
            '¿Qué medios de protección utiliza? (CCTV: circuito cerrado de televisión)',
            'Marque todas las que correspondan.', false,
            '{"show_if":{"posicion":3,"valor":"si"}}'::jsonb)
    RETURNING id INTO v_q;
    INSERT INTO question_options (question_id, valor, etiqueta, orden) VALUES
      (v_q, 'cctv',        'CCTV (circuito cerrado de televisión)', 1),
      (v_q, 'senalética',  'Señalética (carteles informativos)', 2),
      (v_q, 'backup',      'Respaldo de datos (backup)', 3),
      (v_q, 'ninguno',     'Ninguno', 4);
  END IF;
END $b$;

-- ----------------------------------------------------------------------------
-- 5) site_config — paleta diplomática + textos editables (SDD §2, regla dura:
--    los colores se leen AQUÍ en runtime, nunca hardcoded en el frontend).
-- ----------------------------------------------------------------------------
INSERT INTO site_config (clave, valor) VALUES
  ('paleta.primario',   '"#0B2E59"'),   -- Azul diplomático: headers, CTA, tarjetas QR, PDFs
  ('paleta.fondo',      '"#FFFFFF"'),   -- Blanco
  ('paleta.gris',       '"#4A5568"'),   -- Gris diplomático: texto secundario, bordes
  ('paleta.gris_suave', '"#E2E8F0"'),   -- Gris claro: fondos suaves
  ('paleta.acento',     '"#F4C430"'),   -- Amarillo: badges, precios
  ('tipografia',        '"Inter, system-ui, sans-serif"'),
  ('logo.svg',          '"data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22%3E%3Crect width=%22100%22 height=%22100%22 rx=%2212%22 fill=%22%230B2E59%22/%3E%3Cpath d=%22M50 14 82 32v22c0 18-13 29-32 34-19-5-32-16-32-34V32z%22 fill=%22%23F4C430%22/%3E%3C/svg%3E"'),
  ('logo.alt',          '"Escudo de la AGESP"'),
  ('texto.hero_titulo', '"Protegemos lo que importa: seguridad integral para su entidad"'),
  ('texto.hero_subtitulo', '"Vitrina de servicios y tienda de la AGESP: seguridad física, ciberseguridad y asesoría normativa para las mipymes del país."'),
  ('texto.cta_primario', '"Ver servicios"'),
  ('texto.cta_secundario', '"Registrarse"'),
  ('texto.quienes_somos', '"Aseguramiento y Protección Grupal (AGESP) es una mipyme estatal socialista dedicada a la integridad del patrimonio y las personas."'),
  ('texto.como_comprar', '"1) Cree su cuenta y obtenga su tarjeta con QR  2) Agregue servicios al carrito  3) Confirme y reciba su factura."'),
  ('texto.contacto', '"Correo: contacto@agesp.cu · Teléfono: +53 5 000 0000"'),
  ('seo.meta_titulo', '"AGESP — Seguridad integral para mipymes"'),
  ('seo.meta_descripcion', '"Vitrina, tienda y servicios de seguridad física, ciberseguridad y asesoría normativa de la AGESP."')
ON CONFLICT (clave) DO NOTHING;

-- ----------------------------------------------------------------------------
-- 6) email_templates — plantilla mínima "bienvenida_qr" (M3, M6)
-- ----------------------------------------------------------------------------
INSERT INTO email_templates (clave, asunto, html, variables) VALUES
  ('bienvenida_qr',
   'Bienvenido(a) a la AGESP — su tarjeta de servicios',
   E'<div style="font-family:sans-serif;max-width:560px;margin:auto">\n'
     '<h1 style="color:#0B2E59">Bienvenido(a), {{nombre}}</h1>\n'
     '<p>Su entidad quedó registrada en el directorio de la AGESP.</p>\n'
     '<p>Su tarjeta pública con QR está disponible en:<br>\n'
     '<a style="color:#0B2E59" href="{{url_tarjeta}}">{{url_tarjeta}}</a></p>\n'
     '<p style="color:#4A5568;font-size:12px">Si no solicitó este registro, ignore este mensaje.</p>\n'
     '</div>',
   ARRAY['{{nombre}}', '{{url_tarjeta}}'])
ON CONFLICT (clave) DO NOTHING;

-- ----------------------------------------------------------------------------
-- Fin seed.sql — la encuesta AGESP (20 preguntas / 7 secciones) llega en
-- la Fase 4.5 vía migración + seed adicional (D5).
-- ============================================================================
