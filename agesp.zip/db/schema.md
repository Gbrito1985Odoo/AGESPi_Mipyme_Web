# AGESP — Mapa del esquema de datos

> **Fuente de verdad:** `db/migrations/*.sql` + `db/rls/*.sql` (decisión **D10** del SDD).
> `db/schema.sql` es un **snapshot generado** (solo lectura). Este documento es el mapa
> humano de referencia. Fase 1 · AGENTE-1. Idioma: español (D9).

## Generalidades

- **PostgreSQL 16** (Supabase o local vía Docker). Extensión `pgcrypto`.
- **18 tablas**, todas en el esquema `public`, UUID (`gen_random_uuid()`) como PK.
- **Nombres de columna = nombres de campo** de `lib/types/index.ts` (snake_case en ambos lados).
- **RLS activo en las 18 tablas** (`db/rls/00_funciones_puente.sql` + `01_politicas.sql`).
- **Monedas válidas:** `CUP | MLC | USD` (CHECK en `products`, `orders`, `order_items`, `invoices`).
- **Roles de usuario (M6):** `super_admin | admin | editor | customer` (`profiles.rol`).
- **Cifrado de `customers.tax_id_cifrado`** con pgcrypto (`encrypt_tax_id` / `decrypt_tax_id`,
  clave por sesión `app.tax_key`; ver `docs/DB/README-DB.md`).

## Puente de identidad (dual Supabase / local)

| Función | Supabase | Local |
|---|---|---|
| `usuario_actual()` | `auth.uid()` | `current_user_id()` (GUC `app.user_id` vía `SET LOCAL`) |
| `is_auth(u)` | `u = auth.uid()` | `u = current_user_id()` |
| `auth.uid()` | real | mock que delega en `current_user_id()` |

## Tablas por módulo

### M1/M2 — Catálogo

**categories** — categorías del catálogo
- `id` uuid PK · `nombre` text · `slug` text UNIQUE · `descripcion` text · `orden` int · `creado_en` timestamptz

**products** — productos/servicios (vitrina + tienda)
- `id` uuid PK · `codigo` text UNIQUE («ID» visible, M2) · `nombre` · `descripcion` · `imagen_url` (Supabase Storage)
- `precio` numeric(12,2) ≥ 0 · `moneda` (CUP/MLC/USD) · `unidad` (unidad/kg/mes/servicio…)
- `disponible` bool · **`tiempo_entrega` text** (obligatorio, Art. 5 Res. 35/2020) · `destacado` bool
- `categoria_id` → categories (SET NULL) · `stock` int ≥ 0 · `stock_minimo` int ≥ 0 (alertas M5)
- `creado_en` · `actualizado_en`
- Índices: `categoria_id`, parcial `destacado WHERE destacado`, `disponible`

### M3 — Clientes (tarjetas QR)

**customers** — directorio de clientes
- `id` uuid PK · **`uuid` uuid UNIQUE** (público: `https://{dominio}/card/{uuid}`) · `usuario_id` uuid (dueño, RLS customer)
- `nombre` · `tipo_entidad` (`mipyme_estatal|mipyme_privada|persona|otro`) · **`tax_id_cifrado` bytea** (pgcrypto)
- `domicilio` · `codigo_postal` · `telefono` · `correo` · `credencial` · `consentimiento_aceptado` bool (Ley 149)
- `creado_en` · `actualizado_en`

### M2/M5 — Pedidos y facturación

**orders** — pedidos
- `id` PK · `customer_id` → customers (SET NULL) · `moneda` · `estado` (`pendiente|confirmado|pagado|entregado|cancelado`) · `total` numeric(12,2) ≥ 0 · timestamps

**order_items** — líneas de pedido
- `id` PK · `pedido_id` → orders (CASCADE) · `producto_id` → products (SET NULL)
- `nombre_snapshot` + `precio_snapshot` (histórico M5) · `moneda` · `cantidad` > 0

**invoices** — facturas
- `id` PK · `pedido_id` → orders (RESTRICT) · `serie` (default `A`) + `numero` > 0, **UNIQUE(serie, numero)**
- `customer_id` (SET NULL) · `moneda` · `total` · `datos_fiscales` jsonb (datos del PDF, M5) · `pdf_url` · `creado_en`

### M4 — Encuestas dinámicas

**surveys** — `id` · `titulo` · `descripcion` · `activa` bool · `publicada` bool · `creado_en`

**questions** — preguntas
- `id` PK · `survey_id` → surveys (CASCADE) · `posicion` int · `seccion` (agrupación §8.1)
- `tipo` (`texto|seleccion|seleccion_multiple|likert|escala|fecha|numerica|si_no`)
- `texto` · `ayuda` (términos explicados §8.2) · `obligatoria` bool
- `metadata` jsonb — lógica de salto: `{"show_if": {"pregunta_id", "valor"}}`

**question_options** — `id` PK · `question_id` → questions (CASCADE) · `valor` · `etiqueta` · `orden`

**responses** — respuestas
- `id` PK · `survey_id` (CASCADE) · `customer_id` (SET NULL) · `datos` jsonb · `consent_log` jsonb (§7) · `creado_en`

**survey_assignments** — asignaciones
- `id` PK · `survey_id` (CASCADE) · `customer_id` (CASCADE) · **`token` uuid UNIQUE** (enlace sin login)
- `estado` (`pendiente|completada`) · `creado_en`

### M5 — CRM

**leads** — `id` PK · `nombre` · `correo` · `telefono` · `pipeline` (`nuevo|contactado|propuesta|negociacion|ganado|perdido`) · `origen` · `notas` · timestamps

**interactions** — interacciones polimórficas
- `id` PK · `entidad_tipo` (`lead|customer`) + `entidad_id` uuid (sin FK, polimórfica)
- `canal` (`web|correo|telefono|presencial`) · `resumen` · `creado_por` → profiles (SET NULL) · `creado_en`

### M6 — Admin, configuración, correo y auditoría

**profiles** — usuarios del sistema
- `id` uuid PK (= `auth.users.id` en Supabase; **FK condicional** `fk_profiles_auth_users` solo allí, guard D11)
- `correo` UNIQUE · `nombre` · `rol` (`super_admin|admin|editor|customer`) · `mfa_habilitado` bool (MFA TOTP super_admin, D3) · `creado_en`

**site_config** — configuración editable en runtime (clave jsonb)
- `clave` PK («colors.primary», «texto.hero_titulo»…) · `valor` jsonb · `actualizado_en`
- Regla dura: **la paleta nunca se hardcodea**, se lee aquí en runtime (§2)

**email_templates** — `id` PK · `clave` UNIQUE («bienvenida_qr») · `asunto` · `html` · `variables` text[] (`{{nombre}}`, `{{url_tarjeta}}`…) · `actualizado_en`

**email_log** — `id` PK · `destinatario` · `plantilla_clave` · `asunto` · `estado` (`enviado|error`) · `detalle_error` · `creado_en`

**audit_log** — auditoría
- `id` PK · `user_id` → profiles (SET NULL) · `accion` («login», «cambio_precio», «export»…) · `entidad` · `entidad_id` · `detalle` jsonb · `creado_en`
- **APPEND-ONLY (D7):** trigger `trg_audit_log_append_only` rechaza UPDATE/DELETE; en RLS solo hay políticas INSERT/SELECT. Única excepción documentada: superusuario PostgreSQL real con BYPASSRLS.

## Matriz RLS resumida (detalle en `db/rls/01_politicas.sql`)

| Tabla | SELECT | INSERT | UPDATE | DELETE |
|---|---|---|---|---|
| profiles | propio / staff | propio | propio (rol protegido por trigger) | — |
| customers | dueño / staff | dueño | dueño / staff | admin |
| categories, products | público | staff | staff | admin |
| orders, order_items | dueño / staff | dueño / staff | dueño / staff | admin |
| surveys, questions, question_options | público si `activa AND publicada` | admin | staff/admin | admin |
| responses | staff o dueño | público | admin | admin |
| survey_assignments | staff o dueño | staff | staff | admin |
| leads, interactions | staff | staff | staff | admin |
| invoices | staff o dueño | staff | admin | super_admin |
| audit_log | admin | staff | **—** (append-only) | **—** |
| site_config | público | admin | admin | admin |
| email_templates | staff | admin | admin | admin |
| email_log | admin | staff | — | — |

> Nota: las políticas no llevan cláusula `TO` (aplican a anon + authenticated de forma uniforme; el
> predicado decide). Las funciones `rol_actual/es_staff/es_admin/es_super` son `SECURITY DEFINER`
> para evitar recursión con la RLS de `profiles`.

## Triggers y helpers

- `trg_actualizado_en` en `customers, products, orders, leads, site_config, email_templates`.
- `profiles_bloqueo_autoelevacion` (en `01_politicas.sql`): nadie cambia su propio `rol` salvo `super_admin`.
- `audit_log_append_only` (D7): excepción en UPDATE/DELETE.

## Aplicación del esquema

```bash
# Local (Docker + Node): crea BD, aplica migraciones → RLS → seed, en ese orden
npm run db:local:init
# Manual, con psql:
psql "$DATABASE_URL" -f db/migrations/000_init.sql
psql "$DATABASE_URL" -f db/rls/00_funciones_puente.sql
psql "$DATABASE_URL" -f db/rls/01_politicas.sql
psql "$DATABASE_URL" -f db/seed.sql
# Supabase: supabase/migrations/ (copia de db/migrations) + SQL editor para db/rls/*.sql y db/seed.sql
```

## Seed demo (Fase 1, idempotente)

- 3 categorías: `seguridad-fisica`, `ciberseguridad`, `asesoria`.
- 3 productos: **PRD-001** Guardia 1500 CUP · **PRD-002** Auditoría 9800 MLC · **PRD-003** Asesoría 12500 USD
  (todos con `tiempo_entrega`, stock y `stock_minimo`; PRD-001 destacado).
- 2 clientes demo (`mipyme_estatal`, `mipyme_privada`) con `tax_id` cifrado y consentimiento.
- Encuesta demo de **4 preguntas** con salto condicional (la encuesta oficial de 20 preguntas entra en Fase 4.5, D5).
- `site_config` con la paleta diplomática (`#0B2E59`, `#FFFFFF`, `#4A5568`, `#E2E8F0`, `#F4C430`),
  tipografía Inter, textos hero/quiénes-somos/cómo-comprar/contacto y SEO.
- Plantilla de correo `bienvenida_qr`.
