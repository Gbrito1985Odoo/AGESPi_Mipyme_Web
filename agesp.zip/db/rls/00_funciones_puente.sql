-- ============================================================================
-- AGESP — db/rls/00_funciones_puente.sql
-- Funciones puente de identidad + habilitación de RLS en TODAS las tablas (§7).
--
-- Guard dual (SDD §4.1, brief AGENTE-1 §3):
--   - Supabase: auth.uid() (tabla real auth.users presente).
--   - Local:    current_user_id() leyendo current_setting('app.user_id', true)
--               (el cliente local hace SET LOCAL app.user_id).
-- La migración 000_init.sql ya crea estas funciones; aquí se redefinen con
-- CREATE OR REPLACE como idempotencia defensiva (D11) para que este paquete
-- RLS también funcione aplicado aislado.
-- ============================================================================

-- Puente local ---------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.current_user_id() RETURNS uuid
LANGUAGE plpgsql STABLE AS $fn$
DECLARE v text;
BEGIN
  v := current_setting('app.user_id', true);
  IF v IS NULL OR v = '' THEN RETURN NULL; END IF;
  RETURN v::uuid;
EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;
$fn$;

-- Router dual ----------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.usuario_actual() RETURNS uuid
LANGUAGE plpgsql STABLE AS $fn$
BEGIN
  IF to_regclass('auth.users') IS NOT NULL THEN RETURN auth.uid(); END IF;
  RETURN public.current_user_id();
EXCEPTION WHEN OTHERS THEN RETURN NULL;
END;
$fn$;

-- Wrapper para políticas (brief §3) -------------------------------------------
CREATE OR REPLACE FUNCTION public.is_auth(u uuid) RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT u IS NOT NULL AND u = public.usuario_actual() $fn$;

-- Roles (M6) -----------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.rol_actual() RETURNS text
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $fn$
  SELECT p.rol FROM public.profiles p WHERE p.id = public.usuario_actual() LIMIT 1
$fn$;

CREATE OR REPLACE FUNCTION public.es_staff() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() IN ('super_admin','admin','editor') $fn$;

CREATE OR REPLACE FUNCTION public.es_admin() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() IN ('super_admin','admin') $fn$;

CREATE OR REPLACE FUNCTION public.es_super() RETURNS boolean
LANGUAGE sql STABLE AS $fn$ SELECT public.rol_actual() = 'super_admin' $fn$;

-- ----------------------------------------------------------------------------
-- Habilitar RLS en las 18 tablas (idempotente en cualquier target)
-- ----------------------------------------------------------------------------
ALTER TABLE IF EXISTS profiles            ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS customers           ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS products            ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS categories          ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS orders              ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS order_items         ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS surveys             ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS questions           ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS question_options    ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS responses           ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS leads               ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS interactions        ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS invoices            ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS audit_log           ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS site_config         ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_templates     ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_log             ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS survey_assignments  ENABLE ROW LEVEL SECURITY;
