-- ============================================================================
-- AGESP — db/rls/01_politicas.sql
-- Políticas RLS para TODAS las tablas (SDD §7, brief AGENTE-1 §3).
--
-- Roles (M6): super_admin > admin > editor > customer. Funciones de rol ya
-- creadas en 000_init.sql / 00_funciones_puente.sql:
--   usuario_actual(), is_auth(u), rol_actual(), es_staff(), es_admin(), es_super()
--
-- Paridad dual (sustituida por el SDD §4.1):
--   - Supabase → usuario_actual() = auth.uid().
--   - Local    → usuario_actual() = current_user_id() (GUC app.user_id, que
--                lib/db/localClient.ts fija con SET LOCAL app.user_id).
--
-- Idioma: español (D9). Idempotencia defensiva: DROP POLICY IF EXISTS +
-- guard DO $$ ... END $$ por tabla (D11). Las políticas se crean sin cláusula
-- TO (aplica a PUBLIC en local y a anon/authenticated en Supabase): el control
-- real se hace en USING/WITH CHECK por identidad y rol.
--
-- Nota de supervisión (D7): audit_log NO tiene políticas de UPDATE/DELETE:
-- la fila es inmutable para la aplicación. La excepción única documentada es
-- un superusuario real de PostgreSQL (BYPASSRLS); nunca una vía de la app.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- profiles (M6): cada usuario ve y edita su fila; super_admin gestiona todas.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_profiles_select ON profiles;
DROP POLICY IF EXISTS pol_profiles_insert ON profiles;
DROP POLICY IF EXISTS pol_profiles_update ON profiles;

CREATE POLICY pol_profiles_select ON profiles
  FOR SELECT USING (public.is_auth(id) OR public.es_admin());

CREATE POLICY pol_profiles_insert ON profiles
  FOR INSERT WITH CHECK (
    public.is_auth(id)
    -- Un usuario nuevo solo puede crear SU perfil con rol customer;
    -- la elevación de rol es exclusiva del super_admin.
    AND (rol = 'customer' OR public.es_super())
  );

CREATE POLICY pol_profiles_update ON profiles
  FOR UPDATE USING (public.is_auth(id) OR public.es_super())
  WITH CHECK (public.is_auth(id) OR public.es_super());

-- Defensa en profundidad: un usuario autenticado nunca puede auto-elevar su
-- rol por UPDATE propio (la capa app nunca lo necesita; M6/D3).
CREATE OR REPLACE FUNCTION public.profiles_bloqueo_autoelevacion() RETURNS trigger
LANGUAGE plpgsql AS $fn$
BEGIN
  IF public.usuario_actual() IS NOT NULL
     AND OLD.id = public.usuario_actual()
     AND NEW.rol IS DISTINCT FROM OLD.rol
     AND public.rol_actual() <> 'super_admin'
  THEN
    RAISE EXCEPTION 'profiles: un usuario no puede cambiar su propio rol (M6). Solo super_admin.';
  END IF;
  RETURN NEW;
END;
$fn$;

DO $b$ BEGIN
  IF to_regclass('public.profiles') IS NOT NULL THEN
    EXECUTE 'DROP TRIGGER IF EXISTS trg_profiles_autoelevacion ON profiles';
    EXECUTE 'CREATE TRIGGER trg_profiles_autoelevacion
             BEFORE UPDATE ON profiles
             FOR EACH ROW EXECUTE FUNCTION public.profiles_bloqueo_autoelevacion()';
  END IF;
END $b$;

-- ----------------------------------------------------------------------------
-- customers (M3): dueño (usuario_id) ve/edita sus filas; staff ve todas.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_customers_select ON customers;
DROP POLICY IF EXISTS pol_customers_insert ON customers;
DROP POLICY IF EXISTS pol_customers_update ON customers;
DROP POLICY IF EXISTS pol_customers_delete ON customers;

CREATE POLICY pol_customers_select ON customers
  FOR SELECT USING (public.is_auth(usuario_id) OR public.es_staff());

CREATE POLICY pol_customers_insert ON customers
  FOR INSERT WITH CHECK (public.is_auth(usuario_id) OR public.es_staff());

CREATE POLICY pol_customers_update ON customers
  FOR UPDATE USING (public.is_auth(usuario_id) OR public.es_staff())
  WITH CHECK (public.is_auth(usuario_id) OR public.es_staff());

CREATE POLICY pol_customers_delete ON customers
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- categories + products (M1/M2/M5): catálogo público de lectura; staff edita.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_categories_select ON categories;
DROP POLICY IF EXISTS pol_categories_insert ON categories;
DROP POLICY IF EXISTS pol_categories_update ON categories;
DROP POLICY IF EXISTS pol_categories_delete ON categories;

CREATE POLICY pol_categories_select ON categories FOR SELECT USING (true);
CREATE POLICY pol_categories_insert ON categories
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_categories_update ON categories
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_categories_delete ON categories
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_products_select ON products;
DROP POLICY IF EXISTS pol_products_insert ON products;
DROP POLICY IF EXISTS pol_products_update ON products;
DROP POLICY IF EXISTS pol_products_delete ON products;

CREATE POLICY pol_products_select ON products FOR SELECT USING (true);
COMMENT ON POLICY pol_products_select ON products IS 'Catálogo público (M1/M2): cualquiera puede ver (incluye anónimos).';

CREATE POLICY pol_products_insert ON products
  FOR INSERT WITH CHECK (public.es_staff());     -- editor/admin (M2 CRUD)
CREATE POLICY pol_products_update ON products
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff()); -- cambio de precio auditable (M6 audit)
CREATE POLICY pol_products_delete ON products
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- orders + order_items (M2/M5): dueño (vía customers.usuario_id) y staff.
--   Las transiciones de estado (pendiente→confirmado→…→cancelado) se
--   validan en lib/business/orders.ts (la política solo garantiza propiedad).
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_orders_select ON orders;
DROP POLICY IF EXISTS pol_orders_insert ON orders;
DROP POLICY IF EXISTS pol_orders_update ON orders;
DROP POLICY IF EXISTS pol_orders_delete ON orders;

CREATE POLICY pol_orders_select ON orders
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = orders.customer_id AND public.is_auth(c.usuario_id)
    )
  );

CREATE POLICY pol_orders_insert ON orders
  FOR INSERT WITH CHECK (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = orders.customer_id AND public.is_auth(c.usuario_id)
    )
  );

CREATE POLICY pol_orders_update ON orders
  FOR UPDATE USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = orders.customer_id AND public.is_auth(c.usuario_id)
    )
  ) WITH CHECK (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = orders.customer_id AND public.is_auth(c.usuario_id)
    )
  );

CREATE POLICY pol_orders_delete ON orders
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_order_items_select ON order_items;
DROP POLICY IF EXISTS pol_order_items_insert ON order_items;
DROP POLICY IF EXISTS pol_order_items_update ON order_items;
DROP POLICY IF EXISTS pol_order_items_delete ON order_items;

-- El ítem se ve si se ve su pedido (políticas del padre mediante subconsulta).
CREATE POLICY pol_order_items_select ON order_items
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM orders o
      WHERE o.id = order_items.pedido_id
        AND EXISTS (
          SELECT 1 FROM customers c
          WHERE c.id = o.customer_id AND public.is_auth(c.usuario_id)
        )
    )
  );

CREATE POLICY pol_order_items_insert ON order_items
  FOR INSERT WITH CHECK (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM orders o WHERE o.id = order_items.pedido_id
        AND EXISTS (
          SELECT 1 FROM customers c
          WHERE c.id = o.customer_id AND public.is_auth(c.usuario_id)
        )
    )
  );

CREATE POLICY pol_order_items_update ON order_items
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());

CREATE POLICY pol_order_items_delete ON order_items
  FOR DELETE USING (public.es_staff());

-- ----------------------------------------------------------------------------
-- surveys (M4): catálogo público para encuestas activas+publicadas;
-- editor+ las gestiona.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_surveys_select ON surveys;
DROP POLICY IF EXISTS pol_surveys_insert ON surveys;
DROP POLICY IF EXISTS pol_surveys_update ON surveys;
DROP POLICY IF EXISTS pol_surveys_delete ON surveys;

CREATE POLICY pol_surveys_select ON surveys
  FOR SELECT USING (public.es_staff() OR (activa AND publicada));
CREATE POLICY pol_surveys_insert ON surveys
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_surveys_update ON surveys
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_surveys_delete ON surveys
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_questions_select ON questions;
DROP POLICY IF EXISTS pol_questions_insert ON questions;
DROP POLICY IF EXISTS pol_questions_update ON questions;
DROP POLICY IF EXISTS pol_questions_delete ON questions;

CREATE POLICY pol_questions_select ON questions
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM surveys s
      WHERE s.id = questions.survey_id AND s.activa AND s.publicada
    )
  );
CREATE POLICY pol_questions_insert ON questions
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_questions_update ON questions
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_questions_delete ON questions
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_question_options_select ON question_options;
DROP POLICY IF EXISTS pol_question_options_insert ON question_options;
DROP POLICY IF EXISTS pol_question_options_update ON question_options;
DROP POLICY IF EXISTS pol_question_options_delete ON question_options;

CREATE POLICY pol_question_options_select ON question_options
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1
      FROM questions q
      JOIN surveys s ON s.id = q.survey_id
      WHERE q.id = question_options.question_id AND s.activa AND s.publicada
    )
  );
CREATE POLICY pol_question_options_insert ON question_options
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_question_options_update ON question_options
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_question_options_delete ON question_options
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- responses (M4/§7): el público ENVIA (INSERT); staff lee para minería;
-- el dueño (customer) lee sus respuestas. Editor no borra datos personales.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_responses_select ON responses;
DROP POLICY IF EXISTS pol_responses_insert ON responses;
DROP POLICY IF EXISTS pol_responses_update ON responses;
DROP POLICY IF EXISTS pol_responses_delete ON responses;

CREATE POLICY pol_responses_select ON responses
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = responses.customer_id AND public.is_auth(c.usuario_id)
    )
  );
CREATE POLICY pol_responses_insert ON responses
  FOR INSERT WITH CHECK (true);  -- público: enviar encuesta no requiere login (M4)
CREATE POLICY pol_responses_update ON responses
  FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());
CREATE POLICY pol_responses_delete ON responses
  -- ARCO-erase (§7): el borrado real es una decisión de la capa app/admin.
  FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_survey_assignments_select ON survey_assignments;
DROP POLICY IF EXISTS pol_survey_assignments_insert ON survey_assignments;
DROP POLICY IF EXISTS pol_survey_assignments_update ON survey_assignments;
DROP POLICY IF EXISTS pol_survey_assignments_delete ON survey_assignments;

CREATE POLICY pol_survey_assignments_select ON survey_assignments
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = survey_assignments.customer_id AND public.is_auth(c.usuario_id)
    )
  );
CREATE POLICY pol_survey_assignments_insert ON survey_assignments
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_survey_assignments_update ON survey_assignments
  FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_survey_assignments_delete ON survey_assignments
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- leads + interactions (M5 CRM): solo staff.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_leads_select ON leads;
DROP POLICY IF EXISTS pol_leads_insert ON leads;
DROP POLICY IF EXISTS pol_leads_update ON leads;
DROP POLICY IF EXISTS pol_leads_delete ON leads;

CREATE POLICY pol_leads_select   ON leads FOR SELECT USING (public.es_staff());
CREATE POLICY pol_leads_insert   ON leads FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_leads_update   ON leads FOR UPDATE USING (public.es_staff()) WITH CHECK (public.es_staff());
CREATE POLICY pol_leads_delete   ON leads FOR DELETE USING (public.es_admin());

DROP POLICY IF EXISTS pol_interactions_select ON interactions;
DROP POLICY IF EXISTS pol_interactions_insert ON interactions;
DROP POLICY IF EXISTS pol_interactions_update ON interactions;
DROP POLICY IF EXISTS pol_interactions_delete ON interactions;

CREATE POLICY pol_interactions_select ON interactions FOR SELECT USING (public.es_staff());
CREATE POLICY pol_interactions_insert ON interactions FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_interactions_update ON interactions FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());
CREATE POLICY pol_interactions_delete ON interactions FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- invoices (M5): dueño y staff leen; staff emite; admin corrige; super borra.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_invoices_select ON invoices;
DROP POLICY IF EXISTS pol_invoices_insert ON invoices;
DROP POLICY IF EXISTS pol_invoices_update ON invoices;
DROP POLICY IF EXISTS pol_invoices_delete ON invoices;

CREATE POLICY pol_invoices_select ON invoices
  FOR SELECT USING (
    public.es_staff()
    OR EXISTS (
      SELECT 1 FROM customers c
      WHERE c.id = invoices.customer_id AND public.is_auth(c.usuario_id)
    )
  );
CREATE POLICY pol_invoices_insert ON invoices
  FOR INSERT WITH CHECK (public.es_staff());
CREATE POLICY pol_invoices_update ON invoices
  FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());
CREATE POLICY pol_invoices_delete ON invoices
  FOR DELETE USING (public.es_super());

-- ----------------------------------------------------------------------------
-- audit_log (D7): append-only. Solo INSERT (staff) y SELECT (admin).
-- SIN políticas UPDATE/DELETE → inmutable para la aplicación.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_audit_log_select ON audit_log;
DROP POLICY IF EXISTS pol_audit_log_insert ON audit_log;

CREATE POLICY pol_audit_log_select ON audit_log FOR SELECT USING (public.es_admin());
CREATE POLICY pol_audit_log_insert ON audit_log FOR INSERT WITH CHECK (public.es_staff());
COMMENT ON POLICY pol_audit_log_insert ON audit_log IS 'D7: append-only. Inserta la capa servidor (service role/Express). Excepción única documentada: superusuario PostgreSQL con BYPASSRLS (ver docs/DB/README-DB.md).';

-- ----------------------------------------------------------------------------
-- site_config (§2): pública de lectura (paleta/textos/SEO del sitio);
-- solo admin escribe (branding M6).
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_site_config_select ON site_config;
DROP POLICY IF EXISTS pol_site_config_insert ON site_config;
DROP POLICY IF EXISTS pol_site_config_update ON site_config;

CREATE POLICY pol_site_config_select ON site_config FOR SELECT USING (true);
CREATE POLICY pol_site_config_insert ON site_config
  FOR INSERT WITH CHECK (public.es_admin());
CREATE POLICY pol_site_config_update ON site_config
  FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());

-- ----------------------------------------------------------------------------
-- email_templates (M6): plantillas funcionales de la app; staff lee,
-- admin escribe (M6 «plantillas editables»).
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_email_templates_select ON email_templates;
DROP POLICY IF EXISTS pol_email_templates_insert ON email_templates;
DROP POLICY IF EXISTS pol_email_templates_update ON email_templates;
DROP POLICY IF EXISTS pol_email_templates_delete ON email_templates;

CREATE POLICY pol_email_templates_select ON email_templates
  FOR SELECT USING (public.es_staff());
CREATE POLICY pol_email_templates_insert ON email_templates
  FOR INSERT WITH CHECK (public.es_admin());
CREATE POLICY pol_email_templates_update ON email_templates
  FOR UPDATE USING (public.es_admin()) WITH CHECK (public.es_admin());
CREATE POLICY pol_email_templates_delete ON email_templates
  FOR DELETE USING (public.es_admin());

-- ----------------------------------------------------------------------------
-- email_log (M6): operativo; admin.
-- ----------------------------------------------------------------------------

DROP POLICY IF EXISTS pol_email_log_select ON email_log;
DROP POLICY IF EXISTS pol_email_log_insert ON email_log;

CREATE POLICY pol_email_log_select ON email_log FOR SELECT USING (public.es_admin());
CREATE POLICY pol_email_log_insert ON email_log FOR INSERT WITH CHECK (public.es_staff());

-- ----------------------------------------------------------------------------
-- Fin 01_politicas.sql — continúa: db/seed.sql (datos demo, Fase 1).
-- ============================================================================
