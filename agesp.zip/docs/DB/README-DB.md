# README-DB — Guía de base de datos AGESP

Fase 1 · AGENTE-1 (Fundación DB). Idioma: español (D9). Fuente de verdad: `db/migrations/` + `db/rls/` (decisión **D10**).

## Orden de aplicación (siempre este orden)

1. `db/migrations/000_init.sql` — 18 tablas, pgcrypto, funciones puente/rol, triggers, audit_log append-only (D7).
2. `db/rls/00_funciones_puente.sql` — redefine funciones puente + `ENABLE ROW LEVEL SECURITY` en las 18 tablas.
3. `db/rls/01_politicas.sql` — políticas RLS por tabla y rol (super_admin/admin/editor/customer + público).
4. `db/seed.sql` — datos demo idempotentes (3 productos, 2 clientes, encuesta demo 4 preguntas, site_config, plantilla correo).

Atajo local: `npm run db:local:init` (script `scripts/db-local-init.cjs`) aplica 1→4 en orden.

## Entornos (decisión D2: dual Supabase / local)

### Supabase (camino crítico a producción)

- Proyecto remoto: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY` en `.env`.
- Migraciones: copia en `supabase/migrations/000_init.sql` → `supabase db push` (config en `supabase/config.toml`).
- RLS y seed: aplicar `db/rls/*.sql` y `db/seed.sql` desde el SQL Editor (el CLI local no es obligatorio).
- `auth.users` real: la FK `fk_profiles_auth_users` se crea sola (guard D11 en la migración).
- Conexión desde la app: adaptador `lib/db/supabaseClient.ts` (`NEXT_PUBLIC_DB_TARGET=supabase`).

### Local (paridad documentada — decisión D11: esta máquina sin Docker/psql)

- Levantar: `docker compose -f docker/docker-compose.yml up -d` (postgres:16 en **5433**, adminer en 8080; credenciales postgres/postgres, BD `agesp`).
- URL: `postgresql://postgres:postgres@localhost:5433/agesp` (idéntica a `.env.example`).
- Aplicar: `npm run db:local:init` (crea BD si falta y aplica 1→4).
- Conexión desde la app: adaptador `lib/db/localClient.ts` (`NEXT_PUBLIC_DB_TARGET=local`) con `SET LOCAL app.user_id` por transacción.
- `auth.users` no existe: el mock de la migración crea `auth.uid()` delegando en `current_user_id()` (GUC `app.user_id`).

**Nota D11:** en la máquina de desarrollo no hay Docker ni psql instalados, por lo que la ejecución
real del SQL queda **documentada y pendiente de verificación** en una máquina con Docker o en el
proyecto Supabase remoto. El orden y la idempotencia están verificados por revisión estática y por
el script de inicialización.

## Cifrado de `customers.tax_id_cifrado` (§7)

- pgcrypto: `encrypt_tax_id(texto)` / `decrypt_tax_id(dato)`.
- Clave: variable de sesión `app.tax_key`. **Producción:** fijar por conexión/transacción:
  `SELECT set_config('app.tax_key', $clave, true);`
- Desarrollo: si no se define, se usa la clave por defecto
  `AGESP-clave-fiscales-DESARROLLO-cambiar-en-produccion` (solo local/demo, **nunca** en producción).
- El texto claro del NIT/carné nunca se almacena ni se registra en `audit_log` (ver §7 del SDD).

## audit_log append-only (D7)

- Trigger `trg_audit_log_append_only` rechaza UPDATE/DELETE a nivel de tabla.
- RLS: solo `INSERT` (staff) y `SELECT` (admin); **sin** UPDATE ni DELETE.
- Única excepción asumida y documentada: un superusuario real de PostgreSQL (rol con BYPASSRLS,
  p. ej. `postgres`) podría saltarse el trigger; la aplicación jamás expone esa vía.

## Identidad dual (Supabase / local)

| Función | Supabase | Local |
|---|---|---|
| `usuario_actual()` | `auth.uid()` | GUC `app.user_id` (`SET LOCAL`) |
| `auth.uid()` | real | mock → `current_user_id()` |
| Roles | `profiles.rol` (super_admin/admin/editor/customer) | igual |

## Roles (M6) y semántica

- `super_admin`: todo, incluido cambiar roles y borrar facturas.
- `admin`: gestión completa del negocio (catálogo, pedidos, leads, plantillas de correo, auditoría).
- `editor`: staff operativo (catálogo, pedidos, CRM, insertar auditoría) sin borrados de administración.
- `customer`: solo sus propios clientes/pedidos/respuestas (vía `customers.usuario_id`).
- Anónimo (público): leer catálogo, leer encuestas publicadas, enviar respuestas.

## Mapa de archivos

```
db/
  migrations/000_init.sql      # fuente de verdad del DDL
  rls/00_funciones_puente.sql  # ENABLE RLS + funciones puente
  rls/01_politicas.sql         # políticas por tabla
  seed.sql                     # datos demo idempotentes
  schema.sql                   # SNAPSHOT generado (NO editar, D10)
  schema.md                    # mapa humano del esquema
docker/docker-compose.yml      # postgres:16 + adminer (puerto 5433)
supabase/config.toml           # CLI de Supabase
supabase/migrations/000_init.sql  # copia para `supabase db push`
```

## Verificación del checkpoint (qué haría Guillermo)

1. Con Docker disponible: `docker compose -f docker/docker-compose.yml up -d` + `npm run db:local:init` → sin errores.
2. Consultas de humo: `SELECT count(*) FROM products;` (3), `SELECT count(*) FROM customers;` (2),
   `SELECT count(*) FROM questions;` (4), `SELECT clave FROM site_config WHERE clave LIKE 'colors%';`.
3. Smoke de RLS: como anónimo `SELECT * FROM products` funciona; `SELECT * FROM audit_log` da 0 filas (sin permiso).
4. Smoke D7: `UPDATE audit_log SET accion='x';` → ERROR «append-only».
5. En Supabase remoto: `supabase db push` + aplicar `db/rls/*.sql` + `db/seed.sql` desde el SQL Editor.
