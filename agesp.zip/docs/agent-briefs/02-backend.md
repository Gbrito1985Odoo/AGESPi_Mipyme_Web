# Brief AGENTE-2 — Fase 2: Backend (lógica + paridad Deno/Node)

**Rol:** AGENTE-2. Lee primero `docs/SDD.md` (§3, §5 M2/M5, §7), el brief de la Fase 1
(`docs/agent-briefs/01-fundacion-db.md`) y el código existente: `lib/types/index.ts`,
`lib/db/*.ts`. Si `db/schema.sql` aún no existe, trabaja sobre `lib/types/index.ts`
como contrato de datos. Todo **en español** (decisión D9).

## Alcance

### 1. `/lib/business/*.ts` — lógica TypeScript pura (compartida Deno/Node/frontend)

- `cart.ts` — carrito: agregar/quitar/cantidades, totales por ítem y global, validación
  de moneda única por pedido (CUP/MLC/USD configurable, M2). Schemas Zod para las entradas.
- `orders.ts` — gestión de pedidos: crear desde carrito, confirmar, cancelar, estados.
  Al confirmar descuenta stock y emite alerta de bajo inventario (stock < stock_minimo).
- `inventory.ts` — consultas de inventario y alertas de bajo inventario (M5).
- `crm.ts` — leads, customers, pipeline e interacciones/notas (M5).
- `invoices.ts` — facturación: numeración secuencial por serie (transacción segura),
  datos fiscales, delegación de PDF (M5).
- `analytics.ts` — agregados de respuestas de encuestas: por pregunta, distribución de
  opciones, media/mediana (numérica/Likert), series temporales; acepta filtros (fecha,
  tipo entidad, respuesta — M4).
- `surveyLogic.ts` — saltos lógicos: dado `questions[].metadata.show_if` y respuestas
  parciales, devuelve qué preguntas mostrar (§8.2). Prueba el caso P6/P9.
- `qr.ts` — generación de QR con el paquete `qrcode` (PNG data-URL + SVG string) para
  `https://{dominio}/card/{uuid}` (M3).
- `email.ts` — render de plantillas con variables `{{clave}}` + envío con Resend.
  Lee `email_templates`, registra en `email_log`. Sin `RESEND_API_KEY`: estado
  "error" en email_log con detalle; nada crashea.
- `pdf.ts` — factura PDF con `pdf-lib`: numeración, datos fiscales, moneda del pago.
  Los colores de la marca llegan como parámetro (SDD §2: colores en PDFs, no hardcodear).
- `audit.ts` — registra acciones críticas (login, cambio de precio, export…).
- `payments.ts` — **interfaz `PaymentProvider` lista; implementación en TODO fase 2 (D1)**:
  stub que lanza Error("Pasarela de pago TODO fase 2").
- `arco.ts` — lógica de los derechos ARCO `/api/arco/{access,rectify,erase,oppose}` (§7).

Reglas: entrada validada con Zod, errores tipados, comentarios en español. Las funciones
no deben acoplarse a un adaptador concreto: reciben un repositorio (interfaz de acceso a
datos) como parámetro, o usan `lib/db` (el selector dinámico ya creado) cuando el contexto
es seguro.

### 2. Wrappers Deno — `/supabase/functions/{fn}/index.ts`

Para las 6 funciones (SDD §3.2): `generate-qr`, `send-email`, `calculate-analytics`,
`export-csv`, `generate-invoice-pdf`, `regenerate-qr`. Cada wrapper:

- Serve con `Deno.serve`; lee variables de entorno; SERVICE_ROLE solo donde se justifica
  (regenerate-qr / export-csv validar antes el rol admin).
- Rate limiting simple en memoria por IP (§7).
- CORS correcto y errores como JSON.
- Importa la lógica de `/lib/business` vía imports relativos; usa specifiers `npm:` para
  qrcode/pdf-lib/resend si es necesario (Deno 2 soporta npm).

### 3. Wrappers Node — `/server/local/routes/{fn}.ts` + `/server/local/index.ts`

- Express: mismas 6 funciones como routers; validación Zod, `helmet`, rate-limit
  (`express-rate-limit`, §7); CSRF token en rutas mutantes; cookies `SameSite=Strict`.
- `index.ts`: monta los routers bajo `/{fn}`, escucha en `PORT`, logs en español.
- Las rutas usan `lib/db/localClient.ts` y `setUserContext` (decodifican JWT propio con
  `jose` y `JWT_SECRET` para emular identidad → `app.user_id`).

### 4. `/app/api/regenerate-qr/route.ts` — endpoint protegido (M3)

- Route handler de Next que verifica dueño de la tarjeta o rol `admin|super_admin`.
  Rate limit + Zod. Devuelve el QR (PNG/SVG) o 401/403.

### 5. Tests Jest — `/tests/business/*.test.ts`

- Mínimo: `cart`, `orders`, `analytics`, `surveyLogic`, `qr`, `email` (con mocks del
  repositorio; sin red ni Postgres). Configura Jest (ts-jest) en `jest.config.js`.
- Verifica: totales del carrito, moneda única, saltos P6/P9 (§8.2), numeración secuencial
  de facturas con mocks, sanitización de HTML en render de plantillas.

### 6. `BACKEND-PARITY.md` (raíz)

- Matriz función × objetivo (Supabase/Deno | Local/Express): parámetros, rutas, cabeceras,
  variables env, rate limits, y en qué difieren (Storage vs filesystem, etc. — paridad
  documentada según D2).

### 7. `docs/presentaciones/presentacion-fase2.html`

Copia `docs/presentaciones/plantilla-fase.html` y llena: contexto, alcance entregado,
cómo verificar el checkpoint de Fase 2 («generate-qr y export-csv funcionan en ambos»:
comandos `npm run test` y resultado esperado), pendientes y handoff a Fase 3 (qué
funciones/casos de uso debe consumir el frontend).

## Restricciones

- No toques `/db` ni `app/` (excepción declarada: `/app/api/regenerate-qr/route.ts`).
  Si descubre una columna faltante, DOCUMENTA el hallazgo en la presentación de la fase.
- Mensajes de error y console.log en español.
- La clave de servicio nunca en el navegador.

## Entrega

Lista de archivos, matriz de paridad, nota de tests añadidos y de dependencias nuevas
si las agregaste a package.json.
