# Brief AGENTE-5/6 — Fase 5: QA + Deploy

**Rol:** AGENTE-5 + AGENTE-6. Lee `docs/SDD.md` (§6 fase 5, §7, §9, §D), los briefs 1–4 y
el código real del repo (todo lo escrito en las fases 1–4). Todo **en español** (D9).

## Alcance

### 1. Configuración de pruebas

- `jest.config.js` (+ setup si falta): unit tests de `/tests/business` (Fase 2).
- `playwright.config.ts`: proyectos chromium; baseURL configurable
  (`PLAYWRIGHT_BASE_URL`, por defecto `http://localhost:3000`); depende de que
  `npm run dev:local` esté corriendo (documentar: no arrancar servidores por el test
  si el entorno no lo permite).
- `.env` de ejemplo para Playwright si hace falta.

### 2. Pruebas E2E — `/tests/e2e/*.spec.ts` (Playwright)

- Flujos críticos del checkpoint de Fase 5 (SDD §6):

- Registro → QR → tarjeta navegable (M3; usa datos de prueba válidos con
  consentimiento marcado).
- Home carga y muestra servicios destacados + textos de `site_config` (M1).
- Tienda: añadir al carrito → crear pedido → pedido visible/estado pendiente (M2).
- Encuesta pública de la Fase 3 / 4.5: responder la demo y validar salto P6 si el
  fixture lo permite.

Deben correr contra una instancia real del sitio: si `dev:local` no puede correr en
esta máquina (falta PostgreSQL — decisión D11), los specs quedan SKIP con razón
razón clara en español y DOCUMENTA en TEST_REPORT.md cómo correrlos con BD disponible.
### 3. Tests RLS — `/tests/sql/rls/*.sql` (rol de AGENTE-6)

Scripts SQL ejecutables: crear usuario A y usuario B (con `app.user_id` en local /
`auth.uid()` en supabase), verificar que A no puede leer/editar filas de B en las
tablas con datos de usuario (customers, orders, order_items, responses, invoices),
que audit_log rechaza UPDATE/DELETE (append-only, D7), y la excepción de super_admin
documentada. Estructura: un archivo por caso con -- comentarios en español y
sentencias SELECT que fallan si el problema existe (o DO $$ RAISE). Documentar en
README-DB.md cómo correrlos (psql o db:local:init extendido).

### 4. `DEPLOY.md` (raíz)

- Camino crítico (D2): Supabase Cloud + Vercel: crear proyecto, correr
  `db:supabase:push` (migraciones → RLS → seed... explicar el orden), variables env
  exactas (§3.3), dominio + HTTPS obligatorio (§7), Storage bucket `agesp`,
  Resend (verificar dominio), Secret para JWT, WAF/CSP.
- Local (D2/D11): Docker (`docker/docker-compose.yml`) + `npm run db:local:init` +
  `npm run dev:local` + `npm run server:local`, con detalles de arranque.
- Cuadro de comandos y verificación post-despliegue (salud de `/`, registro, admin).

### 5. `CUMPLIMIENTO.md` (raíz)

- Checklist que mapea cada requisito de §7 a archivo/implementación y a un test:
  RLS (tablas + test rls), validación Zod, sanitización XSS/CSP/CSRF/SameSite,
  rate limiting, HTTPS, pgcrypto tax_id, audit append-only (D7), consentimiento
  (checkbox + consent_log), ARCO endpoints, Reporte Mincom (D8: **nota** con la
  fuente oficial de la Res. 58/2022 — no inventar formato; referencia a dónde se
  genera desde admin), marcos Ley 149 / Res. 35 / NC ISO 27001 / 25010.
- Marcar cada ítem como ✅ implementado / ⚠️ parcial / ⬜ pendiente con justificación.

### 6. `TEST_REPORT.md` (raíz)

- Estado REAL de ejecución en esta máquina (D11): qué tests corrieron (jest si es
  posible: instalar dependencias y ejecutar `npm run test` si el entorno lo permite),
  qué quedó bloqueado y por qué (sin PostgreSQL, sin credenciales Supabase), cómo
  reproducir y qué esperar.

### 7. `docs/presentaciones/presentacion-fase5.html`

Copia `plantilla-fase.html`: contexto, alcance, estado de los tests (verde/amarillo/
rojo con justificación D11), pendientes, handoff a la revisión final (AGENTE-7).

## Restricciones

- Puedes ejecutar `npm install` y `npm run test` (Node 22 está en esta máquina —
  recuerda: `C:\Program Files\nodejs` no está en PATH; añádelo al `PATH` del shell:
  `$env:Path = "C:\Program Files\nodejs;$env:Path"`).
- NO despliegues nada (no hay credenciales); solo documenta el proceso (D11).
- CÓrrige inconsistencias MAYORES que los tests destapen (bug fix mínimo) y
  regístralas en la presentación; si una corrección recae en fases previas,
  márcala claramente como hotfix.

## Entrega

Estado de cada suite (unit/e2e/rls), archivos config creados, estado de
DEPLOY/CUMPLIMIENTO/TEST_REPORT y pendientes.
