# Brief AGENTE-7 — Fase 6: Revisión final (informe del MVP)

**Rol:** AGENTE-7 (revisor independiente). No modifiques código salvo errores graves
(y si lo haces, márcalo explícitamente). Lee `docs/SDD.md` completo, los 5 briefs,
las 5 presentaciones de fase y TODA la estructura real del proyecto. Idioma: español.

## Alcance

Genera `REVISION-FINAL.md` (raíz) con:

1. **Cumplimiento del SDD** — matriz módulo (M1–M6) × requisito (§5) × archivo que lo
   implementa × estado (✅ / ⚠️ parcial / ⬜). Incluye los 18 requisitos extra de §7 y
   las decisiones §D (D1..D11).
2. **Métricas de calidad** — número de archivos por carpeta, líneas aproximadas,
   suites de tests y su estado, cobertura declarada si existe, dependencias en
   package.json (y versiones), puntos de riesgo técnico concretos (acoplamiento,
   SQL no idempotente, secretos expuestos, etc.).
3. **Riesgos y recomendaciones** — top 10 priorizados (impacto × esfuerzo).
4. **TODOs consolidados** — extrae de TODO.md + presentaciones + comentarios de código
   `TODO|FIXME|HACK`; grupo por fase 2 / mejoras / despliegue.
5. **Próximos pasos** — plan corto para la semana siguiente (despliegue real,
   credenciales, validación de la Res. 58/2022 con Mincom, pilotaje con usuarios…).
6. **Veredicto del checkpoint final** — ¿el MVP es entregable end-to-end según el plan?
   Justificar con evidencia de archivos.

## Entregable adicional

`docs/presentaciones/presentacion-fase6.html` — copia la plantilla y resume el informe
(con el veredicto y el top 10 de riesgos como secciones principales).

## Restricciones

- Todo con evidencia: ruta de archivo + qué línea/sección respalda la afirmación.
- Sin inventar: si algo no está implementado, márcalo ⬜ y explícalo (SDD D11 permite
  que la verificación de despliegue quede pendiente de credenciales).
