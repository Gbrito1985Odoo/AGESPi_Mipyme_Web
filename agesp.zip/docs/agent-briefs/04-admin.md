# Brief AGENTE-4 — Fase 4 + Fase 4.5: Panel admin y encuesta AGESP

**Rol:** AGENTE-4. Lee `docs/SDD.md` (§2, §5 M4/M5/M6, §7, §8 — especialmente la
encuesta integrada), y el código existente: `lib/types/`, `lib/db/`, `lib/business/`
(su API pública: orders, invoices, analytics, surveyLogic, qr, email, audit, arco),
`app/(public)/` (Fase 3 — claves de `site_config` usadas), `lib/site/theme.ts`.
Todo **en español** (D9).

## ALCANCE FASE 4 — Panel `app/admin/`

### Autenticación + roles (M6)

- `app/admin/login/page.tsx` — login con Supabase Auth (target supabase) o JWT local
  vía Express (target local — paridad documentada, D2/D10). Roles:
  `super_admin, admin, editor, customer`.
- **MFA TOTP obligatorio para `super_admin` (decisión D3 y SDD M6)**: flujo de
  enrolamiento (muestra QR TOTP y verifica el código en el primer login) + verificación
  del factor en cada login de super_admin. Con Supabase usa su módulo MFA (factors);
  en local, librería TOTP (p. ej. `otpauth` — agregar dependencia), documentado.
- Recuperación de contraseña (correo con plantilla `recuperar_password`).
- Guard de rutas admin (middleware o layout): roles válidos, redirect a login.
- Audit: registrar login, cambio de precio, export, etc. vía `lib/business/audit.ts`.

### CRUD de productos (M2)

- `app/admin/productos/page.tsx` — tabla productos + crear/editar/eliminar.
- Campos: codigo, nombre, descripcion, precio, moneda, unidad, disponible,
  tiempo_entrega, destacado, categoria, stock, stock_minimo.
- Carga de imagen a Supabase Storage (bucket `agesp`) en supabase; en local, si no
  hay Storage, guarda URL o archivo local. Validación Zod.
- Cambio de precio → registra en audit_log (M6).

### Constructor de encuestas (M4)

- `app/admin/encuestas/page.tsx` — lista encuestas.
- Constructor: crear encuesta + preguntas dinámicas con todos los tipos de SDD
  (texto, selección, selección múltiple, Likert, escala, fecha, numérica, sí/no),
  secciones, metadata → show_if (constructor de salto lógico simple con UI),
  opciones ordenadas. Guardar en tablas surveys/questions/question_options.
- Asignación: `survey_assignments` a entidades registradas (customers) + token público.
- Validar el caso de saltos del §8.2 en la vista previa.

### Panel de respuestas + minería (M4)

- `app/admin/encuestas/[id]/respuestas/page.tsx` — tabla de respuestas con filtros
  (fecha, tipo de entidad, respuesta concretos), gráficos (recharts) por pregunta,
  agregados (usar `lib/business/analytics.ts`), export CSV (via función
  `export-csv`, registrar en audit_log).

### Branding + plantillas de correo (M6)

- `app/admin/branding/page.tsx` — edición de `site_config`: logo (subida o URL),
  favicon, colores (paleta), textos de páginas y meta SEO (title/description de Fase 3).
  TODO con Zod + audit_log.
- `app/admin/correos/page.tsx` — CRUD de `email_templates` (clave, asunto, HTML,
  variables listadas/emisiones añadidas).

### Métricas dashboard (M6)

- `app/admin/page.tsx` (panel raíz) — tarjetas con métricas: pedidos, ventas por
  moneda, productos con stock bajo, leads por pipeline, respuestas recentes, logs.
- `lib/business/analytics.ts` admite agregados. Gráficos con recharts.

### Derechos ARCO + Reporte Mincom

- API routes UI: interfaz en admin para atender solicitudes ARCO
  (la API `app/api/arco/[accion]/route.ts` ya debería existir de Fase 2 — ajusta si falta).
- Generador del **Reporte Mincom (Res. 58/2022)** en admin: botón que produce un
  HTML/CSV genérico (decisión D8: NO inventar formato; deja nota en CUMPLIMIENTO.md).

## ALCANCE FASE 4.5 — Encuesta integrada AGESP (SDD §8, decisión D5)

- `db/migrations/002_encuesta_agesp.sql` (idempotente) + SQL de seed incluido:
  - `surveys` → 1 registro: «¿Cómo podemos ayudarle a sentirse más seguro?»
  - `questions` → 20 filas + fila de consentimiento, por secciones (§8.1):
    0=Sí/no consent · 1–4: Empresa y rol (texto/selección/rango) · 5–8: seguridad
    física actual · 9–10: intereses + urgencia · 11–13: ciberseguridad (escala + multi) ·
    14–15: sistemas facilitadores / IA (multi) · 16: áreas de interés general (multi) ·
    17–20: encuentro comercial y contacto (selección + texto opcional).
  - `question_options` → opciones por pregunta (escalas «Sí / Tal vez / No / No sé»).
  - Redacta las 20 preguntas EN ESPAÑOL siguiendo §8.2: términos explicados entre
    paréntesis (CCTV, SOC, backup, señalética, firma digital), mensaje inicial
    «No hay respuestas correctas ni incorrectas», contacto y dirección opcionales,
    solo visibles en la sección final.
  - Saltos: `questions.metadata` JSON con `show_if` (p. ej. si no tiene personal de
    seguridad → ocultar P6; si no tiene medios técnicos → mostrar P9 igualmente).
- Verifica que el constructor de la Fase 4 guarda estos saltos y que la encuesta es
  rellenable desde el flujo público de la Fase 3 (prueba el salto P6).

## Entregables HTML

- `docs/presentaciones/presentacion-fase4.html` — checkpoint: crear producto + encuesta +
  ver respuestas + export CSV; incluye Fase 4.5 (carga de encuesta AGESP + test de P6).
- Puedes generar una única presentación que cubra Fase 4 + 4.5, con ambas secciones claras.

## Restricciones

- No reescribas Fase 3: reutiliza sus componentes (`/components`).
- Excepción de audit_log: queda documentada (D7: solo `super_admin`).
- Reporte Mincom sin formato inventado (D8).

## Entrega

Lista de páginas y componentes admin, cambios en `/db` (migración encuesta),
dependencias añadidas si las haya, y estado de los 4 casos del checkpoint.
