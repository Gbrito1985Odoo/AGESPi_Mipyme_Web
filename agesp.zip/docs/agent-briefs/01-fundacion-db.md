# Brief AGENTE-1 — Fase 1: Fundación (Base de datos)

**Rol:** AGENTE-1 (DB) en la Plataforma Web AGESP. Lee primero `docs/SDD.md` (todas sus
secciones, especialmente §4, §7, §9/§D) y el árbol de carpetas (§10). Todo el SQL, los
comentarios y los documentos van **en español** (decisión D9).

## Alcance

1. **`db/schema.sql`** — snapshot canónico idempotente (IF NOT EXISTS) con las 18 tablas
   (SDD §4.2): `profiles, customers, products, categories, orders, order_items, surveys,
   questions, question_options, responses, leads, interactions, invoices, audit_log,
   site_config, email_templates, email_log, survey_assignments`. Deriva las columnas de
   los requisitos §5 con criterio de trazabilidad (p. ej. `products`: codigo, nombre,
   descripcion, imagen_url, precio, moneda CUP/MLC/USD, unidad, disponible,
   tiempo_entrega (Art. 5 Res. 35/2020), destacado, stock, stock_minimo, categoria_id,
   timestamps). Los tipos deben coincidir con `lib/types/index.ts` (ya creado) — ajústalos
   a la realidad SQL (now(), jsonb, timestamptz, uuid).
   - `customers.tax_id` cifrado con **pgcrypto** (columna `tax_id_cifrado` + helper
     `encrypt_tax_id()/decrypt_tax_id()` o función de encriptado en el INSERT).
   - Además de las 18 tablas: habilita `pgcrypto`. NOTA: auth de Supabase provee
     `auth.users` — en snapshot local crea si no existe un esquema mock para portabilidad
     (ver README-DB).
2. **`db/migrations/001_fundacion.sql`** — migración inicial versionada (fuente de verdad, D10).
   Crea las mismas tablas/objetos que el snapshot.
3. **`db/rls/*.sql`** — políticas RLS para TODAS las tablas (SDD §7), separadas por target:
   - Target supabase: usa `auth.uid()` (wrapper `is_auth()`).
   - Target local: usa `current_user_id()` que lee `current_setting('app.user_id', true)`
     (el cliente local hace `SET LOCAL app.user_id`, ver `lib/db/localClient.ts`).
   - Guard clause: `DO $$ BEGIN IF (objeto existe) THEN ... END IF; END $$;` para que
     correr las dos variantes no rompa.
   - Roles: `super_admin, admin, editor, customer` vía columna `rol` en `profiles` y
     función `rol_actual()`. `customer` solo ve/edita SUS rows (customers, orders,
     responses); `editor` gestiona productos/surveys; `admin` todo excepto
     super-admin-only; `super_admin` todo (excepción audit_log).
   - **audit_log append-only (D7):** tabla sin UPDATE/DELETE por INSERT-only + trigger.
     Excepción documentada: solo `super_admin` podría saltarlo — regístralo en un
     comentario SQL y en README-DB.
4. **`db/seed.sql`** — idempotente: 3 productos, 2 clientes demo, 1 encuesta demo de
   4 preguntas (+ opciones), `site_config` con la paleta diplomática y textos de hero
   (SDD §2), `email_templates` mínimo ("bienvenida_qr"). **NO incluye la encuesta AGESP
   de 20 preguntas** (esa es Fase 4.5, D5).
5. **`db/schema.md`** — tabla por tabla: propósito, columnas (nombre, tipo, nulidad,
   propósito), relaciones y trazabilidad hacia los módulos §5. Es un entregable para el
   checkpoint (hallazgo 4/D4).
6. **`docker/docker-compose.yml`** — `postgres:16` + `adminer` (SDD §3.3). Puertos
   consistentes con `.env.example` (5433).
7. **`supabase/config.toml`** mínimo + `supabase/migrations/` — copia de
   `db/migrations/00*.sql` para `supabase db push`. Documenta la regla anti-drift (D10)
   en README-DB.
8. **`README-DB.md`** — cómo correr en cada target (`npm run db:local:init`,
   `npm run db:supabase:push`), reglas D7/D10, puente de identidad, cifrado tax_id, y la excepción documentada de audit_log. Script existente ya
   configurado: usa `scripts/db-local-init.cjs` (aplica migrations → rls → seed).
9. **`presentaciones/presentacion-fase1.html`** (en `docs/presentaciones/`) — copia
   `plantilla-fase.html` y llena: contexto, alcance entregado, cómo verificar
   (comandos), pendientes, handoff a Fase 2 (contratos: tabla/campo ↔ lib/types).

## Restricciones

- SQL idempotente; sin dependencias externas fuera de `pgcrypto`.
- No toques `app/`, `lib/`, `server/`, `supabase/functions/` (fases 2–4).
- Coherencia total con `lib/types/index.ts` (los nombres de columna en snake_case
  corresponden a los campos camelCase del tipo; documenta el mapeo en schema.md).
- No hay PostgreSQL ni Docker en esta máquina (D11): la verificación real queda
  documentada; puedes validar sintaxis SQL manualmente.

## Entrega

Lista final de archivos creados, resumen de decisiones de columnas y aviso de que
presentacion-fase1.html está lista para el checkpoint de Guillermo.
