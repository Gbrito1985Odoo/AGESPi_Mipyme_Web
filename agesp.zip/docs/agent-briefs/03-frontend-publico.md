# Brief AGENTE-3 — Fase 3: Frontend público (M1–M3 + encuesta pública)

**Rol:** AGENTE-3. Lee `docs/SDD.md` (§2, §5 M1–M4, §7), el breve de Fase 1 y 2, y el código
existente (`lib/types/index.ts`, `lib/db/index.ts`, `lib/site/theme.ts`, `app/layout.tsx`,
`lib/business/` — API pública de cada módulo). Todo **en español** (D9).

## Alcance — árbol `app/(public)/` + `components/`

### M1 — Home / Vitrina (objetivo principal del negocio)

- `app/(public)/page.tsx` — Home: hero con la propuesta de valor + CTAs «Ver servicios» /
  «Registrarse»; grid de servicios/productos destacados desde la BD (destacado=true);
  secciones «quiénes somos», «servicios», «contacto», «cómo comprar».
- TODOS los textos editables en `site_config` (tabla clave/valor jsonb): componer un
  helper `lib/site/content.ts` con nombres de claves + helper `getContenido(clave, default)`;
  muestra claro el cómo se edita desde admin (Fase 4).
- **Regla dura (§2):** todos los colores vienen de `site_config` (paleta) y se aplican vía
  `applySiteConfig` de `lib/site/theme.ts` (variables CSS). Rehacer `app/layout.tsx` para
  que lea la paleta server-side y la inyecte en `<html style>`. El placeholder SVG del
  escudo (logo editable) como componente `components/Logo.tsx`.

### M2 — Tienda online

- `app/(public)/tienda/page.tsx` — catálogo: nombre, ID (codigo), foto, precio, unidad,
  disponibilidad, descripción y tiempo de entrega visible (Art. 5 Res. 35/2020).
  Muestra también moneda y stock.
- `app/(public)/producto/[codigo]/page.tsx` — ficha de producto + botón añadir al carrito.
- **Carrito** — estado en cliente (`lib/cart-client.ts` o localStorage simple), página
  `app/(public)/carrito/page.tsx`: editar cantidades, totales, crear pedido (usar
  `lib/business/orders.ts` vía API route o server action).
- API routes: `app/api/orders/route.ts` (POST crear pedido) según `lib/business`.
- Moneda configurable (CUP/MLC/USD) desde `site_config`.
- Pasarela de pago: NO implementar; en el paso de confirmación mostrar un aviso de que
  el pago se coordinará fuera de línea (TODO fase 2, D1) y referenciar `PaymentProvider`.

### M3 — Directorio de clientes + tarjeta QR

- `app/(public)/registro/page.tsx` — formulario con: nombre, tipo entidad, carné/NIT,
  domicilio, código postal, teléfono, correo, credencial + **checkbox de consentimiento
  explícito** (§7) obligatorio. Validación **Zod** cliente + servidor. API
  `app/api/register/route.ts`: hash seguro, UUID público, guarda cifrado; dispara el
  envío del correo de bienvenida con QR (plantilla `bienvenida_qr`,
  `lib/business/email.ts`) e imprime el QR para descargar.
- `app/(public)/card/[uuid]/page.tsx` — tarjeta pública: datos de la entidad, logo,
  colores de `site_config`, campos configurables; QR PNG y SVG descargables.
- `/api/regenerate-qr` ya construido en Fase 2: conéctalo con la UI (botón en la tarjeta),
  visible solo para el dueño (guarda tu UUID en localStorage tras el registro).

### Encuesta pública (M4, parte pública)

- `app/(public)/encuesta/[token]/page.tsx` y `/encuesta/page.tsx` (por id de encuesta en
  principio el token para asignaciones y directo para públicas).
- Navegación por secciones con saltos lógicos: usa `lib/business/surveyLogic.ts` leyendo
  `questions.metadata.show_if` (§8.2). Multi-selección, escalas, guardado de progreso en
  localStorage, campos de contacto solo visibles al final, y envío vía
  `app/api/surveys/submit/route.ts` (Zod + consent_log).

### SEO dinámico + seguridad

- `metadata`/`generateMetadata` en cada página pública: título y descripción desde
  `site_config` (M6 branding incluye meta SEO).
- `app/sitemap.ts` + `app/robots.ts` dinámicos con las rutas del sitio.
- `middleware.ts` — CSP estricta (script-src 'self' + nonce si hace falta,
  frame-ancestors 'none'), cabeceras de seguridad y rate limit básico en rutas API.
- Sanitizar TODO contenido editable (XSS, §7).

### Requisitos de diseño

- Tailwind con los tokens de `tailwind.config.ts` (primary/accent/secondary/muted/surface).
  Inter fuente (imports). Diseño limpio, sobrio, diplomático.
- Accesibilidad: labels, focus visible, contraste AA.
- Responsive global.

### Entregable HTML de la fase

`docs/presentaciones/presentacion-fase3.html` — copia `plantilla-fase.html` y llena:
contexto, alcance (M1–M3 + encuesta pública), cómo verificar el checkpoint
(«flujo registro → QR → tarjeta navegable» — pasos concretos + comando `npm run dev:local`),
pendientes, handoff a Fase 4 (claves de `site_config` usadas; flujos API disponibles).

## Restricciones

- No toques `/admin` (Fase 4) ni `/db` ni `lib/business` (excepto error fixes).
- Si te falta algo del backend (una función `lib/business` con otro nombre de archivo
  etc.), crea UNA nota clara en la presentación y mocks temporales — no reinventar.

## Entrega

Lista de páginas creadas, decisiones clave de contenido (`site_config` claves),
estado de flujos verificables y pendientes concretos.
