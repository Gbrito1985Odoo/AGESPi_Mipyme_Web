# SDD — Plataforma Web AGESP (documento fuente consolidado)

> Este archivo es la especificación autoritativa del proyecto. Fue extraído del documento
> `Promt Omni Plan MPYME AGESP.docx` y conserva íntegro su alcance. Al final incluye la
> sección **D (Decisiones)** con las decisiones adoptadas sobre los 10 hallazgos.

## 1. Resumen ejecutivo

| Campo | Valor |
|---|---|
| Cliente | AGESP (Mipyme Estatal Socialista) |
| Producto | Plataforma web B2B/B2C de vitrina + tienda + ERP/CRM + encuestas |
| Objetivo de negocio | Visualizar y comercializar los servicios de AGESP |
| MVP | End-to-end funcional |
| Modo | Por fases con checkpoint de Guillermo entre cada una |
| Ejecución | Orquestador + 7 sub-agentes secuenciales |
| Doble despliegue | Supabase Cloud + Vercel / PostgreSQL local + Node |
| Entregable por fase | Bloque funcional + presentación HTML para el supervisor |

## 2. Identidad visual (obligatoria, no hardcodeada)

Paleta «diplomática» por defecto (editable desde admin → `site_config` en runtime):

| Rol | Color | Hex |
|---|---|---|
| Primario / headers / CTA | Azul diplomático | `#0B2E59` |
| Fondo / contraste | Blanco | `#FFFFFF` |
| Texto secundario / bordes | Gris diplomático | `#4A5568` |
| Fondos suaves | Gris claro | `#E2E8F0` |
| Acento / badges / precios | Amarillo | `#F4C430` |

- Tipografía: sans-serif legible (Inter o similar).
- Logo: placeholder SVG editable (escudo simple), reemplazable desde admin.
- Aplicación obligatoria en: Tailwind config, tarjetas QR, PDFs de factura, plantillas de correo.
- **Regla dura: no hardcodear colores → leer de `site_config` en runtime.**

## 3. Arquitectura técnica

### 3.1 Stack

- Frontend: Next.js 14 (App Router), TypeScript, TailwindCSS.
- Backend lógica: TypeScript puro en `/lib/business/*.ts` (compartida).
- Adaptadores DB: `supabaseClient.ts` (Supabase JS) / `localClient.ts` (pg con Pool). Selección vía `NEXT_PUBLIC_DB_TARGET=supabase|local`.
- Wrappers backend:
  - Deno + Supabase → `/supabase/functions/{fn}/index.ts`
  - Node Express + pg → `/server/local/routes/{fn}.ts`
- Storage: Supabase Storage (imágenes de producto, logo).
- Email: Resend (`RESEND_API_KEY`).

### 3.2 Funciones backend requeridas (paridad dual)

`generate-qr` · `send-email` · `calculate-analytics` · `export-csv` · `generate-invoice-pdf` · `regenerate-qr`

### 3.3 Variables de entorno

- Supabase: `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_ROLE_KEY`, `RESEND_API_KEY`
- Local: `DATABASE_URL`, `JWT_SECRET`, `RESEND_API_KEY`
- Docker (opcional): `postgres:16` + adminer

### 3.4 Scripts npm

```
db:supabase:push   → supabase db push
db:local:init      → aplica db/migrations/*.sql + db/rls/*.sql + db/seed.sql contra DATABASE_URL
dev:supabase       → next dev (target supabase)
dev:local          → next dev (target local)
deploy:vercel      → npx vercel --prod
```

## 4. Modelo de datos (portable)

### 4.1 Reglas

- Un solo esquema canónico: `/db/schema.sql` idempotente (IF NOT EXISTS).
- Migraciones versionadas: `/db/migrations/NNN_descripcion.sql`.
- RLS separado: `/db/rls/*.sql` con guard clause `DO $$ ... END $$` según target.
- Puente de identidad:
  - Supabase → wrapper sobre `auth.uid()`
  - Local → `current_user_id()` emulando `app.user_id`
- Cifrado: pgcrypto para `customers.tax_id`.
- Seed de arranque `/db/seed.sql`: 3 productos, 2 clientes demo, 1 encuesta de 4 preguntas, `site_config` con paleta.

### 4.2 Tablas mínimas (18)

`profiles` · `customers` · `products` · `categories` · `orders` · `order_items` · `surveys` · `questions` · `question_options` · `responses` · `leads` · `interactions` · `invoices` · `audit_log` · `site_config` · `email_templates` · `email_log` · `survey_assignments`

Nota: las columnas no vienen definidas por tabla; se derivan de los requisitos funcionales (§5) con criterio de trazabilidad.

## 5. Requisitos funcionales (6 módulos MVP)

### M1 — Home / Vitrina de servicios (objetivo principal del negocio)

- Hero con propuesta de valor, CTA «Ver servicios» / «Registrarse».
- Grid de productos/servicios destacados desde BD.
- Secciones: quiénes somos, servicios, contacto, cómo comprar.
- Todo el texto editable desde `site_config`.

### M2 — Tienda online

- Catálogo con: nombre, ID, foto, precio, unidad, disponibilidad, descripción, tiempo de entrega (Art. 5 Res. 35/2020).
- Carrito + gestión de pedidos + moneda configurable (CUP/MLC/USD).
- CRUD de productos desde admin con carga a Storage.
- Pasarela de pago (Transfermóvil/EnZona): TODO fase 2, pero con `PaymentProvider` interface lista.

### M3 — Directorio de clientes + tarjetas QR

- Registro: nombre, carné/NIT (cifrado), domicilio, código postal, teléfono, correo, credencial.
- Al registrar → UUID único → `https://{dominio}/card/{uuid}` → QR PNG+SVG descargable → correo con plantilla editable.
- Tarjeta pública personalizable (logo, colores, campos visibles).
- Endpoint `/api/regenerate-qr` protegido (dueño o admin).

### M4 — Encuestas dinámicas + minería

- Constructor admin: texto, selección múltiple, Likert, fecha, numérica, sí/no.
- Asignación a entidades registradas.
- Panel admin con filtros (fecha, tipo entidad, respuesta), gráficos, agregados SQL/Edge, export CSV/JSON.

### M5 — ERP/CRM backend

- Inventario con stock y alertas de bajo inventario.
- CRM: leads, customers, pipeline, historial, notas.
- Facturación PDF con numeración secuencial, datos fiscales y moneda del pago.

### M6 — Panel admin

- Roles: `super_admin`, `admin`, `editor`, `customer` (RLS).
- MFA TOTP obligatorio para super_admin + recuperación de contraseña.
- Branding editable (logo, favicon, colores, textos, meta SEO).
- Plantillas de correo editables (asunto, HTML, variables).
- Audit log de acciones críticas (login, cambio de precio, export).
- Métricas dashboard.

## 6. Agentes y fases (secuenciales con handoff)

| Fase | Agente(s) | Alcance | Checkpoint |
|---|---|---|---|
| 1. Fundación | AGENTE-1 (DB) + AGENTE-5 (parcial) | schema, migraciones, RLS, seed, docker-compose, README-DB | Schema corre en ambos targets sin error |
| 2. Backend | AGENTE-2 | `/lib/business/*.ts` + tests, wrappers Deno y Node, BACKEND-PARITY.md | generate-qr y export-csv funcionan en ambos |
| 3. Frontend público | AGENTE-3 | Home, tienda, producto, registro, `/card/{uuid}`, encuesta pública, SEO dinámico | Flujo registro → QR → tarjeta navegable |
| 4. Admin | AGENTE-4 | CRUD productos, constructor encuestas, panel respuestas + minería, branding, email templates, roles, audit log | Crear producto + encuesta + ver respuestas + export CSV |
| 5. QA + Deploy | AGENTE-5 + AGENTE-6 | Jest + Playwright E2E, tests RLS, DEPLOY.md, CUMPLIMIENTO.md, TEST_REPORT.md | E2E verde en local y en Vercel |
| 6. Review | AGENTE-7 | Informe final: riesgos, TODOs, próximos pasos, métricas de calidad | MVP end-to-end entregado |

Regla de orquestación: cada agente entrega bloque → checkpoint de Guillermo → solo si pasa, se lanza el siguiente. Handoff documentado al final de cada fase.

## 7. Seguridad y cumplimiento

- RLS en todas las tablas (verificado con test usuario A ≠ usuario B).
- Validación Zod en cliente y servidor.
- Sanitización XSS, CSP estricta, CSRF tokens, SameSite=Strict.
- Rate limiting en Edge Functions y rutas Express.
- HTTPS obligatorio en producción.
- Cifrado en reposo pgcrypto para `tax_id`.
- Audit log append-only (trigger + tabla sin UPDATE/DELETE).
- Consentimiento explícito en registro (checkbox + log de aceptación).
- Derechos ARCO: endpoints `/api/arco/{access|rectify|erase|oppose}`.
- Reporte Mincom (Res. 58/2022) generable desde admin.
- Checklist CUMPLIMIENTO.md mapeando cada requisito a archivo/test.
- Marcos de referencia: Ley 149, Res. 35, NC ISO 27001 / 25010.

## 8. Encuesta integrada «¿Cómo podemos ayudarle a sentirse más seguro?»

Ubicación: entregable adicional al cierre del plan (Fase 4 o posterior, encaja con el constructor de encuestas del M4).

### 8.1 Estructura (20 preguntas / 7 secciones)

| Sección | Preguntas | Tipo |
|---|---|---|
| Consentimiento | 0 (acepto / no) | Sí/no |
| 1. Empresa y rol | 1–4 | Texto, selección, rango |
| 2. Seguridad física actual | 5–8 | Selección / multi |
| 3. Intereses seguridad física | 9–10 | Multi + urgencia |
| 4. Ciberseguridad y digital | 11–13 | Escala + multi |
| 5. Sistemas facilitadores / IA | 14–15 | Multi |
| 6. Áreas de interés general | 16 | Multi |
| 7. Encuentro comercial y contacto | 17–20 | Selección + texto opcional |

### 8.2 Reglas de implementación

- Lógica de salto: si no tiene personal de seguridad → ocultar P6; si no tiene medios técnicos → mostrar igualmente P9.
- Escalas simples: Sí / Tal vez / No / No sé.
- Términos explicados entre paréntesis (CCTV, SOC, backup, señalética, firma digital).
- Datos de contacto y dirección opcionales.
- Mensaje inicial: «No hay respuestas correctas ni incorrectas».
- Digital: multi-selección, guardado de progreso, campos de contacto visibles solo en sección final.

### 8.3 Mapeo al modelo de datos

- `surveys` → 1 registro (encuesta AGESP)
- `questions` → 20 filas + consentimiento
- `question_options` → opciones por pregunta
- `responses` → 1 fila por encuesta enviada (con consent_log)
- `survey_assignments` → asignación a entidades registradas
- Saltos lógicos → a nivel de `questions.metadata` (JSON con `show_if`)

## 9. Hallazgos y riesgos (revisión crítica del plan)

1. Plazo agresivo → declarar explícitamente qué cae a TODO de fase 2 (pasarela de pago ya está ahí).
2. Doble despliegue en MVP duplica QA → Vercel+Supabase como camino crítico, local como «paridad documentada».
3. MFA TOTP requisito duro sin fase explícita → asignar formalmente a AGENTE-4 o TODO.
4. Columnas de 18 tablas no definidas → AGENTE-1 las deriva; checkpoint Fase 1 incluye revisión de schema.md.
5. Encuesta integrada = entregable no listado en fases → Fase 4.5 (o dentro del checkpoint de Fase 4): cargar encuesta AGESP vía seed y validar saltos con P6.
6. Presentación HTML por fase → entregable formal con plantilla común (contexto, alcance entregado, demo/screenshots, pendientes, handoff).
7. audit_log append-only + RLS → riesgo: super_admin podría saltar RLS. Documentar excepción explícita.
8. Reporte Mincom (Res. 58/2022) sin formato → nota en CUMPLIMIENTO.md con fuente oficial; no inventar formato.
9. Idioma: UI y comentarios en español; no desviar a inglés en logs.
10. schema.sql «canónico» vs migraciones → riesgo de drift. Regla: **migraciones = fuente de verdad; schema.sql = snapshot**. Documentar en README-DB.md.

## D. Decisiones adoptadas para la ejecución

| # | Hallazgo | Decisión |
|---|---|---|
| D1 | 1 | TODO.md de fase 2: pasarela de pago (Transfermóvil/EnZona) con `PaymentProvider` implementada como interfaz lista; el flujo crítico MVP no depende de pagos. |
| D2 | 2 | Camino crítico: Supabase Cloud + Vercel. Local (PostgreSQL + Express) es paridad documentada y no bloquea checkpoints. |
| D3 | 3 | MFA TOTP para super_admin se asigna formalmente a AGENTE-4 (Flujo con Supabase MFA; fallback local documentado). |
| D4 | 4 | Columnas derivadas por AGENTE-1; se publica `schema.md` para el checkpoint. |
| D5 | 5 | Encuesta AGESP (20 preguntas / 7 secciones) se carga en Fase 4.5 vía `db/migrations` + seed; validación de saltos con P6. El seed de Fase 1 incluye solo la encuesta demo de 4 preguntas. |
| D6 | 6 | Existe `docs/presentaciones/plantilla-fase.html`; cada fase genera `presentacion-fase{N}.html` con esa plantilla. |
| D7 | 7 | `audit_log` append-only: trigger que rechaza UPDATE/DELETE; excepción única y documentada para `super_admin`. |
| D8 | 8 | CUMPLIMIENTO.md documenta la fuente oficial de la Res. 58/2022 y una nota «formato pendiente de validación con Mincom»; no se inventa formato. |
| D9 | 9 | Toda UI, comentarios, mensajes de error y logs en español. |
| D10 | 10 | Migraciones versionadas = fuente de verdad; `schema.sql` es snapshot regenerable. |
| D11 | Entorno | Sin credenciales de Supabase ni PostgreSQL/Docker local en esta máquina: la verificación real (push a Supabase, E2E verde) queda como paso de despliegue documentado en DEPLOY.md / TEST_REPORT.md. Node 22 + Git disponibles; psql y docker no instalados. |
