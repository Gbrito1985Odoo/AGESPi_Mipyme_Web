# Plataforma Web AGESP

Web B2B/B2C de vitrina + tienda + ERP/CRM + encuestas para la AGESP
(Mipyme Estatal Socialista). Especificación: **`docs/SDD.md`** (fuente autoritativa).

## Arranque rápido

```bash
npm install

# Supabase (camino crítico, D2)
cp .env.example .env.local   # completar claves de Supabase
npm run db:supabase:push
npm run dev:supabase

# Local PostgreSQL (paridad documentada, D2/D11)
docker compose -f docker/docker-compose.yml up -d
npm run db:local:init
npm run dev:local            # Next.js
npm run server:local         # Express wrappers (paridad de funciones backend)
```

## Mapa del repo

| Carpeta/archivo | Contenido |
|---|---|
| `app/(public)/` | Home, tienda, producto, registro, `/card/{uuid}`, encuesta pública |
| `app/admin/` | Panel admin (productos, encuestas, respuestas, branding, roles…) |
| `components/` | Componentes públicos y admin |
| `lib/business/` | Lógica TypeScript pura (compartida Deno/Node/frontend) |
| `lib/db/` | Adaptadores: `supabaseClient.ts` / `localClient.ts` / selector `index.ts` |
| `lib/types/` | Contratos de dominio (18 tablas) |
| `db/` | `schema.sql` (snapshot), `migrations/` (fuente de verdad), `rls/`, `seed.sql` |
| `supabase/` | `functions/` (wrappers Deno), `migrations/` (para `supabase db push`) |
| `server/local/` | Wrappers Express de las 6 funciones backend |
| `docker/` | `docker-compose.yml` (postgres:16 + adminer) |
| `scripts/` | `db-local-init.cjs` (aplica migrations → rls → seed) |
| `tests/` | Jest (unit business) + Playwright (E2E) + SQL (RLS) |
| `docs/SDD.md` | Especificación oficial + decisiones D1–D11 |
| `docs/agent-briefs/` | Briefs por fase (AGENTE-1 … AGENTE-7) |
| `docs/presentaciones/` | Plantilla + presentaciones HTML por fase (checkpoint Guillermo) |
| `DEPLOY.md`, `CUMPLIMIENTO.md`, `BACKEND-PARITY.md`, `TEST_REPORT.md`, `README-DB.md`, `TODO.md` | Documentación operativa |

## Reglas transversales (SDD §2/§7/§D)

- Nunca hardcodear colores: leer paleta de `site_config` en runtime (`lib/site/theme.ts`).
- Todo en español: UI, comentarios, logs y errores.
- Migraciones versionadas = fuente de verdad; `db/schema.sql` es snapshot (D10).
- Audit log append-only (D7). Consentimiento explícito y derechos ARCO (§7).
- Pasarela de pago: interfaz `PaymentProvider` lista; implementación en TODO fase 2 (D1).
