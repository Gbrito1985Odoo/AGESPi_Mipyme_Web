/**
 * Función Supabase — regenerate-qr (M3): regenera el QR de una tarjeta
 * existente. Endpoint PROTEGIDO: exige rol admin o super_admin
 * (SERVICE_ROLE se usa solo para el cliente interno; jamás en la respuesta).
 * Entrada: { uuid } del customers.uuid público.
 */
import { z } from "zod";
import { generarQRTarjeta } from "../../../lib/business/qr";
import { parsear } from "../../../lib/business/validacion";
import { json, preflight, respuestaError } from "../_shared/http.ts";
import { ipBloqueada, ipDePeticion, LIMITES_SUGERIDOS } from "../_shared/rateLimit.ts";
import { identidadDePeticion, exigirRol } from "../_shared/rol.ts";

const SCHEMA = z.object({
  uuid: z.string().uuid(),
  base_url: z.string().url().optional(),
});

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return preflight();
  try {
    if (ipBloqueada(ipDePeticion(req), LIMITES_SUGERIDOS.generadorQR)) {
      return json({ error: "Demasiados intentos; espere un minuto" }, 429);
    }
    if (req.method !== "POST") {
      return json({ error: "Método no permitido (use POST)" }, 405);
    }

    // Protección de rol (M6): solo administradores regeneran tarjetas.
    const identidad = await identidadDePeticion(req);
    exigirRol(identidad, ["admin", "super_admin"]);

    const cuerpo = await req.json().catch(() => ({}));
    const { uuid, base_url } = parsear(SCHEMA, cuerpo, "Entrada de regenerate-qr inválida");
    const url = base_url ?? Deno.env.get("SITE_URL") ?? "https://agesp.local";
    const qr = await generarQRTarjeta({ base_url: url, uuid });

    return json({
      url: qr.url,
      png_data_url: qr.png_data_url,
      svg: qr.svg,
      regenerado_por: identidad.usuario_id,
    });
  } catch (e) {
    return respuestaError(e);
  }
});
