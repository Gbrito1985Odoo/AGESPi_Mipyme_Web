/**
 * Función Supabase — calculate-analytics (M4/M6): agregados de respuestas.
 * Endpoint PROTEGIDO (staff). Entrada: { survey_id, desde?, hasta?, pregunta_id? }.
 */
import { calcularAnalytics } from "../../../lib/business/analytics";
import { crearRepositorioSupabase } from "../_shared/repositorio.ts";
import { clienteServicio, identidadDePeticion } from "../_shared/rol.ts";
import { json, preflight, respuestaError } from "../_shared/http.ts";
import { ipBloqueada, ipDePeticion, LIMITES_SUGERIDOS } from "../_shared/rateLimit.ts";

Deno.serve( async (req) => {
  if (req.method === "OPTIONS") return preflight();
  try {
    if (ipBloqueada(ipDePeticion(req), LIMITES_SUGERIDOS.analytics)) {
      return json({ error: "Demasiadas consultas; espere un minuto" }, 429);
    }
    // Staff y super: los agregados reflejan datos sensibles (§7).
    const identidad = await identidadDePeticion(req);
    if (!["super_admin", "admin", "editor"].includes(identidad.rol)) {
      return json({ error: "Permisos insuficientes para consultar analytics" }, 403);
    }
    if (req.method !== "POST") {
      return json({ error: "Método no permitido (use POST)" }, 405);
    }
    const cuerpo = await req.json().catch(() => ({}));
    const repo = crearRepositorioSupabase(clienteServicio());
    const resultado = await calcularAnalytics(repo, cuerpo);
    return json(resultado);
  } catch (e) {
    return respuestaError(e);
  }
});
