/**
 * Adaptador Supabase → Repositorio (capa business) para las funciones Deno.
 * Permite que /lib/business trabaje sin acoplarse al cliente concreto (D2).
 * Paridad documentada: las transacciones multi-paso se ejecutan secuencialmente
 * (Sin BEGIN/COMMIT de PostgREST); ver BACKEND-PARITY.md.
 */
import type { SupabaseClient } from "npm:@supabase/supabase-js@2";
import type { Repositorio, FiltrosSeleccionar } from "../../../lib/business/repositorio";

export function crearRepositorioSupabase(cliente: SupabaseClient): Repositorio {
  const repo: Repositorio = {
    target: "supabase",
    async seleccionar<T = unknown>(tabla: string, opts?: FiltrosSeleccionar): Promise<T[]> {
      let q = cliente.from(tabla).select(opts?.columnas ?? "*");
      if (opts?.eq) {
        for (const [col, val] of Object.entries(opts.eq)) {
          q = q.eq(col, val as never);
        }
      }
      if (opts?.ordenarPor) {
        q = q.order(opts.ordenarPor.columna, { ascending: opts.ordenarPor.asc !== false });
      }
      if (opts?.limite) q = q.limit(opts.limite);
      const { data, error } = await q;
      if (error) throw new Error(`[db:supabase:${tabla}] ${error.message}`);
      return (data ?? []) as T[];
    },
    async insertar<T = unknown>(tabla: string, fila: Record<string, unknown>): Promise<T> {
      const { data, error } = await cliente
        .from(tabla)
        .insert(fila)
        .select()
        .single();
      if (error) throw new Error(`[insertar:supabase:${tabla}] ${error.message}`);
      return data as T;
    },
    async actualizar<T = unknown>(
      tabla: string,
      valores: Record<string, unknown>,
      eq: Record<string, unknown>
    ): Promise<T[]> {
      let q = cliente.from(tabla).update(valores);
      for (const [col, val] of Object.entries(eq)) q = q.eq(col, val as never);
      const { data, error } = await q.select();
      if (error) throw new Error(`[actualizar:supabase:${tabla}] ${error.message}`);
      return (data ?? []) as T[];
    },
    /**
     * En Supabase (PostgREST) NO hay transacciones cliente: se ejecuta
     * secuencialmente. Las reglas de negocio confían en restricciones UNIQUE
     * y guards optimistas de tabla (ver BACKEND-PARITY.md, sección transacciones).
     */
    async transaccion<T>(fn: (trx: Repositorio) => Promise<T>): Promise<T> {
      return fn(repo);
    },
  };
  return repo;
}
