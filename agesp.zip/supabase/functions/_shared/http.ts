/**
 * Utilidades HTTP comunes de las funciones Deno (SDD §3.2): CORS, JSON,
 * traducción de errores a respuestas en español (errores.ts de la capa
 * business). Idioma de las respuestas: español (D9).
 */
import { errorAJSON } from "../../../lib/business/errores";

export const CABECERAS_CORS: Record<string, string> = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

export function json(
  cuerpo: unknown,
  estado = 200,
  extra: Record<string, string> = {}
): Response {
  return new Response(JSON.stringify(cuerpo), {
    status: estado,
    headers: { "Content-Type": "application/json", ...CABECERAS_CORS, ...extra },
  });
}

/** Respuesta binaria (PDF, CSV) con CORS. */
export function binario(
  cuerpo: BodyInit,
  tipoContenido: string,
  extra: Record<string, string> = {}
): Response {
  return new Response(cuerpo, {
    status: 200,
    headers: {
      "Content-Type": tipoContenido,
      ...CABECERAS_CORS,
      ...extra,
    },
  });
}

/** Convierte cualquier error de dominio en una Response HTTP JSON en español. */
export function respuestaError(error: unknown): Response {
  const { estado, cuerpo } = errorAJSON(error);
  return json(cuerpo, estado);
}

/** Preflight CORS. */
export function preflight(): Response {
  return new Response("ok", { headers: CABECERAS_CORS });
}
