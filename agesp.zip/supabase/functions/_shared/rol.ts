/**
 * Verificación de identidad y rol en las funciones Deno (M6, §7).
 * El token Bearer se valida contra Supabase Auth (cliente con clave ANON);
 * el rol se lee SIEMPRE de `profiles.rol` (jamás de claims editables).
 * SERVICE_ROLE solo en clientes construidos aquí (nunca en la respuesta).
 */
import { createClient } from "npm:@supabase/supabase-js@2";
import { ErrorNoAutorizado, ErrorPermisos } from "../../../lib/business/errores";

/** Fanout: cliente con clave ANON para validar tokens de usuarios. */
function clienteAnon() {
  const url = Deno.env.get("SUPABASE_URL");
  const anon = Deno.env.get("SUPABASE_ANON_KEY");
  if (!url || !anon) {
    throw new Error("Faltan SUPABASE_URL / SUPABASE_ANON_KEY en las variables de entorno");
  }
  return createClient(url, anon, { auth: { persistSession: false } });
}

/** Cliente con SERVICE_ROLE para el wrapper (uso interno; nunca expuesto). */
export function clienteServicio() {
  const url = Deno.env.get("SUPABASE_URL");
  const service = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!url || !service) {
    throw new Error("Falta SUPABASE_SERVICE_ROLE_KEY (uso exclusivo del servidor)");
  }
  return createClient(url, service, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}

export interface Identidad {
  usuario_id: string;
  rol: "super_admin" | "admin" | "editor" | "customer";
}

/** Extrae y valida el Bearer token; devuelve identidad (usuario_id + rol). */
export async function identidadDePeticion(req: Request): Promise<Identidad> {
  const token = req.headers.get("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) throw new ErrorNoAutorizado("Falta el token de autorización (Bearer)");

  const cliente = clienteAnon();
  const { data, error } = await cliente.auth.getUser(token);
  if (error || !data.user) {
    throw new ErrorNoAutorizado("Token inválido o caducado");
  }

  const { data: perfil, error: errorPerfil } = await cliente
    .from("profiles")
    .select("id, rol")
    .eq("id", data.user.id)
    .single();
  if (errorPerfil || !perfil) {
    throw new ErrorNoAutorizado("El usuario no tiene perfil registrado en AGESP");
  }
  return { usuario_id: perfil.id, rol: perfil.rol };
}

/** Gate de rol: exige cada uno de los puestos listados. */
export function exigirRol(
  identidad: Identidad,
  permitidos: Identidad["rol"][]
): void {
  if (!permitidos.includes(identidad.rol)) {
    throw new ErrorPermisos(
      `Requiere uno de estos roles: ${permitidos.join(", ")} (rol actual: ${identidad.rol})`
    );
  }
}
