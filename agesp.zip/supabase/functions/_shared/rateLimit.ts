/**
 * Rate limiting simple en memoria por IP (§7 del SDD). Adecuado por instancia
 * de la función Edge; la paridad con express-rate-limit local es «mejor
 * esfuerzo» (documentada en BACKEND-PARITY.md). Para límites estrictos
 * globales multi-instancia se necesitaría un almacén compartido (TODO).
 */

interface Registro {
  contador: number;
  expiraEn: number;
}

const registros = new Map<string, Registro>();

export interface OpcionesLimite {
  max: number;
  ventanaMs: number;
}

export const LIMITES_SUGERIDOS = {
  /** Endpoints de QR y públicos: conservadores. */
  generadorQR: { max: 30, ventanaMs: 60_000 },
  correo: { max: 10, ventanaMs: 60_000 },
  exportar: { max: 5, ventanaMs: 60_000 },
  analytics: { max: 30, ventanaMs: 60_000 },
} as const satisfies Record<string, OpcionesLimite>;

/** Devuelve true si la petición debe rechazarse (límite alcanzado). */
export function ipBloqueada(ip: string, { max, ventanaMs }: OpcionesLimite): boolean {
  const ahora = Date.now();
  const r = registros.get(ip);
  if (!r || ahora > r.expiraEn) {
    registros.set(ip, { contador: 1, expiraEn: ahora + ventanaMs });
    return false;
  }
  r.contador++;
  if (r.contador > max) {
    // Limpieza oportunista para no crecer sin límite.
    if (registros.size > 10_000) {
      for (const [k, v] of registros) if (ahora > v.expiraEn) registros.delete(k);
    }
    return true;
  }
  return false;
}

/** IP del solicitante (el runtime Edge la expone en cabeceras). */
export function ipDePeticion(req: Request): string {
  return (
    req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    req.headers.get("cf-connecting-ip") ??
    "ip-desconocida"
  );
}
