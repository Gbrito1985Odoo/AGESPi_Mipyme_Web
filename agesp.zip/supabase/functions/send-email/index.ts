/**
 * Función Supabase — send-email (M3/M5): envía correo con plantilla renderizada
 * y registra en email_log. Endpoint PROTEGIDO (staff); Sin RESEND_API_KEY
 * registra «error» sin crashear (ver email.ts). Entrada:
 * { plantilla, destinatario, variables }.
 */
import { enviarCorreo } from "../../../lib/business/email";
import { crearRepositorioSupabase } from "../_shared/repositorio.ts";
import { identidadDePeticion, clienteServicio } from "../_shared/rol.ts";
import { json, preflight, respuestaError } from "../_shared/http.ts";
import { ipBloqueada, ipDePeticion, LIMITES_SUGERIDOS } from "../_shared/rateLimit.ts";

// SERVICE_ROLE: escribir en email_log aunque RLS restrinja al remitente;
// el correo es exclusivamente de staff (con rol verificado por identidadDePeticion).
Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return preflight();
  try {
    if (ipBloqueada(ipDePeticion(req), LIMITES_SUGERIDOS.correo)) {
      return json({ error: "Demasiados envíos; espere un minuto" }, 429);
    }
    if (req.method !== "POST") {
      return json({ error: "Método no permitido (use POST)" }, 405);
    }

    // Solo staff (admin/super_admin/editor) dispara correos.
    const identidad = await identidadDePeticion(req);
    if (!["super_admin", "admin", "editor"].includes(identidad.rol)) {
      return json({ error: "Permisos insuficientes para enviar correos" }, 403);
    }

    const cuerpo = await req.json().catch(() => ({}));
    const repo = crearRepositorioSupabase(clienteServicio());
    const registro = await enviarCorreo(repo, {
      ...cuerpo,
      variables: cuerpo.variables ?? {},
    });
    return json({ registro }, registro === null ? 500 : 200);
  } catch (e) {
    return respuestaError(e);
  }
});
