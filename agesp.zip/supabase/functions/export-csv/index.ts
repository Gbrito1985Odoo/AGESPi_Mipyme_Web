/**
 * Función Supabase — export-csv (M5/M6): exporta una tabla a CSV con delimitador
 * `;` y BOM (Excel es-ES). Endpoint PROTEGIDO admin/super_admin (§7: los datos
 * exportados se auditan). GET /?tabla=products&eq[disponible]=true (eq plano).
 * Registra la acción «export» en audit_log (best-effort).
 */
import {
  filasACSV,
  nombreArchivoCSV,
  validarTablaExport,
} from "../../../lib/business/exportCsv";
import { crearRepositorioSupabase } from "../_shared/repositorio.ts";
import { clienteServicio, identidadDePeticion } from "../_shared/rol.ts";
import { binario, json, preflight, respuestaError } from "../_shared/http.ts";
import { ipBloqueada, ipDePeticion, LIMITES_SUGERIDOS } from "../_shared/rateLimit.ts";
import { registrarAccion } from "../../../lib/business/audit";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return preflight();
  try {
    if (ipBloqueada(ipDePeticion(req), LIMITES_SUGERIDOS.exportar)) {
      return json({ error: "Demasiadas exportaciones; espere un minuto" }, 429);
    }
    if (req.method !== "GET") {
      return json({ error: "Método no permitido (use GET)" }, 405);
    }

    // Protección cruda: solo administradores exportan datos completos.
    const identidad = await identidadDePeticion(req);
    if (!["super_admin", "admin"].includes(identidad.rol)) {
      return json({ error: "Exportación solo para admin o super_admin" }, 403);
    }

    const urlPeticion = new URL(req.url);
    const tablaPedida = urlPeticion.searchParams.get("tabla");
    if (!tablaPedida) {
      return json({ error: "Falta el parámetro ?tabla=" }, 400);
    }
    // Seguridad: solo tablas conocidas del código (export-csv del brief).
    const tabla = validarTablaExport(tablaPedida);

    // eq simples: ?eq[disponible]=true (strings; el repo de Supabase los maneja).
    const eq: Record<string, string> = {};
    for (const [k, v] of urlPeticion.searchParams.entries()) {
      const m = k.match(/^eq\[(.+)\]$/); // solo claves eq[...] para evitar inyecciones
      if (m) eq[m[1]] = v;
    }

    const repo = crearRepositorioSupabase(clienteServicio());
    const filas = await repo.seleccionar(tabla, { eq, limite: 10_000 });
    const csv = filasACSV(filas);

    // Auditoría del export (D7: append-only; best-effort).
    await registrarAccion(repo, {
      user_id: identidad.usuario_id,
      accion: "export",
      entidad: tabla,
      entidad_id: null,
      detalle: { filas: filas.length, formato: "csv" },
    }).catch(() => undefined);

    return binario(csv, "text/csv; charset=utf-8", {
      "Content-Disposition": `attachment; filename="${nombreArchivoCSV(tabla)}"`,
    });
  } catch (e) {
    return respuestaError(e);
  }
});
