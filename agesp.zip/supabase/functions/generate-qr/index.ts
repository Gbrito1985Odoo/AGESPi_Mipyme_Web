/**
 * Función Supabase — generate-qr (M3): genera el QR de la tarjeta
 * `/{base_url}/card/{uuid}`. Pública (la URL de la tarjeta es pública),
 * con rate limit por IP. Entrada: { base_url, uuid }.
 */
import { generarQRTarjeta } from "../../../lib/business/qr";
import { json, preflight, respuestaError } from "../_shared/http.ts";
import { ipBloqueada, ipDePeticion, LIMITES_SUGERIDOS } from "../_shared/rateLimit.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return preflight();
  try {
    if (ipBloqueada(ipDePeticion(req), LIMITES_SUGERIDOS.generadorQR)) {
      return json({ error: "Demasiados intentos; espere un minuto" }, 429);
    }
    if (req.method !== "POST") {
      return json({ error: "Método no permitido (use POST)" }, 405);
    }
    const cuerpo = await req.json().catch(() => ({}));
    const qr = await generarQRTarjeta(cuerpo);
    return json({ url: qr.url, png_data_url: qr.png_data_url, svg: qr.svg });
  } catch (e) {
    return respuestaError(e);
  }
});
