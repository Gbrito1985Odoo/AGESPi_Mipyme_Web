/**
 * Función Supabase — generate-invoice-pdf (M5): construye el PDF de la factura
 * con los colores de marca tomados de site_config (§2: NUNCA hardcodear).
 * Endpoint PROTEGIDO staff. Entrada: { factura_id } u { pedido_id } (última
 * factura del pedido). Devuelve application/pdf.
 */
import { PDFDocument } from "pdf-lib";
import { z } from "zod";
import { parsear } from "../../../lib/business/validacion";
import { generarFacturaPDF } from "../../../lib/business/pdf";
import type { Factura, PedidoItem } from "../../../lib/types";
import { crearRepositorioSupabase } from "../_shared/repositorio.ts";
import { clienteServicio, identidadDePeticion } from "../_shared/rol.ts";
import { binario, json, preflight, respuestaError } from "../_shared/http.ts";
import { ipBloqueada, ipDePeticion, LIMITES_SUGERIDOS } from "../_shared/rateLimit.ts";
import { TABLAS } from "../../../lib/business/repositorio";
import { ErrorNoEncontrado } from "../../../lib/business/errores";

const SCHEMA = z.object({
  factura_id: z.string().uuid().optional(),
  pedido_id: z.string().uuid().optional(),
});

/** Lee la paleta de site_config (runtime, §2); usa valores por defecto si faltan. */
async function paletaDeMarca(repo: ReturnType<typeof crearRepositorioSupabase>) {
  const filas = await repo.seleccionar<{
    clave: string;
    valor: Record<string, string>;
  }>(TABLAS.configSitio, { eq: { clave: "colors" }, limite: 1 });
  const colores = filas[0]?.valor ?? {};
  return {
    primario: colores.primario ?? "#0B2E59",
    texto: colores.texto ?? colores.secundario ?? "#4A5568",
    acento: colores.acento ?? "#F4C430",
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return preflight();
  try {
    if (ipBloqueada(ipDePeticion(req), LIMITES_SUGERIDOS.exportar)) {
      return json({ error: "Demasiados intentos; espere un minuto" }, 429);
    }
    if (req.method !== "POST") {
      return json({ error: "Método no permitido (use POST)" }, 405);
    }

    const identidad = await identidadDePeticion(req);
    if (!["super_admin", "admin", "editor"].includes(identidad.rol)) {
      return json({ error: "Permisos insuficientes para generar facturas" }, 403);
    }

    const cuerpo = await req.json().catch(() => ({}));
    const { factura_id, pedido_id } = parsear(SCHEMA, cuerpo, "Entrada de PDF inválida");

    const repo = crearRepositorioSupabase(clienteServicio());

    // Localizar la factura (por id o por pedido).
    let factura: Factura;
    if (factura_id) {
      const filas = await repo.seleccionar<Factura>(TABLAS.facturas, {
        eq: { id: factura_id }, limite: 1,
      });
      if (filas.length === 0) throw new ErrorNoEncontrado("Factura", factura_id);
      factura = filas[0];
    } else if (pedido_id) {
      const filas = await repo.seleccionar<Factura>(TABLAS.facturas, {
        eq: { pedido_id },
        ordenarPor: { columna: "creado_en", asc: false },
        limite: 1,
      });
      if (filas.length === 0) throw new ErrorNoEncontrado("Factura del pedido", pedido_id);
      factura = filas[0];
    } else {
      throw new ErrorNoEncontrado("Factura (faltan factura_id o pedido_id)");
    }

    const items = await repo.seleccionar<PedidoItem>(TABLAS.pedidosItems, {
      eq: { pedido_id: factura.pedido_id },
    });

    const pdfBytes = await generarFacturaPDF({
      factura,
      items,
      colores: await paletaDeMarca(repo),
      emisor: {
        nombre: "AGESP",
        razon: "Agencia de Seguridad y Protección",
        nit: String(factura.datos_fiscales?.nit ?? ""),
      },
    });
    void PDFDocument; // referencia mantenida para posibles colaboradores Deno (metadata)

    return binario(pdfBytes, "application/pdf", {
      "Content-Disposition": `attachment; filename="factura_${factura.serie}-${factura.numero}.pdf"`,
    });
  } catch (e) {
    return respuestaError(e);
  }
});
