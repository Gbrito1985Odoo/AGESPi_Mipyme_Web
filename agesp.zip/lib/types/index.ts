/**
 * Tipos de dominio compartidos — contratos únicos para frontend,
 * /lib/business, adaptadores DB y wrappers Deno/Express.
 * Fuente de esquema: db/schema.sql (SDD §4.2). Idioma: español.
 */

/* ---------- Catálogo / Tienda (M2) ---------- */

export type Moneda = "CUP" | "MLC" | "USD";

export interface Categoria {
  id: string;
  nombre: string;
  slug: string;
  descripcion?: string | null;
  orden?: number | null;
}

export interface Producto {
  id: string;
  /** Identificador visible (SDD M2: «ID» en el catálogo). */
  codigo: string;
  nombre: string;
  descripcion?: string | null;
  /** URL de imagen en Supabase Storage. */
  imagen_url?: string | null;
  precio: number;
  moneda: Moneda;
  /** Unidad de venta: "unidad", "kg", "mes", "servicio"... (Art. 5 Res. 35/2020). */
  unidad: string;
  disponible: boolean;
  /** Tiempo de entrega declarado (Art. 5 Res. 35/2020). */
  tiempo_entrega: string;
  destacado: boolean;
  categoria_id?: string | null;
  /** Stock disponible (M5: inventario + alertas de bajo inventario). */
  stock: number;
  stock_minimo: number;
  creado_en: string;
  actualizado_en: string;
}

/* ---------- Clientes / Directorio (M3) ---------- */

export interface Customer {
  id: string;
  /** UUID público para la tarjeta: https://{dominio}/card/{uuid} */
  uuid: string;
  nombre: string;
  /** Nombre de la entidad (empresa / mipyme / persona). */
  tipo_entidad: "mipyme_estatal" | "mipyme_privada" | "persona" | "otro";
  /** Carné o NIT — cifrado en reposo con pgcrypto. */
  tax_id_cifrado: string;
  domicilio?: string | null;
  codigo_postal?: string | null;
  telefono?: string | null;
  correo?: string | null;
  credencial?: string | null;
  consentimiento_aceptado: boolean;
  creado_en: string;
  actualizado_en: string;
}

/* ---------- Pedidos / Facturación (M2, M5) ---------- */

export interface Pedido {
  id: string;
  customer_id?: string | null;
  moneda: Moneda;
  /** estado: pendiente | confirmado | pagado | entregado | cancelado */
  estado: "pendiente" | "confirmado" | "pagado" | "entregado" | "cancelado";
  total: number;
  creado_en: string;
  actualizado_en: string;
}

export interface PedidoItem {
  id: string;
  pedido_id: string;
  producto_id: string;
  nombre_snapshot: string;
  precio_snapshot: number;
  moneda: Moneda;
  cantidad: number;
}

export interface Factura {
  id: string;
  pedido_id: string;
  /** Numeración secuencial (M5): serie + consecutivo. */
  serie: string;
  numero: number;
  customer_id?: string | null;
  moneda: Moneda;
  total: number;
  /** Datos fiscales incluidos en el PDF. */
  datos_fiscales: Record<string, string>;
  pdf_url?: string | null;
  creado_en: string;
}

/* ---------- Encuestas (M4, §8) ---------- */

export type TipoPregunta =
  | "texto"
  | "seleccion"
  | "seleccion_multiple"
  | "likert"
  | "escala"
  | "fecha"
  | "numerica"
  | "si_no";

export interface Encuesta {
  id: string;
  titulo: string;
  descripcion?: string | null;
  activa: boolean;
  publicada: boolean;
  creado_en: string;
}

export interface Pregunta {
  id: string;
  survey_id: string;
  posicion: number;
  /** Id de sección para agrupar en la UI (§8.1). */
  seccion: string;
  tipo: TipoPregunta;
  texto: string;
  /** Ayuda/explicación de términos entre paréntesis (§8.2). */
  ayuda?: string | null;
  obligatoria: boolean;
  /** metadata JSON con lógica de salto: { show_if: { questionId, valor } } */
  metadata?: PreguntaMetadata | null;
}

export interface PreguntaMetadata {
  show_if?: { pregunta_id: string; valor: unknown };
  /** Para escala/likert: etiquetas de los valores. */
  escala?: string[];
  /** §8.2: mostrar aunque la condición show_if no se cumpla (p. ej. P9). */
  mostrar_igualmente?: boolean;
}

export interface OpcionPregunta {
  id: string;
  question_id: string;
  valor: string;
  etiqueta: string;
  orden: number;
}

export interface RespuestaEncuesta {
  id: string;
  survey_id: string;
  customer_id?: string | null;
  /** JSON: { [question_id]: valor } */
  datos: Record<string, unknown>;
  /** Log de consentimiento (§7). */
  consent_log?: { aceptado: boolean; fecha: string } | null;
  creado_en: string;
}

export interface AsignacionEncuesta {
  id: string;
  survey_id: string;
  customer_id?: string | null;
  /** Público/por entidad cuando no hay usuario. */
  token?: string | null;
  estado: "pendiente" | "completada";
  creado_en: string;
}

/* ---------- CRM (M5) ---------- */

export interface Lead {
  id: string;
  nombre: string;
  correo?: string | null;
  telefono?: string | null;
  /** pipeline: nuevo | contactado | propuesta | negociacion | ganado | perdido */
  pipeline: "nuevo" | "contactado" | "propuesta" | "negociacion" | "ganado" | "perdido";
  origen?: string | null;
  notas?: string | null;
  creado_en: string;
  actualizado_en: string;
}

export interface Interaccion {
  id: string;
  /** lead o customer */
  entidad_tipo: "lead" | "customer";
  entidad_id: string;
  canal: "web" | "correo" | "telefono" | "presencial";
  resumen: string;
  creado_por?: string | null;
  creado_en: string;
}

/* ---------- Admin / Config / Seguridad (M6, §7) ---------- */

export type Rol = "super_admin" | "admin" | "editor" | "customer";

export interface Perfil {
  id: string;
  correo: string;
  nombre?: string | null;
  rol: Rol;
  /** MFA TOTP obligatorio para super_admin (SDD M6, decisión D3). */
  mfa_habilitado: boolean;
  creado_en: string;
}

export interface ConfigSitio {
  /** Clave plana editable desde admin: "colors.primary", "texto.hero_titulo"… */
  clave: string;
  valor: unknown;
  actualizado_en: string;
}

export interface PlantillaCorreo {
  id: string;
  clave: string; // p. ej. "bienvenida_qr", "confirmacion_pedido"
  asunto: string;
  html: string;
  /** Variables disponibles: {{nombre}}, {{url_tarjeta}}, {{pedido_id}}… */
  variables: string[];
  actualizado_en: string;
}

export interface RegistroAuditoria {
  id: string;
  user_id?: string | null;
  accion: string; // "login", "cambio_precio", "export", "crear_producto"…
  entidad?: string | null;
  entidad_id?: string | null;
  detalle?: Record<string, unknown> | null;
  creado_en: string;
}

export interface RegistroCorreo {
  id: string;
  destinatario: string;
  plantilla_clave?: string | null;
  asunto: string;
  estado: "enviado" | "error";
  detalle_error?: string | null;
  creado_en: string;
}

/* ---------- Pagos (M2, TODO fase 2 — D1) ---------- */

/** Interfaz lista para pasarela Transfermóvil/EnZona (impl. fase 2). */
export interface PaymentProvider {
  nombre: "transfermovil" | "enzona";
  crearPago(monto: number, moneda: Moneda, referencia: string): Promise<{ url: string }>;
}

/* ---------- Analytics (M4/M6) ---------- */

export interface FiltrosAnalytics {
  desde?: string;
  hasta?: string;
  tipo_entidad?: Customer["tipo_entidad"];
  survey_id?: string;
  pregunta_id?: string;
}
