/**
 * Selector de objetivo (SDD §3.1): NEXT_PUBLIC_DB_TARGET=supabase|local.
 * El resto del código NUNCA importa los adaptadores directamente: usa
 * este índice para no acoplarse a un objetivo concreto.
 */
import type { SupabaseClient } from "@supabase/supabase-js";

export type TargetDB = "supabase" | "local";

export function objetivoDB(): TargetDB {
  const t = process.env.NEXT_PUBLIC_DB_TARGET;
  if (t !== "supabase" && t !== "local") {
    // Valor por defecto: camino crítico (SDD, decisión D2).
    return "supabase";
  }
  return t;
}

export interface AdaptadorDB {
  target: TargetDB;
  /**
   * Lecturas simples tipo tabla (fila por fila).
   * En Supabase → from().select(); en local → SQL equivalente.
   */
  seleccionar<T = unknown>(
    tabla: string,
    opts?: {
      columnas?: string;
      ordenarPor?: { columna: string; asc?: boolean };
      limite?: number;
      eq?: Record<string, unknown>;
      single?: boolean;
    }
  ): Promise<T[]>;
}

export async function db(): Promise<AdaptadorDB> {
  const target = objetivoDB();
  if (target === "supabase") {
    const { createSupabaseClient } = await import("./supabaseClient");
    const supabase = createSupabaseClient();
    return {
      target,
      async seleccionar<T = unknown>(tabla, opts) {
        let q = supabase
          .from(tabla)
          .select(opts?.columnas ?? "*");
        if (opts?.eq) {
          for (const [col, val] of Object.entries(opts.eq)) {
            q = q.eq(col, val as any);
          }
        }
        if (opts?.ordenarPor) {
          q = q.order(opts.ordenarPor.columna, {
            ascending: opts.ordenarPor.asc !== false,
          });
        }
        if (opts?.limite) q = q.limit(opts.limite);
        if (opts?.single) q = q.limit(1);
        const { data, error } = await q;
        if (error) throw new Error(`[db:${tabla}] ${error.message}`);
        return (data ?? []) as T[];
      },
    };
  }
  const { createLocalClient } = await import("./localClient");
  const local = createLocalClient();
  return {
    target,
    async seleccionar<T = unknown>(tabla, opts) {
      const columnas =
        (opts?.columnas ?? "*") === "*" ? "*" : opts!.columnas;
      let sql = `SELECT ${columnas} FROM ${inalterado(tabla)}`;
      const params: unknown[] = [];
      if (opts?.eq) {
        const conds = Object.entries(opts.eq).map(([col, val]) => {
          params.push(val);
          return `${col} = $${params.length}`;
        });
        sql += ` WHERE ${conds.join(" AND ")}`;
      }
      if (opts?.ordenarPor) {
        sql += ` ORDER BY ${opts.ordenarPor.columna} ${opts.ordenarPor.asc !== false ? "ASC" : "DESC"}`;
      }
      if (opts?.limite) sql += ` LIMIT ${opts.limite}`;
      const res = await local.query(sql, params);
      return res.rows as T[];
    },
  };
}

/** Las tablas provienen de constantes del código, no del usuario. */
function inalterado(tabla: string): string {
  if (!/^[a-z_]+$/.test(tabla)) throw new Error("Nombre de tabla inválido");
  return `"${tabla}"`;
}
