import { Pool, PoolClient, QueryResult, PoolConfig } from "pg";

/**
 * Adaptador PostgreSQL local (SDD §3.1, D2): paridad con el objetivo
 * `supabase` a través de wrapper `unified`. Rutas Express → query entrante.
 */

let _pool: Pool | null = null;

export function getPool(): Pool {
  if (!_pool) {
    const config: PoolConfig = process.env.DATABASE_URL
      ? { connectionString: process.env.DATABASE_URL }
      : {};
    _pool = new Pool({ ...config, max: 10 });
    _pool.on("error", (err) =>
      console.error("[localClient] Error en consulta:", err.message)
    );
  }
  return _pool;
}

export interface LocalDB {
  /** Consulta parametrizada: siempre pasar parámetros, nunca concatenar SQL. */
  query<T = unknown>(sql: string, params?: unknown[]): Promise<QueryResult<T>>;
  tx<T>(fn: (client: PoolClient) => Promise<T>): Promise<T>;
  cerrar(): Promise<void>;
}

export function createLocalClient() {
  const pool = getPool();
  const client: LocalDB = {
    query: (sql, params) => pool.query(sql, params as any),
    tx: async (fn) => {
      const c = await pool.connect();
      try {
        await c.query("BEGIN");
        const r = await fn(c);
        await c.query("COMMIT");
        return r;
      } catch (e) {
        await c.query("ROLLBACK");
        throw e;
      } finally {
        c.release();
      }
    },
    cerrar: async () => {
      if (_pool) {
        await _pool.end();
        _pool = null;
      }
    },
  };
  return client;
}

/**
 * Objetivo del usuario en sesión local (puente de identidad, SDD §4.1):
 * el token JWT se decodifica en las rutas y se guarda en
 * `SET LOCAL app.user_id` dentro de la transacción para que las políticas
 * RLS de local usen current_user_id().
 */
export async function setUserContext(
  c: PoolClient,
  userId: string
): Promise<void> {
  await c.query("SELECT set_config('app.user_id', $1, true)", [userId]);
}
