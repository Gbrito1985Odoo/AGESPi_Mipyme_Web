import { createClient, SupabaseClient } from "@supabase/supabase-js";

/**
 * Adaptador Supabase (SDD §3.1). El cliente con clave ANON se usa en
 * navegador; el cliente con SERVICE_ROLE solo puede usarse côté servidor
 * (wrappers Deno, rutas API) — jamás exponer en el cliente.
 */

export interface CredencialesSupabase {
  url: string;
  anonKey: string;
}

export function credenciales(): CredencialesSupabase {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const anonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !anonKey) {
    throw new Error(
      "Faltan NEXT_PUBLIC_SUPABASE_URL / NEXT_PUBLIC_SUPABASE_ANON_KEY en .env"
    );
  }
  return { url, anonKey };
}

export function createSupabaseClient(): SupabaseClient {
  const { url, anonKey } = credenciales();
  return createClient(url, anonKey, { auth: { persistSession: true } });
}

/** Solo côté servidor (API routes, wrappers Deno, seeds). */
export function createSupabaseAdminClient(): SupabaseClient {
  const { url } = credenciales();
  const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!serviceRoleKey) {
    throw new Error("Falta SUPABASE_SERVICE_ROLE_KEY (uso exclusivo del servidor)");
  }
  return createClient(url, serviceRoleKey, {
    auth: { persistSession: false, autoRefreshToken: false },
  });
}
