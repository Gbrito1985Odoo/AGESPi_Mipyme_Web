/**
 * QR de tarjetas de cliente (SDD M3): genera el QR para
 * `https://{dominio}/card/{uuid}` como PNG (data-URL) y SVG string.
 * Paquete compartido Deno/Node vía `qrcode` (npm: specifier en Deno).
 */
import QRCode from "qrcode";
import { z } from "zod";
import { parsear } from "./validacion";

const ENTRADA_QR_SCHEMA = z.object({
  /** Base sin barra final, p. ej. "https://agesp.example.cu" */
  base_url: z.string().url(),
  /** UUID público de la tarjeta (customers.uuid). */
  uuid: z.string().uuid(),
});

export interface TarjetaQR {
  /** URL completa codificada en el QR. */
  url: string;
  /** PNG en formato data-URL (para incrustar en HTML/correo). */
  png_data_url: string;
  /** SVG vectorial string (para impresión de la tarjeta). */
  svg: string;
}

/** Construye la URL pública de la tarjeta (M3). */
export function urlTarjeta(baseUrl: string, uuidTarjeta: string): string {
  const base = baseUrl.replace(/\/+$/, "");
  return `${base}/card/${uuidTarjeta}`;
}

/**
 * Genera el QR de la tarjeta. Nivel de corrección alto (H) para que
 * sobreviva impresión y escaneo desde una tarjeta plástica.
 */
export async function generarQRTarjeta(
  entrada: unknown,
  opciones: { ancho?: number } = {}
): Promise<TarjetaQR> {
  const datos = parsear(ENTRADA_QR_SCHEMA, entrada, "Entrada de QR inválida");
  const url = urlTarjeta(datos.base_url, datos.uuid);
  const ancho = opciones.ancho ?? 320;

  const png_data_url = await QRCode.toDataURL(url, {
    errorCorrectionLevel: "H",
    width: ancho,
    margin: 2,
  });
  const svg = await QRCode.toString(url, {
    errorCorrectionLevel: "H",
    type: "svg",
    margin: 2,
  });

  return { url, png_data_url, svg };
}
