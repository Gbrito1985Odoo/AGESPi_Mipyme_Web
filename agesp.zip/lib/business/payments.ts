/**
 * Pagos (SDD M2, decisión D1): la pasarela de pago es SOLO una interfaz lista
 * (Transfermóvil / EnZona). La implementación es TODO fase 2 por decisión
 * explícita del SDD: este stub nunca simula un cobro.
 */
import type { Moneda, PaymentProvider } from "../types";
import { ErrorNoDisponible } from "./errores";

/** Proveedores previstos por el SDD (D1). Ninguno implementado aún. */
export const PROVEEDORES_PREVISTOS = [
  "transfermovil",
  "enzona",
] as const satisfies readonly PaymentProvider["nombre"][];

/** Proveedor stub: toda llamada lanza ErrorNoDisponible («TODO fase 2», D1). */
export function crearProveedorStub(nombre: string): PaymentProvider {
  if (!PROVEEDORES_PREVISTOS.some((p) => p === nombre)) {
    throw new ErrorNegocioProveedor(nombre);
  }
  return {
    nombre: nombre as PaymentProvider["nombre"],
    async crearPago(monto, moneda, referencia) {
      void monto;
      void moneda;
      void referencia;
      throw new ErrorNoDisponible(
        "Pasarela de pago TODO fase 2 (decisión D1): solo interfaz PaymentProvider"
      );
    },
  };
}

class ErrorNegocioProveedor extends Error {
  constructor(nombre: string) {
    super(`Proveedor de pago desconocido: ${nombre}`);
    this.name = "ErrorNegocioProveedor";
  }
}
