/**
 * Pedidos (SDD M2/M5): crear desde el carrito, cambiar estado con máquina
 * de estados, descontar/devolver stock en transacción y alertas de bajo
 * inventario. Portabilidad: solo Repositorio (repositorio.ts), sin
 * SELECT FOR UPDATE (guard optimista como inventory.ts).
 */
import { z } from "zod";
import type { Pedido, PedidoItem, Producto } from "../types";
import { ErrorNegocio, ErrorNoEncontrado } from "./errores";
import { parsear } from "./validacion";
import { TABLAS, type Repositorio } from "./repositorio";
import { redondearMonto, validarCarrito, type Carrito } from "./cart";
import { registrarAccion } from "./audit";

/* ---------- Máquina de estados (M5) ---------- */

const TRANSICIONES: Record<Pedido["estado"], Pedido["estado"][]> = {
  pendiente: ["confirmado", "cancelado"],
  confirmado: ["pagado", "cancelado"],
  pagado: ["entregado", "cancelado"],
  entregado: [], // estado final
  cancelado: [], // estado final
};

export const ESTADOS_SCHEMA = z.enum(["pendiente", "confirmado", "pagado", "entregado", "cancelado"]);

/* ---------- Listado / obtención ---------- */

export interface FiltrosPedido {
  customer_id?: string;
  estado?: Pedido["estado"];
  limite?: number;
}

export async function listarPedidos(
  repo: Repositorio,
  filtros: FiltrosPedido = {}
): Promise<Pedido[]> {
  const eq: Record<string, unknown> = {};
  if (filtros.customer_id) eq.customer_id = filtros.customer_id;
  if (filtros.estado) eq.estado = filtros.estado;
  return repo.seleccionar<Pedido>(TABLAS.pedidos, {
    eq: Object.keys(eq).length ? eq : undefined,
    ordenarPor: { columna: "creado_en", asc: false },
    limite: filtros.limite,
  });
}

export async function obtenerPedido(
  repo: Repositorio,
  pedidoId: string
): Promise<Pedido> {
  const filas = await repo.seleccionar<Pedido>(TABLAS.pedidos, {
    eq: { id: pedidoId },
    limite: 1,
  });
  if (filas.length === 0) throw new ErrorNoEncontrado("Pedido", pedidoId);
  return filas[0];
}

export async function itemsDePedido(
  repo: Repositorio,
  pedidoId: string
): Promise<PedidoItem[]> {
  return repo.seleccionar<PedidoItem>(TABLAS.pedidosItems, {
    eq: { pedido_id: pedidoId },
    ordenarPor: { columna: "id", asc: true },
  });
}

/* ---------- Crear pedido desde carrito ---------- */

export const ENTRADA_PEDIDO_SCHEMA = z.object({
  customer_id: z.string().uuid().nullable().optional(),
  usuario_id: z.string().uuid().nullable().optional(),
});

export interface CrearPedidoEntrada {
  customer_id?: string | null;
  usuario_id?: string | null;
}

export interface PedidoAlerta {
  producto_id: string;
  nombre: string;
  stock: number;
  stock_minimo: number;
}

export interface ResultadoPedido {
  pedido: Pedido;
  items: PedidoItem[];
  /** Productos que quedaron bajo el mínimo tras el descuento (M5). */
  alertas: PedidoAlerta[];
}

/**
 * Crea el pedido en estado `pendiente` a partir del carrito (M2).
 *Snapshot de nombre/precio/moneda por ítem (histórico M5). El stock NO se
 * descuenta aquí: se descuenta al CONFIRMAR (regla de negocio M5).
 */
export async function crearPedidoDesdeCarrito(
  repo: Repositorio,
  carrito: Carrito,
  entrada: CrearPedidoEntrada = {}
): Promise<ResultadoPedido> {
  const problemas = validarCarrito(carrito);
  if (problemas.length > 0) {
    throw new ErrorNegocio(`Carrito inválido: ${problemas.join(" · ")}`);
  }
  const datos = parsear(ENTRADA_PEDIDO_SCHEMA, entrada, "Entrada de pedido inválida");
  const total = redondearMonto(carrito.items.reduce((s, i) => s + i.precio * i.cantidad, 0));

  return repo.transaccion(async (trx) => {
    const pedido = await trx.insertar<Pedido>(TABLAS.pedidos, {
      customer_id: datos.customer_id ?? null,
      moneda: carrito.moneda as Pedido["moneda"],
      estado: "pendiente" as const,
      total,
      creado_en: new Date().toISOString(),
      actualizado_en: new Date().toISOString(),
    });

    const items = await Promise.all(
      carrito.items.map((i) =>
        trx.insertar<PedidoItem>(TABLAS.pedidosItems, {
          pedido_id: pedido.id,
          producto_id: i.producto_id,
          nombre_snapshot: i.nombre,
          precio_snapshot: i.precio,
          moneda: i.moneda,
          cantidad: i.cantidad,
        })
      )
    );

    if (datos.usuario_id) {
      await registrarAccion(trx, {
        user_id: datos.usuario_id,
        accion: "crear_pedido",
        entidad: TABLAS.pedidos,
        entidad_id: pedido.id,
        detalle: { total, moneda: carrito.moneda, items: items.length },
      }).catch(() => undefined);
    }

    return { pedido, items, alertas: [] };
  });
}

/* ---------- Cambio de estado ---------- */

/** Mueve el pedido por la máquina de estados. En `confirmado` descuenta
 * stock; en `cancelado` lo devuelve si ya fue descontado. Post-entrega el
 * pedido es inmutable y no se puede cancelar (regla M5 de servicio). */
export async function cambiarEstadoPedido(
  repo: Repositorio,
  pedidoId: string,
  nuevoEstado: unknown,
  opciones: { usuarioId?: string | null } = {}
): Promise<{ pedido: Pedido; alertas: PedidoAlerta[] }> {
  const estadoDestino = parsear(ESTADOS_SCHEMA, nuevoEstado, "Estado de pedido inválido");

  return repo.transaccion(async (trx) => {
    const pedido = await obtenerPedido(trx, pedidoId);
    const permitidos = TRANSICIONES[pedido.estado] ?? [];

    if (!permitidos.includes(estadoDestino)) {
      throw new ErrorNegocio(
        `Transición de estado no permitida: ${pedido.estado} → ${estadoDestino}` +
          (permitidos.length
            ? ` (permitidas: ${permitidos.join(", ")})`
            : " (estado final, inmutable)")
      );
    }

    const items = await itemsDePedido(trx, pedidoId);
    let alertas: PedidoAlerta[] = [];

    if (estadoDestino === "confirmado") {
      alertas = await descontarStockItems(trx, items, pedidoId);
    }
    if (
      estadoDestino === "cancelado" &&
      (pedido.estado === "confirmado" || pedido.estado === "pagado")
    ) {
      await devolverStockItems(trx, items);
    }

    const filas = await trx.actualizar<Pedido>(
      TABLAS.pedidos,
      { estado: estadoDestino, actualizado_en: new Date().toISOString() },
      { id: pedidoId, estado: pedido.estado } // guard optimista
    );
    if (filas.length === 0) {
      throw new ErrorNegocio("El pedido cambió durante la operación; reintente");
    }

    if (opciones.usuarioId) {
      await registrarAccion(trx, {
        user_id: opciones.usuarioId,
        accion: "cambiar_estado_pedido",
        entidad: TABLAS.pedidos,
        entidad_id: pedidoId,
        detalle: { de: pedido.estado, a: estadoDestino },
      }).catch(() => undefined);
    }

    return { pedido: filas[0], alertas };
  });
}

/* ---------- Stock (guard optimista, misma técnica que inventory.ts) ---------- */

async function descontarStockItems(
  trx: Repositorio,
  items: PedidoItem[],
  pedidoId: string
): Promise<PedidoAlerta[]> {
  const alertas: PedidoAlerta[] = [];
  for (const item of items) {
    const producto = await obtenerProductoSeguro(trx, item);
    const nuevoStock = producto.stock - item.cantidad;
    if (nuevoStock < 0) {
      throw new ErrorNegocio(
        `Stock insuficiente de "${producto.nombre}" (disponible ${producto.stock}, requerido ${item.cantidad}) en el pedido ${pedidoId}`
      );
    }
    const filas = await trx.actualizar<Producto>(
      TABLAS.productos,
      { stock: nuevoStock, actualizado_en: new Date().toISOString() },
      { id: producto.id, stock: producto.stock }
    );
    if (filas.length === 0) {
      throw new ErrorNegocio(`El stock de "${producto.nombre}" cambió durante la operación; reintente`);
    }
    const actualizado = filas[0];
    if (actualizado.stock < actualizado.stock_minimo) {
      alertas.push({
        producto_id: actualizado.id,
        nombre: actualizado.nombre,
        stock: actualizado.stock,
        stock_minimo: actualizado.stock_minimo,
      });
    }
  }
  return alertas;
}

async function devolverStockItems(trx: Repositorio, items: PedidoItem[]): Promise<void> {
  for (const item of items) {
    if (!item.producto_id) continue; // producto eliminado: nada que devolver
    const filas = await trx.seleccionar<Producto>(TABLAS.productos, {
      eq: { id: item.producto_id },
      limite: 1,
    });
    if (filas.length === 0) continue;
    const producto = filas[0];
    await trx.actualizar<Producto>(
      TABLAS.productos,
      { stock: producto.stock + item.cantidad, actualizado_en: new Date().toISOString() },
      { id: producto.id, stock: producto.stock }
    );
  }
}

async function obtenerProductoSeguro(trx: Repositorio, item: PedidoItem): Promise<Producto> {
  if (!item.producto_id) {
    throw new ErrorNegocio(
      `El ítem "${item.nombre_snapshot}" referencia un producto eliminado; no se puede confirmar el pedido`
    );
  }
  const filas = await trx.seleccionar<Producto>(TABLAS.productos, {
    eq: { id: item.producto_id },
    limite: 1,
  });
  if (filas.length === 0) {
    throw new ErrorNoEncontrado("Producto", item.producto_id);
  }
  return filas[0];
}
