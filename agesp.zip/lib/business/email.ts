/**
 * Correo (SDD M3/M5): render de plantillas `{{clave}}` con sanitización de
 * variables visibles en HTML y envío con Resend. Sin `RESEND_API_KEY` o sin
 * credenciales válidas: se registra "error" en `email_log` («enviado» solo con
 * confirmación del proveedor), pero nada crashea. Idioma: español (D9).
 */
import { z } from "zod";
import type { PlantillaCorreo, RegistroCorreo } from "../types";
import { parsear } from "./validacion";
import { TABLAS, type Repositorio } from "./repositorio";

export const ENTRADA_CORREO_SCHEMA = z.object({
  /** Clave de plantilla en email_templates, p. ej. "bienvenida_qr". */
  plantilla: z.string().min(2).max(50),
  destinatario: z.string().email("El correo del destinatario no es válido"),
  variables: z.record(z.string(), z.unknown()).default({}),
});

export interface EntradaCorreo {
  plantilla: string;
  destinatario: string;
  variables: Record<string, unknown>;
}

/* ---------- Render ---------- */

/** Escapa los caracteres de la entrada para inyectar en HTML (§7). */
export function escaparHtml(texto: string): string {
  return texto
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** Reemplaza `{{clave}}` por el valor escapado; clave desconocida queda como está. */
export function renderizarPlantilla(
  html: string,
  variables: Record<string, unknown>
): string {
  return html.replace(/\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}/g, (_m, clave: string) => {
    const valor = variables[clave];
    if (valor === undefined || valor === null) return `{{${clave}}}`; // no silenciar descuidos
    return escaparHtml(String(valor));
  });
}

/** Sustituye también el asunto (p. ej. «Factura del pedido {{pedido_id}}»). */
export function renderizarAsunto(
  asunto: string,
  variables: Record<string, unknown>
): string {
  return asunto.replace(/\{\{\s*([a-zA-Z_][a-zA-Z0-9_]*)\s*\}\}/g, (_m, clave: string) => {
    const valor = variables[clave];
    if (valor === undefined || valor === null) return `{{${clave}}}`;
    return String(valor); // el asunto es texto plano
  });
}

/* ---------- Envío ---------- */

/**
 * Envía un correo con la plantilla y lo registra en email_log. Sin RESEND_API_KEY:
 * lanza error explícito en el sistema y lo loguea con detalle.
 */
export async function enviarCorreo(
  repo: Repositorio,
  entrada: unknown
): Promise<RegistroCorreo> {
  const datos = parsear(ENTRADA_CORREO_SCHEMA, entrada, "Entrada de correo inválida");

  // 1) Plantilla del sistema (fuente de legibilidad, no del usuario final).
  const plantillaFilas = await repo.seleccionar<PlantillaCorreo>(TABLAS.plantillasCorreo, {
    eq: { clave: datos.plantilla },
    limite: 1,
  });
  if (plantillaFilas.length === 0) {
    return registroFracaso(repo, {
      destinatario: datos.destinatario,
      plantilla: datos.plantilla,
      detalle: `No existe la plantilla "${datos.plantilla}"`,
    });
  }
  const plantilla: PlantillaCorreo = plantillaFilas[0];

  // 2) Pendientes: variables que la plantilla declara y nadie envió.
  const faltantes = plantilla.variables.filter((v) => {
    const clave = v.replace(/[{}]/g, "").trim();
    return datos.variables[clave] === undefined;
  });

  const htmlFinal = renderizarPlantilla(plantilla.html, datos.variables);
  const asuntoFinal = renderizarAsunto(plantilla.asunto, datos.variables);

  const apiKey = process.env.RESEND_API_KEY;

  /* Envío real solo si hay credenciales; sin Resend no hay envío simulado. */
  if (!apiKey) {
    const detalle = faltantes.length
      ? "Sin RESEND_API_KEY; además faltan variables: " + faltantes.join(", ")
      : "Sin RESEND_API_KEY configurada: no se envió el correo";
    return registroFracaso(repo, {
      destinatario: datos.destinatario,
      plantilla: datos.plantilla,
      detalle,
    });
  }

  try {
    const { Resend } = await import("resend");
    const resend = new Resend(apiKey);
    const remitente = process.env.RESEND_FROM ?? "AGESP <onboarding@resend.dev>";
    const response = await resend.emails.send({
      from: remitente,
      to: [datos.destinatario],
      subject: asuntoFinal,
      html: htmlFinal,
    });
    if (response.error) {
      return registroFracaso(repo, {
        destinatario: datos.destinatario,
        plantilla: datos.plantilla,
        detalle: `Resend reportó error: ${response.error.message ?? "sin detalle"}`,
      });
    }

    // 3) Log de envío OK (enviado).
    return repo.insertar<RegistroCorreo>(TABLAS.logCorreo, {
      destinatario: datos.destinatario,
      plantilla_clave: datos.plantilla,
      asunto: asuntoFinal,
      estado: "enviado",
      detalle_error: null,
      creado_en: new Date().toISOString(),
    });
  } catch (e) {
    return registroFracaso(repo, {
      destinatario: datos.destinatario,
      plantilla: datos.plantilla,
      detalle: e instanceof Error ? e.message : "Error desconocido de Resend",
    });
  }
}

/* ---------- Registro de errores (siempre loguea) ---------- */

interface DetalleFracaso {
  destinatario: string;
  plantilla: string;
  detalle: string;
}

function registroFracaso(
  repo: Repositorio,
  { destinatario, plantilla, detalle }: DetalleFracaso
): Promise<RegistroCorreo> {
  // Console en español por decisión D9 (solo errores reales).
  console.error(`[email] No se envió el correo (${plantilla}): ${detalle}`);
  return repo.insertar<RegistroCorreo>(TABLAS.logCorreo, {
    destinatario,
    plantilla_clave: plantilla,
    asunto: `(no enviado) ${plantilla}`,
    estado: "error",
    detalle_error: detalle,
    creado_en: new Date().toISOString(),
  });
}
