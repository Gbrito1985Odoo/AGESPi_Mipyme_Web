/**
 * CRM (SDD M5): leads, customers, pipeline e interacciones/notas.
 * Operaciones con validación Zod y transiciones de pipeline acotadas.
 */
import { z } from "zod";
import type { Interaccion, Lead } from "../types";
import { ErrorNegocio, ErrorNoEncontrado } from "./errores";
import { parsear } from "./validacion";
import { TABLAS, type Repositorio } from "./repositorio";

/* ---------------------- Leads ---------------------- */

export const ENTRADA_LEAD_SCHEMA = z.object({
  nombre: z.string().min(1, "El nombre del lead es obligatorio"),
  correo: z.string().email().optional().nullable(),
  telefono: z.string().min(5).optional().nullable(),
  origen: z.string().optional().nullable(),
  notas: z.string().optional().nullable(),
  pipeline: z
    .enum(["nuevo", "contactado", "propuesta", "negociacion", "ganado", "perdido"])
    .default("nuevo"),
});

export async function crearLead(repo: Repositorio, entrada: unknown): Promise<Lead> {
  const datos = parsear(ENTRADA_LEAD_SCHEMA, entrada, "Datos de lead inválidos");
  return repo.insertar<Lead>(TABLAS.leads, { ...datos, creado_en: new Date().toISOString() });
}

export async function listarLeads(
  repo: Repositorio,
  filtros?: { pipeline?: Lead["pipeline"]; limite?: number }
): Promise<Lead[]> {
  return repo.seleccionar<Lead>(TABLAS.leads, {
    eq: filtros?.pipeline ? { pipeline: filtros.pipeline } : undefined,
    ordenarPor: { columna: "creado_en", asc: false },
    limite: filtros?.limite,
  });
}

/** Transiciones válidas de pipeline (embudo de comercial). */
const TRANSICIONES_PIPELINE: Record<Lead["pipeline"], Lead["pipeline"][]> = {
  nuevo: ["contactado", "ganado", "perdido", "propuesta"],
  contactado: ["propuesta", "negociacion", "ganado", "perdido"],
  propuesta: ["negociacion", "ganado", "perdido"],
  negociacion: ["ganado", "perdido"],
  ganado: [],
  perdido: [],
};

export async function moverPipeline(
  repo: Repositorio,
  leadId: string,
  nuevoPipeline: Lead["pipeline"],
  usuarioId?: string | null
): Promise<Lead> {
  const filas = await repo.seleccionar<Lead>(TABLAS.leads, { eq: { id: leadId }, limite: 1 });
  if (filas.length === 0) throw new ErrorNoEncontrado("Lead", leadId);
  const actual = filas[0];
  if (!TRANSICIONES_PIPELINE[actual.pipeline].includes(nuevoPipeline)) {
    throw new ErrorNegocio(
      `Transición de pipeline no permitida: ${actual.pipeline} → ${nuevoPipeline}`
    );
  }
  const filas2 = await repo.actualizar<Lead>(TABLAS.leads, { pipeline: nuevoPipeline, actualizado_en: new Date().toISOString() }, { id: leadId });
  const actualizado = filas2[0];
  if (usuarioId) {
    const auditoria = await import("./audit");
    await auditoria.registrarAccion(repo, {
      user_id: usuarioId,
      accion: "mover_pipeline",
      entidad: TABLAS.leads,
      entidad_id: leadId,
      detalle: { de: actual.pipeline, a: nuevoPipeline },
    }).catch(() => undefined);
  }
  return actualizado;
}

/* -------------------- Interacciones ---------------- */

export const ENTRADA_INTERACCION_SCHEMA = z.object({
  entidad_tipo: z.enum(["lead", "customer"]),
  entidad_id: z.string().uuid(),
  canal: z.enum(["web", "correo", "telefono", "presencial"]),
  resumen: z.string().min(1, "El resumen de la interacción es obligatorio"),
});

export async function registrarInteraccion(
  repo: Repositorio,
  entrada: unknown,
  usuarioId?: string | null
): Promise<Interaccion> {
  const datos = parsear(ENTRADA_INTERACCION_SCHEMA, entrada, "Interacción inválida");
  return repo.insertar<Interaccion>(TABLAS.interacciones, {
    ...datos,
    creado_por: usuarioId ?? null,
    creado_en: new Date().toISOString(),
  });
}

export async function listarInteracciones(
  repo: Repositorio,
  entidad: { tipo: "lead" | "customer"; id: string }
): Promise<Interaccion[]> {
  return repo.seleccionar<Interaccion>(TABLAS.interacciones, {
    eq: { entidad_tipo: entidad.tipo, entidad_id: entidad.id },
    ordenarPor: { columna: "creado_en", asc: false },
  });
}
