/**
 * Generador de CSV (paridad de export-csv en Deno y Express, SDD §3.2).
 * Delimitador `;` para Excel en español (es-ES usa `;` como separador),
 * BOM UTF-8 para acentos correctos en Excel, escape estándar RFC 4180.
 */
import { tablaSegura, type Tabla } from "./repositorio";

// BOM (Byte Order Mark) para que Excel respete UTF-8.
const BOM = "\uFEFF";

function escaparCelda(valor: unknown, delim: string): string {
  if (valor === null || valor === undefined) return "";
  let texto: string;
  if (Array.isArray(valor)) texto = valor.join(";");
  else if (typeof valor === "object") texto = JSON.stringify(valor);
  else texto = String(valor);
  texto = texto.replace(/\r?\n/g, "\n"); // normalizar saltos
  const necesitaComillas =
    texto.includes('"') || texto.includes(delim) || texto.includes("\n");
  if (necesitaComillas) {
    texto = '"' + texto.replace(/"/g, '""') + '"';
  }
  return texto;
}

/** Convierte un conjunto dinámico de filas a CSV. */
export function filasACSV(
  filas: Record<string, unknown>[],
  opciones?: { delim?: string; incluirBom?: boolean }
): string {
  const delim = opciones?.delim ?? ";";
  const bom = opciones?.incluirBom === false ? "" : BOM;
  if (filas.length === 0) return bom;

  // Encabezados: unión ordenada de claves (orden de primera aparición).
  const encabezados: string[] = [];
  for (const fila of filas) {
    for (const clave of Object.keys(fila)) {
      if (!encabezados.includes(clave)) encabezados.push(clave);
    }
  }
  const lineas = [
    encabezados.map((h) => escaparCelda(h, delim)).join(delim),
    ...filas.map((fila) =>
      encabezados.map((h) => escaparCelda(fila[h], delim)).join(delim)
    ),
  ];
  return bom + lineas.join("\n");
}

/** Nombre de archivo sugerido con fecha (p. ej. products_2026-10-24.csv). */
export function nombreArchivoCSV(tabla: string): string {
  const segura = tablaSegura(tabla);
  const fecha = new Date().toISOString().slice(0, 10);
  return `${segura}_${fecha}.csv`;
}

/** Un 'export' válido solo sobre tablas conocidas (seguridad: tablas de código). */
export function validarTablaExport(tabla: string): Tabla {
  return tablaSegura(tabla);
}
