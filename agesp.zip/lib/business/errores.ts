/**
 * Errores de dominio tipados (SDD §5, brief AGENTE-2 §1):
 * los módulos de /lib/business lanzan SIEMPRE errores de esta jerarquía
 * y los wrappers Deno/Express los traducen a respuestas HTTP JSON en español.
 * Idioma: español (decisión D9).
 */

export class ErrorDominio extends Error {
  /** Código estable para consumidores (p. ej. "validacion"). */
  readonly codigo: string;
  /** Estado HTTP sugerido para los wrappers. */
  readonly estadoHTTP: number;

  constructor(mensaje: string, codigo: string, estadoHTTP = 400) {
    super(mensaje);
    this.name = "ErrorDominio";
    this.codigo = codigo;
    this.estadoHTTP = estadoHTTP;
  }
}

/** Entrada inválida (Zod falló, campos faltantes). → HTTP 400 */
export class ErrorValidacion extends ErrorDominio {
  readonly detalles?: Record<string, string[]>;
  constructor(mensaje = "Datos de entrada inválidos", detalles?: Record<string, string[]>) {
    super(mensaje, "validacion", 400);
    this.detalles = detalles;
  }
}

/** Recurso no hallado. → HTTP 404 */
export class ErrorNoEncontrado extends ErrorDominio {
  constructor(recurso = "Recurso", id?: string) {
    super(`${recurso} no encontrado${id ? ` (${id})` : ""}`, "no_encontrado", 404);
  }
}

/** Falta identidad/token. → HTTP 401 */
export class ErrorNoAutorizado extends ErrorDominio {
  constructor(mensaje = "Autenticación requerida") {
    super(mensaje, "no_autorizado", 401);
  }
}

/** Identificado pero sin rol suficiente. → HTTP 403 */
export class ErrorPermisos extends ErrorDominio {
  constructor(mensaje = "Permisos insuficientes para esta operación") {
    super(mensaje, "permisos_insuficientes", 403);
  }
}

/** Regla de negocio incumplida (stock, moneda, estado…). → HTTP 409 */
export class ErrorNegocio extends ErrorDominio {
  constructor(mensaje: string, estadoHTTP = 409) {
    super(mensaje, "negocio", estadoHTTP);
  }
}

/** No disponible en este target (paridad documentada, D2). → HTTP 501 */
export class ErrorNoDisponible extends ErrorDominio {
  constructor(mensaje = "Función no disponible en este objetivo de despliegue") {
    super(mensaje, "no_disponible", 501);
  }
}

/** Traducción del error de dominio a un cuerpo JSON estándar (español). */
export function errorAJSON(error: unknown): {
  cuerpo: { error: string; codigo: string; detalles?: Record<string, string[]> };
  estado: number;
} {
  if (error instanceof ErrorDominio) {
    return {
      estado: error.estadoHTTP,
      cuerpo: {
        error: error.message,
        codigo: error.codigo,
        ...(error instanceof ErrorValidacion && error.detalles
          ? { detalles: error.detalles }
          : {}),
      },
    };
  }
  // Nunca filtrar detalles internos desconocidos al cliente.
  console.error("[errores] Error inesperado:", error);
  return {
    estado: 500,
    cuerpo: { error: "Error interno del servidor", codigo: "interno" },
  };
}
