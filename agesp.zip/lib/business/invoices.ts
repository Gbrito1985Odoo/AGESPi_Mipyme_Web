/**
 * Facturación (SDD M5): numeración secuencial por serie en transacción
 * (guardado por la restricción UNIQUE(serie, numero)), datos fiscales y
 * delegación del PDF al módulo pdf.ts. Solo Repositorio (portable).
 */
import { z } from "zod";
import type { Factura, Pedido } from "../types";
import { ErrorNegocio, ErrorNoEncontrado } from "./errores";
import { parsear } from "./validacion";
import { TABLAS, type Repositorio } from "./repositorio";
import { obtenerPedido } from "./orders";
import { registrarAccion } from "./audit";

export const ENTRADA_FACTURA_SCHEMA = z.object({
  pedido_id: z.string().uuid(),
  serie: z.string().min(1).max(4).default("A"),
  /** Datos fiscales que irán al PDF (NIT, nombre de la entidad, dirección…). */
  datos_fiscales: z.record(z.string(), z.string()).default({}),
  usuario_id: z.string().uuid().nullable().optional(),
});

export interface CrearFacturaEntrada {
  pedido_id: string;
  serie?: string;
  datos_fiscales?: Record<string, string>;
  usuario_id?: string | null;
}

export interface ResultadoFactura {
  factura: Factura;
  /** El PDF se genera aparte (pdf.ts) para no acoplar la facturación a la librería. */
  pedido: Pedido;
}

/**
 * Emite la factura para un pedido: número secuencial por serie dentro de la
 * transacción. La restricción UNIQUE(serie, numero) es el arbitro final contra
 * carreras; ante conflicto se lanza ErrorNegocio para reintento idempotente.
 */
export async function emitirFactura(
  repo: Repositorio,
  entrada: unknown
): Promise<ResultadoFactura> {
  const datos = parsear(ENTRADA_FACTURA_SCHEMA, entrada, "Entrada de factura inválida");

  return repo.transaccion(async (trx) => {
    const pedido = await obtenerPedido(trx, datos.pedido_id);

    // Solo se factura un pedido pagado o entregado (regla M5); «pendiente» y
    // «confirmado» aún no tienen contraprestación.
    if (pedido.estado !== "pagado" && pedido.estado !== "entregado") {
      throw new ErrorNegocio(
        `Solo se puede facturar un pedido pagado o entregado (pedido ${pedido.id} está en estado ${pedido.estado})`
      );
    }

    // Filas ya facturadas para este pedido (una factura por pedido).
    const previas = await repo.seleccionar<Factura>(TABLAS.facturas, {
      eq: { pedido_id: pedido.id },
      limite: 1,
    });
    if (previas.length > 0) {
      throw new ErrorNegocio(
        `El pedido ${pedido.id} ya tiene factura (serie ${previas[0].serie}, número ${previas[0].numero})`
      );
    }

    // Numeración secuencial por serie: consecutivo = máximo + 1.
    const filasSerie = await repo.seleccionar<Factura>(TABLAS.facturas, {
      eq: { serie: datos.serie },
      ordenarPor: { columna: "numero", asc: false },
      limite: 1,
    });
    const numero = (filasSerie.length ? Number(filasSerie[0].numero) : 0) + 1;

    try {
      const factura = await trx.insertar<Factura>(TABLAS.facturas, {
        pedido_id: pedido.id,
        serie: datos.serie,
        numero,
        customer_id: pedido.customer_id ?? null,
        moneda: pedido.moneda,
        total: pedido.total,
        datos_fiscales: datos.datos_fiscales ?? {},
        creado_en: new Date().toISOString(),
      });

      if (datos.usuario_id) {
        await registrarAccion(trx, {
          user_id: datos.usuario_id,
          accion: "factura_emitida",
          entidad: TABLAS.facturas,
          entidad_id: factura.id,
          detalle: {
            serie: datos.serie,
            numero,
            pedido_id: pedido.id,
            total: pedido.total,
          },
        }).catch(() => undefined);
      }

      return { factura, pedido };
    } catch (e) {
      const msg = e instanceof Error ? e.message : String(e);
      if (/unique|invoices_serie_numero/i.test(msg)) {
        throw new ErrorNegocio(
          `Conflicto de numeración en serie ${datos.serie}; reintente la emisión`
        );
      }
      throw e;
    }
  });
}

export async function obtenerFactura(
  repo: Repositorio,
  facturaId: string
): Promise<Factura> {
  const filas = await repo.seleccionar<Factura>(TABLAS.facturas, {
    eq: { id: facturaId },
    limite: 1,
  });
  if (filas.length === 0) throw new ErrorNoEncontrado("Factura", facturaId);
  return filas[0];
}

export interface FiltrosFactura {
  customer_id?: string;
  pedido_id?: string;
  serie?: string;
  limite?: number;
}

export async function listarFacturas(
  repo: Repositorio,
  filtros: FiltrosFactura = {}
): Promise<Factura[]> {
  const eq: Record<string, unknown> = {};
  if (filtros.customer_id) eq.customer_id = filtros.customer_id;
  if (filtros.pedido_id) eq.pedido_id = filtros.pedido_id;
  if (filtros.serie) eq.serie = filtros.serie;
  return repo.seleccionar<Factura>(TABLAS.facturas, {
    eq: Object.keys(eq).length ? eq : undefined,
    ordenarPor: { columna: "creado_en", asc: false },
    limite: filtros.limite,
  });
}
