/**
 * Helper de validación Zod (SDD §7: validación en cliente y servidor).
 * Traduce ZodError → ErrorValidacion con detalles en español.
 */
import { z } from "zod";
import { ErrorValidacion } from "./errores";

type EsquemaZod = z.ZodTypeAny;

export function parsear<S extends EsquemaZod>(
  esquema: S,
  dato: unknown,
  mensaje = "Datos de entrada inválidos"
): z.infer<S> {
  const resultado = esquema.safeParse(dato);
  if (!resultado.success) {
    const detalles: Record<string, string[]> = {};
    for (const problema of resultado.error.issues) {
      const clave = problema.path.join(".") || "(raíz)";
      (detalles[clave] ??= []).push(problema.message);
    }
    throw new ErrorValidacion(mensaje, detalles);
  }
  return resultado.data;
}
