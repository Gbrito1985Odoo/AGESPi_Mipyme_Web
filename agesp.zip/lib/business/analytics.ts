/**
 * Analytics de encuestas (SDD M4/M6): agregados sobre `responses` a partir
 * de filtros. Lógica pura: recibe repositorio + los datos ya consultados
 * son filtrados por defecto (fecha, tipo de entidad vía customers, survey).
 */
import { z } from "zod";
import type { Pregunta, RespuestaEncuesta } from "../types";
import { parsear } from "./validacion";
import { TABLAS, type Repositorio } from "./repositorio";

export const FILTROS_ANALYTICS_SCHEMA = z.object({
  survey_id: z.string().uuid(),
  desde: z.string().datetime().optional(),
  hasta: z.string().datetime().optional(),
  /** Un solo filtro por otra survey/pregunta/pregunta_id documentado en D1: primero survey, luego opcional pregunta. */
  pregunta_id: z.string().uuid().optional(),
});

export interface FiltrosAnalyticsEntrada {
  survey_id: string;
  desde?: string;
  hasta?: string;
  pregunta_id?: string;
}

/* ---------- Resultados ---------- */

export interface AgregadoPreguntaNumerica {
  tipo: "numerica" | "likert" | "escala";
  pregunta_id: string;
  texto: string;
  respuestaOkCount: number;
  media: number;
  mediana: number;
  min: number;
  max: number;
}

export interface AgregadoPreguntaOpciones {
  tipo: "seleccion" | "seleccion_multiple" | "si_no";
  pregunta_id: string;
  texto: string;
  /** Conteo por valor de opción (valor: { etiqueta, conteo }). */
  distribucion: Record<string, { etiqueta: string; conteo: number }>;
  sinRespuesta: number;
}

export interface AgregadoTexto {
  tipo: "texto" | "fecha";
  pregunta_id: string;
  texto: string;
  /** Primeras respuestas orgánicas (para revisión manual; sin una analítica automática). */
  muestra: string[];
  respondentCount: number;
}

export interface ResultadoAnalytics {
  survey_id: string;
  total_respuestas: number;
  /** Timestamp ISO desde/hasta aplicados (normalizados). */
  rango: { desde?: string; hasta?: string };
  por_pregunta: Array<AgregadoPreguntaNumerica | AgregadoPreguntaOpciones | AgregadoTexto>;
}

/* ---------- Agregados ---------- */

/** Calcula la distribución de opciones y la media/mediana de la respuesta. */
export async function calcularAnalytics(
  repo: Repositorio,
  filtros: FiltrosAnalyticsEntrada | unknown
): Promise<ResultadoAnalytics> {
  const f = parsear(FILTROS_ANALYTICS_SCHEMA, filtros, "Filtros de analytics inválidos");

  // 1) Respuestas de la encuesta (fecha de creación rango).
  const respuestas = await repo.seleccionar<RespuestaEncuesta>(TABLAS.respuestas, {
    eq: { survey_id: f.survey_id },
    ordenarPor: { columna: "creado_en", asc: false },
  });

  const enRango = respuestas.filter((r) => {
    const ts = new Date(r.creado_en).getTime();
    if (Number.isNaN(ts)) return false;
    if (f.desde && ts < new Date(f.desde).getTime()) return false;
    if (f.hasta && ts > new Date(f.hasta).getTime()) return false;
    return true;
  });

  // 2) Preguntas de la encuesta para conocer tipo.
  const preguntas = await repo.seleccionar<Pregunta>(TABLAS.preguntas, {
    eq: { survey_id: f.survey_id },
    ordenarPor: { columna: "posicion", asc: true },
  });

  const porPregunta = await Promise.all(
    preguntas
      .filter((p) => !f.pregunta_id || p.id === f.pregunta_id)
      .map((p) => agregarPregunta(repo, p, enRango))
  );

  // 3) Rango normalizado aplicado.
  const rango = { desde: f.desde, hasta: f.hasta };
  return {
    survey_id: f.survey_id,
    total_respuestas: enRango.length,
    rango,
    por_pregunta: porPregunta,
  };
}

async function agregarPregunta(
  repo: Repositorio,
  pregunta: Pregunta,
  respuestas: RespuestaEncuesta[]
): Promise<AgregadoPreguntaNumerica | AgregadoPreguntaOpciones | AgregadoTexto> {
  const valores = respuestas
    .map((r) => r.datos?.[pregunta.id])
    .filter((v) => v !== undefined && v !== null);

  const tipoTexto = pregunta.tipo === "texto" || pregunta.tipo === "fecha";

  if (tipoTexto) {
    return {
      tipo: pregunta.tipo,
      pregunta_id: pregunta.id,
      texto: pregunta.texto,
      muestra: valores.slice(0, 10).map((v) => String(v)),
      respondentCount: valores.length,
    };
  }

  if (pregunta.tipo === "numerica" || pregunta.tipo === "likert" || pregunta.tipo === "escala") {
    const nums = valores
      .map((v) => (typeof v === "number" ? v : Number(v)))
      .filter((n) => Number.isFinite(n));
    if (nums.length === 0) {
      return {
        tipo: pregunta.tipo,
        pregunta_id: pregunta.id,
        texto: pregunta.texto,
        respuestaOkCount: 0,
        media: 0,
        mediana: 0,
        min: 0,
        max: 0,
      };
    }
    const orden = [...nums].sort((a, b) => a - b);
    const media = Math.round((nums.reduce((s, n) => s + n, 0) / nums.length) * 100) / 100;
    const mediana =
      orden.length % 2 === 0
        ? Math.round(((orden[orden.length / 2 - 1] + orden[orden.length / 2]) / 2) * 100) / 100
        : orden[(orden.length - 1) / 2];
    return {
      tipo: pregunta.tipo,
      pregunta_id: pregunta.id,
      texto: pregunta.texto,
      respuestaOkCount: nums.length,
      media,
      mediana,
      min: orden[0],
      max: orden[orden.length - 1],
    };
  }

  // selección / seleccion_multiple / si_no → distribución por valor.
  const opcionesDetalle = await repo.seleccionar<{
    valor: string;
    etiqueta: string;
  }>(TABLAS.opciones, { eq: { question_id: pregunta.id } });
  const etiquetas = new Map(opcionesDetalle.map((o) => [o.valor, o.etiqueta]));
  if (pregunta.tipo === "si_no") {
    etiquetas.set("si", "Sí");
    etiquetas.set("no", "No");
  }

  const distribucion: AgregadoPreguntaOpciones["distribucion"] = {};
  let sinRespuesta = 0;
  for (const v of valores) {
    if (Array.isArray(v)) {
      if (v.length === 0) sinRespuesta++;
      for (const valor of v) {
        const k = String(valor);
        const entrada = distribucion[k] ?? {
          etiqueta: etiquetas.get(k) ?? k,
          conteo: 0,
        };
        entrada.conteo++;
        distribucion[k] = entrada;
      }
    } else if (v !== "" && v !== null) {
      const k = String(v);
      const entrada = distribucion[k] ?? { etiqueta: etiquetas.get(k) ?? k, conteo: 0 };
      entrada.conteo++;
      distribucion[k] = entrada;
    } else {
      sinRespuesta++;
    }
  }

  return {
    tipo: pregunta.tipo,
    pregunta_id: pregunta.id,
    texto: pregunta.texto,
    distribucion,
    sinRespuesta,
  };
}

/* ---------- Series temporales (respuestas por día) ---------- */

export interface SerieTemporal {
  fecha: string;
  respuestas: number;
}

/** Series por día ISO de la encuesta (para gráficos de la vista admin). */
export function serieTemporal(respuestas: { creado_en: string }[]): SerieTemporal[] {
  const conteo = new Map<string, number>();
  for (const r of respuestas) {
    const fecha = new Date(r.creado_en).toISOString().slice(0, 10);
    conteo.set(fecha, (conteo.get(fecha) ?? 0) + 1);
  }
  return [...conteo.entries()]
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([fecha, n]) => ({ fecha, respuestas: n }));
}
