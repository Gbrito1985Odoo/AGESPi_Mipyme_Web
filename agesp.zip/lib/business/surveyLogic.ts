/**
 * Lógica de saltos de la encuesta (SDD §8.2, brief AGENTE-2 §1):
 * dado `questions[].metadata.show_if` y respuestas parciales, calcula qué
 * preguntas se muestran. Pure function — se usa en admin (constructor),
 * encuesta pública y minería. Casos de referencia: P6 se oculta si la
 * entidad no tiene personal de seguridad; P9 se muestra SIEMPRE (con o
 * sin medios técnicos).
 */
import type { Pregunta, PreguntaMetadata } from "../types";

/** Respuestas parciales: { [pregunta_id]: valor } */
export type RespuestasParciales = Record<string, unknown>;

/** Evaluación de un valor show_if. Normaliza comparaciones simples. */
export function valoresEquivalentes(
  valorRespuesta: unknown,
  valorEsperado: unknown
): boolean {
  // both null/undefined ⇒ considered equal only if explicitly null
  if (valorEsperado === null || valorEsperado === undefined) {
    return valorRespuesta === null || valorRespuesta === undefined;
  }
  if (typeof valorEsperado === "boolean") {
    return Boolean(valorRespuesta) === valorEsperado;
  }
  if (Array.isArray(valorEsperado)) {
    // la respuesta debe incluir todos los valores esperados
    const arr = Array.isArray(valorRespuesta) ? valorRespuesta : [valorRespuesta];
    return (valorEsperado as unknown[]).every((v) => arr.map(String).includes(String(v)));
  }
  if (typeof valorEsperado === "number") {
    return Number(valorRespuesta) === valorEsperado;
  }
  // string: caso especial boolean-as-string ("si"/"no")
  const esperado = String(valorEsperado).toLowerCase();
  const rta =
    typeof valorRespuesta === "boolean"
      ? valorRespuesta ? "si" : "no"
      : String(valorRespuesta ?? "").toLowerCase();
  return rta === esperado;
}

/** ¿Debe mostrarse la pregunta dadas las respuestas actuales? */
export function estaVisible(
  pregunta: Pregunta,
  respuestas: RespuestasParciales
): boolean {
  const showIf: PreguntaMetadata["show_if"] | undefined =
    pregunta.metadata?.show_if;
  if (!showIf || !showIf.pregunta_id) return true;
  const valorRespuesta = respuestas[showIf.pregunta_id];
  const visible = valoresEquivalentes(valorRespuesta, showIf.valor);
  // §8.2: si la condición no se cumple y la pregunta era forzada, mostrar igualmente.
  if (!visible && pregunta.metadata?.mostrar_igualmente) return true;
  return visible;
}

/** Todas las preguntas visibles en este estado (orden de `posicion`). */
export function preguntasVisibles(
  preguntas: Pregunta[],
  respuestas: RespuestasParciales
): Pregunta[] {
  return [...preguntas]
    .sort((a, b) => a.posicion - b.posicion)
    .filter((p) => estaVisible(p, respuestas));
}

/** Ids de las preguntas visibles (útil para la UI). */
export function idsVisibles(preguntas: Pregunta[], respuestas: RespuestasParciales): string[] {
  return preguntasVisibles(preguntas, respuestas).map((p) => p.id);
}

/**
 * Del estado actual, siguiente pregunta visible a responder (para
 * multi-paso con guardado de progreso, §8.2). Salta respondidas.
 */
export function siguientePregunta(
  preguntas: Pregunta[],
  respuestas: RespuestasParciales
): Pregunta | null {
  const visibles = preguntasVisibles(preguntas, respuestas);
  return (
    visibles.find((p) => respuestas[p.id] === undefined || respuestas[p.id] === null) ??
    null
  );
}

/**
 * Validación de paso: obligatorias visibles sin responder.
 * Devuelve las faltantes (vacío = se puede avanzar).
 */
export function obligatoriasPendientes(
  preguntas: Pregunta[],
  respuestas: RespuestasParciales
): string[] {
  return preguntasVisibles(preguntas, respuestas)
    .filter((p) => p.obligatoria)
    .filter((p) => respuestas[p.id] === undefined || respuestas[p.id] === null || respuestas[p.id] === "")
    .map((p) => p.texto);
}

/* ------------------------------------------------------------------ */
/* Reglas específicas de la encuesta AGESP (§8)                        */
/* ------------------------------------------------------------------ */

/**
 * Reglas duales documentadas (§8.2) para la encuesta integrada «¿Cómo
 * podemos ayudarle a sentirse más seguro?». Los ids "P5", "P6", "P9"
 * deben coincidir con el seed de AGENTE-1/4 (migración de Fase 4.5, D5).
 */
export const REGLAS_SALTO_AGESP = {
  /** ¿Cuenta su entidad con personal de seguridad? (pregunta previa a P6) */
  PREGUNTA_PERSONAL: "P5",
  /** P6 (fiscales) se oculta si NO tiene personal de seguridad. */
  P6: { id: "P6", show_if: { pregunta_id: "P5", valor: "si" } },
  /** P9 (medios técnicos/ciber) se muestra siempre, con o sin medios. */
  P9: { id: "P9", mostrarSiempre: true },
} as const;

/**
 * Aplica las reglas duales de P6/P9 a un conjunto de preguntas de la
 * encuesta AGESP. Utilizada cuando el seed no trae metadata completa o
 * cuando la minería necesita replicar exactamente la semántica del §8.2.
 */
export function aplicarReglasSaltosAGESP(
  preguntas: Pregunta[],
  respuestas: RespuestasParciales
): Pregunta[] {
  const tienePersonal = valoresEquivalentes(
    respuestas[REGLAS_SALTO_AGESP.PREGUNTA_PERSONAL],
    "si"
  );
  return preguntas.map((p) => {
    if (p.id === REGLAS_SALTO_AGESP.P6.id) {
      return { ...p, metadata: { ...p.metadata, show_if: REGLAS_SALTO_AGESP.P6.show_if } };
    }
    // P9: forzar visibilidad incondicional (mostrar_igualmente en metadata).
    if (p.id === REGLAS_SALTO_AGESP.P9.id) {
      return { ...p, metadata: { ...p.metadata, mostrar_igualmente: true } };
    }
    return p;
  }).filter((p) => {
    if (p.id === REGLAS_SALTO_AGESP.P6.id) {
      return tienePersonal || estaVisible(p, respuestas);
    }
    return true;
  });
}
