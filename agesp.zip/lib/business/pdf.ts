/**
 * Factura PDF (SDD M5): genera el PDF de la factura con `pdf-lib`.
 * Regla dura §2: los colores de la marca llegan como PARÁMETRO (nunca
 * hardcodeados); el llamador los toma de site_config en runtime.
 */
import { PDFDocument, StandardFonts, rgb, type RGB } from "pdf-lib";
import { z } from "zod";
import type { Factura, PedidoItem } from "../types";
import { parsear } from "./validacion";

const ENTRADA_PDF_SCHEMA = z.object({
  factura: z.record(z.string(), z.unknown()), // Factura
  items: z.array(z.record(z.string(), z.unknown())).default([]), // PedidoItem[]
  /** Paleta diplomática de site_config (colores hex, §2). */
  colores: z
    .object({
      primario: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#0B2E59"),
      texto: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#4A5568"),
      acento: z.string().regex(/^#[0-9a-fA-F]{6}$/).default("#F4C430"),
    })
    .default({}),
  /** Datos del emisor (encabezado del PDF). */
  emisor: z
    .object({
      nombre: z.string().default("AGESP"),
      razon: z.string().default("Agencia de Seguridad y Protección"),
      nit: z.string().default(""),
    })
    .default({}),
});

export interface EntradaPDF {
  factura: Factura;
  items: PedidoItem[];
  colores?: { primario?: string; texto?: string; acento?: string };
  emisor?: { nombre?: string; razon?: string; nit?: string };
}

function hexARGB(hex: string): RGB {
  const n = hex.replace("#", "");
  return rgb(
    parseInt(n.slice(0, 2), 16) / 255,
    parseInt(n.slice(2, 4), 16) / 255,
    parseInt(n.slice(4, 6), 16) / 255
  );
}

function formatearMonto(n: number): string {
  return n.toLocaleString("es-CU", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/**
 * Construye el PDF de la factura y devuelve sus bytes. El PDF usa fuentes
 * estándar Helvetica (no requiere embebidos). Layout: encabezado de marca en
 * primario con línea de acento, tabla de ítems snapshot y totales por moneda.
 */
export async function generarFacturaPDF(entrada: unknown): Promise<Uint8Array> {
  const datos = parsear(ENTRADA_PDF_SCHEMA, entrada, "Entrada de PDF inválida");
  const factura = datos.factura as unknown as Factura;
  const items = datos.items as unknown as PedidoItem[];

  const pdf = await PDFDocument.create();
  pdf.setTitle(`Factura ${factura.serie}-${factura.numero}`);
  pdf.setLanguage("es");
  pdf.setProducer("AGESP · Plataforma");

  const helvetica = await pdf.embedFont(StandardFonts.Helvetica);
  const helveticaBold = await pdf.embedFont(StandardFonts.HelveticaBold);

  let page = pdf.addPage([595, 842]); // A4 federal estándar 72dpi
  const { width, height } = page.getSize();
  const margen = 40;
  let y = height - 56;

  const colorPrimario = hexARGB(datos.colores.primario ?? "#0B2E59");
  const colorTexto = hexARGB(datos.colores.texto ?? "#4A5568");
  const colorAcento = hexARGB(datos.colores.acento ?? "#F4C430");

  const texto = (s: string, size = 10, bold = false, color = colorTexto) => {
    page.drawText(s, { x: margen, y, size, font: bold ? helveticaBold : helvetica, color });
    y -= size + 6;
  };

  /* Encabezado de marca (paleta por parámetro, §2). */
  page.drawRectangle({ x: 0, y: height - 90, width, height: 90, color: colorPrimario });
  page.drawRectangle({ x: 0, y: height - 96, width, height: 6, color: colorAcento });
  page.drawText(datos.emisor.nombre, { x: margen, y: height - 42, size: 20, font: helveticaBold, color: rgb(1, 1, 1) });
  page.drawText(datos.emisor.razon, { x: margen, y: height - 60, size: 10, font: helvetica, color: rgb(1, 1, 1) });
  if (datos.emisor.nit) {
    page.drawText(`NIT: ${datos.emisor.nit}`, { x: margen, y: height - 76, size: 9, font: helvetica, color: rgb(1, 1, 1) });
  }

  /* Datos de la factura. */
  y = height - 120;
  texto(`FACTURA ${factura.serie}-${factura.numero}`, 16, true, colorPrimario);
  texto(`Fecha de emisión: ${new Date(factura.creado_en).toLocaleString("es-CU")}`);
  texto(`Moneda: ${factura.moneda}`);
  texto(`Pedido: ${factura.pedido_id}`);

  /* Datos fiscales del cliente (§7, mapeados del jsonb). */
  const fiscales = factura.datos_fiscales ?? {};
  const lineasFiscales = Object.entries(fiscales);
  if (lineasFiscales.length > 0) {
    texto("Datos fiscales del receptor:", 11, true, colorPrimario);
    for (const [k, v] of lineasFiscales) texto(`${k}: ${v}`);
  }

  /* Tabla de ítems (snapshot histórico M5). */
  y -= 10;
  page.drawRectangle({ x: margen - 4, y: y - 16, width: width - 2 * margen + 8, height: 20, color: rgb(0.976, 0.976, 0.976) });
  page.drawText("Descripción", { x: margen, y: y - 10, size: 9, font: helveticaBold, color: colorPrimario });
  page.drawText("Cantidad", { x: width - margen - 210, y: y - 10, size: 9, font: helveticaBold, color: colorPrimario });
  page.drawText("Precio", { x: width - margen - 120, y: y - 10, size: 9, font: helveticaBold, color: colorPrimario });
  page.drawText("Importe", { x: width - margen - 60, y: y - 10, size: 9, font: helveticaBold, color: colorPrimario });
  y -= 18;

  for (const item of items) {
    // Salto de página si llega al pie.
    if (y < 80) {
      page.drawText("… (continua)", { x: margen, y: y - 4, size: 8, font: helvetica, color: colorTexto });
      page = pdf.addPage([595, 842]);
      y = height - 56;
    }
    const importe = item.precio_snapshot * item.cantidad;
    page.drawText(cortar(item.nombre_snapshot, 52), { x: margen, y, size: 10, font: helvetica, color: colorTexto });
    page.drawText(String(item.cantidad), { x: width - margen - 210, y, size: 10, font: helvetica, color: colorTexto });
    page.drawText(formatearMonto(Number(item.precio_snapshot)), { x: width - margen - 120, y, size: 10, font: helvetica, color: colorTexto });
    page.drawText(formatearMonto(importe), { x: width - margen - 60, y, size: 10, font: helveticaBold, color: colorTexto });
    y -= 16;
  }

  /* Total del pedido. */
  y -= 10;
  page.drawLine({
    start: { x: margen, y },
    end: { x: width - margen, y },
    thickness: 1,
    color: colorAcento,
  });
  y -= 22;
  texto(`TOTAL: ${formatearMonto(Number(factura.total))} ${factura.moneda}`, 14, true, colorPrimario);

  /* Pie legal y numeración. */
  texto("Documento emitido por el sistema AGESP. Mipyme Estatal Socialista.", 8);
  texto("Tiempo de entrega declarado por servicio (Art. 5 Res. 35/2020).", 8);

  return pdf.save();
}

/** Detecorta cortes de la cadena sin romper palabras (aprox. para Helvetica). */
function cortar(s: string, max: number): string {
  return s.length > max ? s.slice(0, max - 1) + "…" : s;
}
