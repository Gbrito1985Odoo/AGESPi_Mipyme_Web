/**
 * Carrito de compras (SDD M2): lógica pura compartida frontend/backend.
 * Reglas: cantidades enteras positivas, totales por ítem y global,
 * moneda única por pedido (CUP/MLC/USD configurable). Entradas validadas
 * con Zod; errores de dominio en español.
 */
import { z } from "zod";
import type { Moneda } from "../types";
import { ErrorNegocio } from "./errores";
import { parsear } from "./validacion";

export const MONEDA_SCHEMA = z.enum(["CUP", "MLC", "USD"]);

/** Ítem tal como entra al carrito (validado). */
export const ENTRADA_ITEM_SCHEMA = z.object({
  producto_id: z.string().uuid(),
  nombre: z.string().min(1, "El nombre es obligatorio"),
  precio: z.number().nonnegative("El precio no puede ser negativo"),
  moneda: MONEDA_SCHEMA,
  cantidad: z.number().int().positive("La cantidad debe ser un entero positivo"),
});
export type EntradaItem = z.infer<typeof ENTRADA_ITEM_SCHEMA>;

export interface ItemCarrito {
  producto_id: string;
  nombre: string;
  precio: number;
  moneda: Moneda;
  cantidad: number;
  /** Total de línea, calculado (precio × cantidad). */
  total: number;
}

export interface Carrito {
  /** Moneda fija del carrito (null mientras esté vacío). */
  moneda: Moneda | null;
  items: ItemCarrito[];
}

export const CARRITO_VACIO: Carrito = { moneda: null, items: [] };

/** Redondeo monetario a 2 decimales (evita errores de coma flotante). */
export function redondearMonto(valor: number): number {
  return Math.round((valor + Number.EPSILON) * 100) / 100;
}

function esItem(x: unknown): x is ItemCarrito {
  return (
    typeof x === "object" && x !== null &&
    typeof (x as ItemCarrito).producto_id === "string"
  );
}

/** Agrega (o acumula) un ítem. Lanza ErrorNegocio si la moneda difiere. */
export function agregarItem(carrito: Carrito, entrada: unknown): Carrito {
  const nueva = parsear(ENTRADA_ITEM_SCHEMA, entrada, "Ítem de carrito inválido");

  if (carrito.moneda && nueva.moneda !== carrito.moneda) {
    throw new ErrorNegocio(
      `El carrito solo admite una moneda (${carrito.moneda}); el ítem "${nueva.nombre}" está en ${nueva.moneda}`
    );
  }

  const existente = carrito.items.find((i) => i.producto_id === nueva.producto_id);
  const items = existente
    ? carrito.items.map((i) =>
        i.producto_id === nueva.producto_id
          ? { ...i, cantidad: i.cantidad + nueva.cantidad, total: redondearMonto(i.precio * (i.cantidad + nueva.cantidad)) }
          : i
      )
    : [
        ...carrito.items,
        { ...nueva, total: redondearMonto(nueva.precio * nueva.cantidad) },
      ];

  return { moneda: nueva.moneda, items };
}

/**
 * Cambia la cantidad de un ítem. `cantidad = 0` equivale a quitarlo.
 * Lanza ErrorNegocio si el producto no está en el carrito o la cantidad es inválida.
 */
export function actualizarCantidad(
  carrito: Carrito,
  productoId: string,
  cantidad: number
): Carrito {
  if (!Number.isInteger(cantidad) || cantidad < 0) {
    throw new ErrorNegocio("La cantidad debe ser un entero mayor o igual a 0");
  }
  if (!carrito.items.some((i) => i.producto_id === productoId)) {
    throw new ErrorNegocio("El producto no está en el carrito");
  }
  if (cantidad === 0) return quitarItem(carrito, productoId);

  return {
    moneda: carrito.moneda,
    items: carrito.items.map((i) =>
      i.producto_id === productoId
        ? { ...i, cantidad, total: redondearMonto(i.precio * cantidad) }
        : i
    ),
  };
}

/** Quita un ítem del carrito; si no existe, el resto queda igual. */
export function quitarItem(carrito: Carrito, productoId: string): Carrito {
  const items = carrito.items.filter((i) => i.producto_id !== productoId);
  return { moneda: items.length ? carrito.moneda : null, items };
}

export function vaciarCarrito(): Carrito {
  return { ...CARRITO_VACIO, items: [] };
}

/** Total global del carrito (ya redondeado). */
export function calcularTotal(carrito: Carrito): number {
  return redondearMonto(
    carrito.items.reduce((sum, i) => sum + i.total, 0)
  );
}

/**
 * Valida el carrito completo antes de crear el pedido:
 *  - tiene ítems,
 *  - moneda única (ya garantizada por agregar, doble comprobación),
 *  - sin guardas UI (ítems deberían revalidarse contra BD al ordenar).
 * Devuelve lista de problemas en español; vacía = carrito válido.
 */
export function validarCarrito(carrito: unknown): string[] {
  const problemas: string[] = [];
  if (!esItemArray(carrito)) return ["El carrito no tiene un formato válido"];
  const c = carrito as Carrito;

  if (!c.items || c.items.length === 0) problemas.push("El carrito está vacío");
  const monedas = new Set((c.items ?? []).map((i) => i.moneda));
  if (monedas.size > 1) {
    problemas.push(`El carrito mezcla monedas (${[...monedas].join(", ")}); se exige una sola por pedido`);
  }
  for (const i of c.items ?? []) {
    if (!(i.cantidad > 0)) problemas.push(`Cantidad inválida para "${i.nombre}"`);
    if (typeof i.precio !== "number" || i.precio < 0)
      problemas.push(`Precio inválido para "${i.nombre}"`);
  }
  return problemas;
}

function esItemArray(x: unknown): boolean {
  return (
    typeof x === "object" && x !== null &&
    "items" in (x as Record<string, unknown>) &&
    Array.isArray((x as Carrito).items)
  );
}

/**
 * Estado final del carrito listo para `orders.crearPedidoDesdeCarrito`:
 * moneda, total y líneas de detalle.
 */
export function carritoAPedido(carrito: Carrito): {
  moneda: Moneda;
  total: number;
  items: { producto_id: string; nombre: string; precio: number; cantidad: number }[];
} {
  const problemas = validarCarrito(carrito);
  if (problemas.length > 0) {
    throw new ErrorNegocio(`Carrito inválido: ${problemas.join(" · ")}`);
  }
  return {
    moneda: carrito.moneda as Moneda,
    total: calcularTotal(carrito),
    items: carrito.items.map(({ producto_id, nombre, precio, cantidad }) => ({
      producto_id, nombre, precio, cantidad,
    })),
  };
}
