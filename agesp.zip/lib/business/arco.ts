/**
 * Derechos ARCO de protección de datos (SDD §7, Ley 149):
 * Acceso, Rectificación, Cancelación/Eliminación, Oposición.
 * Cada función opera SOLO con Repositorio (portable supabase/local),
 * audita la solicitud en `audit_log` (acción "arco") y devuelve guías de
 * acción concretas para el operador/administrador. Garantía dura: nunca
 * filtra tax_id en claro; la columna cifrada no sale por estas rutas y su
 * lectura con decrypt_tax_id queda reservada al admin por SQL.
 */
import { z } from "zod";
import type { Customer, RegistroAuditoria } from "../types";
import { ErrorNoEncontrado, ErrorNegocio } from "./errores";
import { parsear } from "./validacion";
import { TABLAS, type Repositorio } from "./repositorio";
import { registrarAccion } from "./audit";

export const TIPO_ARCO_SCHEMA = z.enum(["acceso", "rectificar", "borrar", "oponer"]);

export const ENTRADA_ARCO_SCHEMA = z.object({
  tipo: TIPO_ARCO_SCHEMA,
  /** Identificación del titular: id interno o correo del contacto. */
  customer_id: z.string().uuid().optional(),
  correo: z.string().email().optional(),
  /** Extensión del pedido cuando aplica (p. ej. campos a rectificar). */
  detalle: z.record(z.unknown()).default({}),
  usuario_id: z.string().uuid().nullable().optional(),
});

export interface EntradaARCO {
  tipo: "acceso" | "rectificar" | "borrar" | "oponer";
  customer_id?: string;
  correo?: string;
  detalle: Record<string, unknown>;
  usuario_id?: string | null;
}

export interface ResultadoARCO {
  tipo: EntradaARCO["tipo"];
  /** Datos personales visibles (solo para «acceso»; sin tax_id en claro). */
  datos?: Record<string, unknown> | null;
  /** Acciones concretas para el operador/admin. */
  acciones: string[];
  registro: RegistroAuditoria;
}

async function clientePorIdentidad(
  repo: Repositorio,
  { customer_id, correo }: EntradaARCO
): Promise<Customer> {
  if (customer_id) {
    const filas = await repo.seleccionar<Customer>(TABLAS.clientes, {
      eq: { id: customer_id },
      limite: 1,
    });
    if (filas.length > 0) return filas[0];
  }
  if (correo) {
    const filas = await repo.seleccionar<Customer>(TABLAS.clientes, {
      eq: { correo },
      limite: 1,
    });
    if (filas.length > 0) return filas[0];
  }
  throw new ErrorNoEncontrado(
    "Titular de datos",
    customer_id ?? correo ?? "(sin identificación)"
  );
}

/** Punto de entrada de /api/arco/* — procesa el derecho solicitado. */
export async function procesarSolicitudARCO(
  repo: Repositorio,
  entrada: unknown
): Promise<ResultadoARCO> {
  const datos = parsear(ENTRADA_ARCO_SCHEMA, entrada, "Solicitud ARCO inválida");

  return repo.transaccion(async (trx) => {
    const cliente = await clientePorIdentidad(trx, datos);

    /* --- DERECHOS DE ACCESO (tipo=acceso) --- */
    if (datos.tipo === "acceso") {
      const datosVisibles = {
        nombre: cliente.nombre,
        tipo_entidad: cliente.tipo_entidad,
        domicilio: cliente.domicilio,
        codigo_postal: cliente.codigo_postal,
        telefono: cliente.telefono,
        correo: cliente.correo,
        credencial: cliente.credencial,
        consentimiento_aceptado: cliente.consentimiento_aceptado,
        creado_en: cliente.creado_en,
        // NOTA (§7): se excluye tax_id_cifrado — la ley y la trazabilidad fiscal
        // no exigen exponerlo; para mostrarlo el ADMIN usaría decrypt_tax_id por SQL.
      };
      const res = await auditarARCO(trx, datos, cliente, "acceso");
      return {
        tipo: "acceso",
        datos: datosVisibles,
        acciones: [
          "Entrega al titular la copia de los datos personales que obran en AGESP.",
          "Registra la entrega y fecha en acta del RFC (archivo del expediente del cliente).",
        ],
        registro: res,
      };
    }

    /* --- RECTIFICACIÓN (tipo=rectificar) --- */
    if (datos.tipo === "rectificar") {
      // Solo campos permitidos de la tabla customers (tax_id va cifrado y solo cambia por SQL).
      const CAMPOS = ["nombre", "domicilio", "codigo_postal", "telefono", "correo", "credencial"] as const;
      const cambios: Record<string, unknown> = {};
      for (const campo of CAMPOS) {
        if (datos.detalle[campo] !== undefined) cambios[campo] = datos.detalle[campo];
      }
      const claves = Object.keys(cambios);
      if (claves.length === 0) {
        throw new ErrorNegocio(
          `No se enviaron campos rectificables (permitidos: ${CAMPOS.join(", ")})`
        );
      }
      const filas = await trx.actualizar<Customer>(
        TABLAS.clientes,
        { ...cambios, actualizado_en: new Date().toISOString() },
        { id: cliente.id }
      );
      if (filas.length === 0) throw new ErrorNoEncontrado("Titular de datos", cliente.id);

      const res = await auditarARCO(trx, datos, cliente, "rectificar", claves);
      return {
        tipo: "rectificar",
        acciones: [
          `Campos actualizados: ${claves.join(", ")}.`,
          "Notifica al titular por el canal de su solicitud la rectificación realizada.",
        ],
        registro: res,
      };
    }

    /* --- CANCELACIÓN / ELIMINACIÓN (tipo=borrar) --- */
    if (datos.tipo === "borrar") {
      /* Supuesto §7: el borrado duro del tax_id implicaría romper la trazabilidad
       * fiscal (Art. 149). Se aplica deslinkeo de servicios (usuario_id=null,
       * consentimiento_aceptado=false) y anonimización, con borrado definitivo
       * aprobado por admin (comprueba sus retenciones legales). */
      await trx.actualizar<Customer>(
        TABLAS.clientes,
        { usuario_id: null, consentimiento_aceptado: false, actualizado_en: new Date().toISOString() },
        { id: cliente.id }
      );
      const res = await auditarARCO(trx, datos, cliente, "borrar");
      return {
        tipo: "borrar",
        acciones: [
          "Revoca el acceso del titular y desliga sus servicios (usuario_id = null).",
          "El admin evalúa retenciones legales (facturación, contabilidad) antes de eliminar registros.",
          "Si no aplica retención, se planifica el borrado físico en un mantenimiento con respaldo previo.",
        ],
        registro: res,
      };
    }

    /* --- OPOSICIÓN (tipo=oponer) --- */
    const res = await auditarARCO(trx, datos, cliente, "oponer");
    return {
      tipo: "oponer",
      acciones: [
        "Cesa el envío de comunicaciones comerciales al titular (lista de exclusión).",
        "Registra la objeción en el expediente del cliente y ajusta la segmentación de marketing.",
      ],
      registro: res,
    };
  });
}

/* ---------- Auditoría (best-effort, D7) ---------- */

async function auditarARCO(
  repo: Repositorio,
  datos: EntradaARCO,
  cliente: Customer,
  accionARCO: string,
  campos?: string[]
): Promise<RegistroAuditoria> {
  const detalle: Record<string, unknown> = {
    tipo_arco: datos.tipo,
    tipo_entidad: cliente.tipo_entidad,
    titular: cliente.id,
    campos: campos ?? null,
  };
  // Sin datos en claro; el detalle solo enumera claves (no valores personales).
  return repo.insertar<RegistroAuditoria>(TABLAS.auditoria, {
    user_id: datos.usuario_id ?? null,
    accion: "arco",
    entidad: TABLAS.clientes,
    entidad_id: cliente.id,
    detalle,
    creado_en: new Date().toISOString(),
  });
}
