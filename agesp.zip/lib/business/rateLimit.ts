/**
 * Rate limiting simple en memoria por clave/IP (SDD §7).
 * Ventana fija: suficiente para MVP y compartible entre Deno y Node
 * porque no depende de almacenamiento externo.
 * Nota: en instancias múltiples (serverless) la ventana es por instancia.
 */

export interface ConfigLimite {
  /** Máximo de peticiones por ventana. */
  maximo: number;
  /** Duración de la ventana en ms. */
  ventanaMs: number;
}

export interface ResultadoLimite {
  permitido: boolean;
  restantes: number;
  /** Milisegundos hasta el reinicio de la ventana. */
  reinicioEnMs: number;
}

interface RegistroVentana {
  inicio: number;
  cuenta: number;
}

export type Limitador = {
  /** Verifica (y al aplicar si es permitido) el límite para una clave. */
  verificar: (clave: string) => ResultadoLimite;
  /** Tamaño actual de la tabla (solo para tests). */
  tamano: () => number;
};

export function crearLimitador(config: ConfigLimite): Limitador {
  const { maximo, ventanaMs } = config;
  const ventanas = new Map<string, RegistroVentana>();

  return {
    verificar(clave: string): ResultadoLimite {
      const ahora = Date.now();
      let registro = ventanas.get(clave);

      if (!registro || ahora - registro.inicio >= ventanaMs) {
        registro = { inicio: ahora, cuenta: 0 };
        ventanas.set(clave, registro);
        // Mantenimiento perezoso para no crecer indefinidamente.
        if (ventanas.size > 10_000) {
          for (const [k, v] of ventanas) {
            if (ahora - v.inicio >= ventanaMs) ventanas.delete(k);
          }
        }
      }

      registro.cuenta += 1;
      const restantes = Math.max(0, maximo - registro.cuenta);
      return {
        permitido: registro.cuenta <= maximo,
        restantes,
        reinicioEnMs: ventanaMs - (ahora - registro.inicio),
      };
    },
    tamano: () => ventanas.size,
  };
}

/** Extrae una clave de cliente de los encabezados habituales detrás de proxy. */
export function claveCliente(headers: {
  get(nombre: string): string | null;
}): string {
  const reenviada = headers.get("x-forwarded-for");
  if (reenviada) return reenviada.split(",")[0].trim();
  return headers.get("x-real-ip") ?? "desconocida";
}
