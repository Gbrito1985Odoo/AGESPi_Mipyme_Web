/**
 * Auditoría de acciones críticas (SDD M6, §7 y decisión D7).
 * `audit_log` es append-only (trigger rechaza UPDATE/DELETE); la única
 * excepción documentada es `super_admin` (política RLS de AGENTE-1).
 * Este módulo solo INSERTA, nunca modifica ni borra.
 */
import { z } from "zod";
import type { RegistroAuditoria } from "../types";
import { parsear } from "./validacion";
import { TABLAS, type Repositorio } from "./repositorio";

/** Acciones críticas estándar (SDD M6): extensibles sin romper el contrato. */
export const ACCIONES_CONOCIDAS = [
  "login",
  "cambio_precio",
  "export",
  "crear_producto",
  "ajuste_stock",
  "mover_pipeline",
  "factura_emitida",
  "arco",
  "regenerate_qr",
] as const;

export const ENTRADA_AUDITORIA_SCHEMA = z.object({
  user_id: z.string().uuid().nullable().optional(),
  accion: z.string().min(3),
  entidad: z.string().nullable().optional(),
  entidad_id: z.string().nullable().optional(),
  detalle: z.record(z.unknown()).nullable().optional(),
});

export interface EntradaAuditoria {
  user_id?: string | null;
  accion: string;
  entidad?: string | null;
  entidad_id?: string | null;
  detalle?: Record<string, unknown> | null;
}

/**
 * Registra una acción crítica. Devuelve la fila insertada.
 * Nunca lastra la operación principal: los wrappers llaman con
 * `.catch(() => undefined)` cuando la auditoría es best-effort.
 */
export async function registrarAccion(
  repo: Repositorio,
  entrada: EntradaAuditoria
): Promise<RegistroAuditoria> {
  const datos = parsear(ENTRADA_AUDITORIA_SCHEMA, entrada, "Entrada de auditoría inválida");
  return repo.insertar<RegistroAuditoria>(TABLAS.auditoria, {
    user_id: datos.user_id ?? null,
    accion: datos.accion,
    entidad: datos.entidad ?? null,
    entidad_id: datos.entidad_id ?? null,
    detalle: datos.detalle ?? null,
    creado_en: new Date().toISOString(),
  });
}

/** Lista auditoría para el panel admin (solo lectura; D7: append-only). */
export async function listarAuditoria(
  repo: Repositorio,
  filtros?: { accion?: string; user_id?: string; limite?: number }
): Promise<RegistroAuditoria[]> {
  const eq: Record<string, unknown> = {};
  if (filtros?.accion) eq.accion = filtros.accion;
  if (filtros?.user_id) eq.user_id = filtros.user_id;
  return repo.seleccionar<RegistroAuditoria>(TABLAS.auditoria, {
    eq: Object.keys(eq).length ? eq : undefined,
    ordenarPor: { columna: "creado_en", asc: false },
    limite: filtros?.limite,
  });
}
