/**
 * Puerto de acceso a datos de la capa business (brief AGENTE-2 §1):
 * las funciones de negocio NO se acoplan a un adaptador concreto; reciben
 * un `Repositorio` como parámetro. Las implementaciones adaptadoras viven:
 *  - Target supabase → supabase/functions/_shared/repositorio.ts (Deno)
 *  - Target local    → server/local/repositorioLocal.ts (Node/pg)
 *  - Tests           → mocks en tests/business/
 *
 * Estructura de opciones idéntica a lib/db (SDD §3.1).
 */

export interface FiltrosSeleccionar {
  columnas?: string;
  ordenarPor?: { columna: string; asc?: boolean };
  limite?: number;
  eq?: Record<string, unknown>;
  single?: boolean;
}

export interface Repositorio {
  target: string;
  seleccionar<T = unknown>(
    tabla: string,
    opts?: FiltrosSeleccionar
  ): Promise<T[]>;
  /** Inserta una fila y devuelve la fila creada (con id). */
  insertar<T = unknown>(
    tabla: string,
    fila: Record<string, unknown>
  ): Promise<T>;
  /** Actualiza con condiciones de igualdad; devuelve las filas afectadas. */
  actualizar<T = unknown>(
    tabla: string,
    valores: Record<string, unknown>,
    eq: Record<string, unknown>
  ): Promise<T[]>;
  /**
   * Ejecuta `fn` con un repositorio de transacción. Para el target local
   * es atómico (BEGIN/COMMIT + SET LOCAL app.user_id); para supabase se
   * ejecuta secuencialmente (documentación de paridad, BACKEND-PARITY.md).
   */
  transaccion<T>(fn: (trx: Repositorio) => Promise<T>): Promise<T>;
}

/** Nombres canónicos de tablas (SDD §4.2; coincide con db/schema de AGENTE-1). */
export const TABLAS = {
  perfiles: "profiles",
  clientes: "customers",
  productos: "products",
  categorias: "categories",
  pedidos: "orders",
  pedidosItems: "order_items",
  facturas: "invoices",
  encuestas: "surveys",
  preguntas: "questions",
  opciones: "question_options",
  respuestas: "responses",
  asignaciones: "survey_assignments",
  leads: "leads",
  interacciones: "interactions",
  auditoria: "audit_log",
  configSitio: "site_config",
  plantillasCorreo: "email_templates",
  logCorreo: "email_log",
} as const;

export type Tabla = (typeof TABLAS)[keyof typeof TABLAS];

/** Verifica que el nombre de tabla provenga de la constante y no del usuario. */
export function tablaSegura(nombre: string): Tabla {
  const conocida = Object.values(TABLAS).find((t) => t === nombre);
  if (!conocida) {
    throw new Error(`Tabla no reconocida: ${nombre} (solo constantes de código)`);
  }
  return conocida;
}
