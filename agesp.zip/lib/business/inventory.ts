/**
 * Inventario (SDD M5): consultas de productos y alertas de bajo inventario
 * (stock < stock_minimo). Actualización de stock con concurrencia
 * optimista (re-verifica el stock previo en el UPDATE) para ser portable
 * entre Supabase y PostgreSQL local sin depender de SELECT FOR UPDATE.
 */
import type { Producto } from "../types";
import { ErrorNegocio, ErrorNoEncontrado } from "./errores";
import { TABLAS, type Repositorio } from "./repositorio";

export interface FiltrosProducto {
  disponible?: boolean;
  categoria_id?: string;
  destacado?: boolean;
  limite?: number;
}

/** Lista productos con filtros simples (catálogo M2). */
export async function listarProductos(
  repo: Repositorio,
  filtros: FiltrosProducto = {}
): Promise<Producto[]> {
  const eq: Record<string, unknown> = {};
  if (filtros.disponible !== undefined) eq.disponible = filtros.disponible;
  if (filtros.categoria_id) eq.categoria_id = filtros.categoria_id;
  if (filtros.destacado !== undefined) eq.destacado = filtros.destacado;

  return repo.seleccionar<Producto>(TABLAS.productos, {
    ordenarPor: { columna: "creado_en", asc: false },
    limite: filtros.limite,
    eq,
  });
}

export async function obtenerProducto(
  repo: Repositorio,
  productoId: string
): Promise<Producto> {
  const filas = await repo.seleccionar<Producto>(TABLAS.productos, {
    eq: { id: productoId },
    limite: 1,
  });
  if (filas.length === 0) throw new ErrorNoEncontrado("Producto", productoId);
  return filas[0];
}

/** Alertas de bajo inventario: productos con stock < stock_minimo. */
export async function alertasBajoInventario(repo: Repositorio): Promise<Producto[]> {
  const productos = await repo.seleccionar<Producto>(TABLAS.productos);
  return productos.filter((p) => p.stock < p.stock_minimo);
}

export interface ResultadoAjusteStock {
  producto: Producto;
  /** true si tras el ajuste quedó por debajo del mínimo (alerta). */
  requiereAlerta: boolean;
}

/**
 * Ajuste relativo de stock (delta puede ser negativo para venta, positivo
 * para entrada de mercancía). Concurrencia optimista: el UPDATE exige el
 * stock previo leído; si otro usuario modificó la fila se lanza
 * ErrorNegocio para reintentar (sin race condition silenciosa).
 */
export async function ajustarStock(
  repo: Repositorio,
  productoId: string,
  delta: number,
  opciones: { motivo: string; usuarioId?: string | null }
): Promise<ResultadoAjusteStock> {
  if (!Number.isInteger(delta)) {
    throw new ErrorNegocio("El ajuste de stock debe ser un entero");
  }
  return repo.transaccion(async (trx) => {
    const producto = await obtenerProducto(trx, productoId);
    const nuevoStock = producto.stock + delta;
    if (nuevoStock < 0) {
      throw new ErrorNegocio(
        `Stock insuficiente para "${producto.nombre}": disponible ${producto.stock}, requerido ${Math.abs(delta)}`
      );
    }
    const filas = await trx.actualizar<Producto>(
      TABLAS.productos,
      { stock: nuevoStock, actualizado_en: new Date().toISOString() },
      { id: productoId, stock: producto.stock } // guard optimista
    );
    if (filas.length === 0) {
      throw new ErrorNegocio(
        `El stock de "${producto.nombre}" cambió durante la operación; reintente`
      );
    }
    const actualizado = filas[0];
    if (opciones.usuarioId) {
      // Auditoría best-effort fuera del flujo crítico de stock (D7).
      const auditoria = await import("./audit");
      await auditoria
        .registrarAccion(trx, {
          user_id: opciones.usuarioId,
          accion: "ajuste_stock",
          entidad: TABLAS.productos,
          entidad_id: productoId,
          detalle: { delta, motivo: opciones.motivo, nuevo_stock: nuevoStock },
        })
        .catch(() => undefined);
    }
    return {
      producto: actualizado,
      requiereAlerta: actualizado.stock < actualizado.stock_minimo,
    };
  });
}
