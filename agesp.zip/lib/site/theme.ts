/**
 * Aplicación de temas desde `site_config` (SDD §2 — regla dura:
 * no hardcodear colores). Devuelve atributos/estilos listos para el <html>.
 * FALLBACK: la paleta diplomática por defecto (ver globals.css).
 */
export interface PaletaSitio {
  primary: string; // hex, p. ej. #0B2E59
  accent: string; // #F4C430
  secondary: string; // #4A5568
  muted: string; // #E2E8F0
  surface: string; // #FFFFFF
}

export const PALETA_DEFECTO: PaletaSitio = {
  primary: "#0B2E59",
  accent: "#F4C430",
  secondary: "#4A5568",
  muted: "#E2E8F0",
  surface: "#FFFFFF",
};

/** Convierte #RRGGBB a "R G B" para las variables CSS de Tailwind. */
export function hexACanales(hex: string): string {
  const limpio = hex.replace("#", "");
  const full = limpio.length === 3 ? limpio.split("").map((c) => c + c).join("") : limpio;
  const n = parseInt(full || "000000", 16);
  const r = (n >> 16) & 255;
  const g = (n >> 8) & 255;
  const b = n & 255;
  return `${r} ${g} ${b}`;
}

export function applySiteConfig(paleta: Partial<PaletaSitio>): string {
  const p = { ...PALETA_DEFECTO, ...paleta };
  return [
    `--color-primary:${hexACanales(p.primary)}`,
    `--color-accent:${hexACanales(p.accent)}`,
    `--color-secondary:${hexACanales(p.secondary)}`,
    `--color-muted:${hexACanales(p.muted)}`,
    `--color-surface:${hexACanales(p.surface)}`,
  ].join(";");
}
