/**
 * Autenticación local con JWT propio (D11: sin Supabase Auth en el target
 * local). Firma HS256 con JOSE; el payload { sub } es el id del perfil
 * y se fija en `app.user_id` para las RLS locales.
 * Uso: middleware `deAutenticacion` y helper `requiereRol([...])`.
 */
import { SignJWT, jwtVerify } from "jose";
import type { NextFunction, Request, Response } from "express";
import { ErrorNoAutorizado, ErrorPermisos } from "../../lib/business/errores";
import { errorAJSON } from "../../lib/business/errores";
import type { Rol } from "../../lib/types";

const secreto = new TextEncoder().encode(
  process.env.JWT_SECRET ?? "AGESP-secreto-DESARROLLO-cambiar-en-produccion"
);

/** Emite un token de sesión local (habitualmente desde el login admin). */
export async function firmarToken(usuarioId: string, rol: Rol): Promise<string> {
  return new SignJWT({ rol })
    .setProtectedHeader({ alg: "HS256" })
    .setSubject(usuarioId)
    .setIssuedAt()
    .setExpirationTime("8h")
    .sign(secreto);
}

export interface SesionLocal {
  usuarioId: string;
  rol: Rol;
}

export async function verificarToken(token: string): Promise<SesionLocal> {
  const { payload } = await jwtVerify(token, secreto);
  if (!payload.sub || typeof payload.rol !== "string") {
    throw new ErrorNoAutorizado("Token sin identidad válida");
  }
  return { usuarioId: payload.sub, rol: payload.rol as Rol };
}

declare module "express-serve-static-core" {
  interface Request {
    sesion?: SesionLocal;
  }
}

/** Middleware: guarda req.sesion si hay Bearer token válido (puede ser anónimo). */
export async function deAutenticacion(
  req: Request,
  _res: Response,
  next: NextFunction
): Promise<void> {
  try {
    const token = req.headers.authorization?.replace(/^Bearer\s+/i, "");
    if (token) req.sesion = await verificarToken(token);
    next();
  } catch (e) {
    const { estado, cuerpo } = errorAJSON(e);
    res.status(estado).json(cuerpo);
  }
}

/** Exige identidad y rol; si no, responde 401/403 (no avanza). */
export function requiereRol(permitidos: Rol[]) {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.sesion) {
      res.status(401).json({ error: ErrorNoAutorizado.message });
      return;
    }
    if (!permitidos.includes(req.sesion.rol)) {
      res.status(403).json({
        error: `Requiere uno de estos roles: ${permitidos.join(", ")}`,
      });
      return;
    }
    next();
  };
}
