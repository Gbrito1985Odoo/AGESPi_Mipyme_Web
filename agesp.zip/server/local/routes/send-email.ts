/**
 * Rutas de correo (M3/M5): envío con plantilla + registro en email_log.
 * Paridad con send-email (Deno). Solo staff; sin RESEND_API_KEY registra
 * «error» y responde 200 con la fila del log (comportamiento idéntico al Edge).
 */
import { Router } from "express";
import { enviarCorreo } from "../../lib/business/email";
import { crearRepositorioLocal } from "./repositorioLocal";
import { errorAJSON, ErrorPermisos } from "../../lib/business/errores";
import { limiteCorreo } from "../rateLimit";
import { requiereRol, deAutenticacion } from "../autenticacion";

const router = Router();

/** POST /send-email — { plantilla, destinatario, variables }. */
router.post("/", deAutenticacion, requiereRol(["admin", "super_admin", "editor"]), limiteCorreo, async (req: any, res: any) => {
  try {
    const repo = crearRepositorioLocal({ usuarioId: req.sesion?.usuarioId });
    const registro = await enviarCorreo(repo, {
      plantilla: req.body?.plantilla,
      destinatario: req.body?.destinatario,
      variables: req.body?.variables ?? {},
    });
    // registrar quien lo disparó (best-effort); la escritura del email_log la hace email.ts
    res.json({ registro });
  } catch (e) {
    const { estado, cuerpo } = errorAJSON(e);
    res.status(estado).json(cuerpo);
  }
});

void ErrorPermisos; // el 403 lo decide requiereRol(); aquí no lanzamos para paridad

export default router;
