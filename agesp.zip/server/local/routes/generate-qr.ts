/**
 * Rutas de QR (M3): generar (público) y regenerar (admin/super_admin).
 * Paridad con generate-qr / regenerate-qr (Deno).
 */
import { Router } from "express";
import { generarQRTarjeta } from "../../lib/business/qr";
import { crearRepositorioLocal } from "./repositorioLocal";
import { TABLAS } from "../../lib/business/repositorio";
import type { Customer } from "../../lib/types";
import { errorAJSON, ErrorNoEncontrado } from "../../lib/business/errores";
import { limiteQR } from "../rateLimit";
import { requiereRol, deAutenticacion } from "../autenticacion";

const router = Router();

/** POST /generate-qr — { base_url, uuid | customer_id }. Público (rate). */
router.post("/", limiteQR, async (req: any, res: any) => {
  try {
    let uuid: string | undefined = req.body?.uuid;
    const baseUrl: string = req.body?.base_url ?? `${req.protocol}://${req.get("host")}`;

    // Si llega customer_id, resolvemos el uuid público de la tarjeta.
    if (!uuid && typeof req.body?.customer_id === "string") {
      const repo = crearRepositorioLocal();
      const filas = await repo.seleccionar<Customer>(TABLAS.clientes, {
        eq: { id: req.body.customer_id },
        limite: 1,
      });
      if (filas.length === 0) throw new ErrorNoEncontrado("Cliente", req.body.customer_id);
      uuid = filas[0].uuid;
    }
    const qr = await generarQRTarjeta({ base_url: baseUrl, uuid });
    res.json(qr);
  } catch (e) {
    const { estado, cuerpo } = errorAJSON(e);
    res.status(estado).json(cuerpo);
  }
});

/** POST /regenerate-qr — { uuid } con rol admin|super_admin. */
router.post("/regenerar", deAutenticacion, requiereRol(["admin", "super_admin"]), async (req: any, res: any) => {
  try {
    const baseUrl: string = req.body?.base_url ?? `${req.protocol}://${req.get("host")}`;
    const qr = await generarQRTarjeta({ base_url: baseUrl, uuid: req.body?.uuid });
    // Auditoría best-effort (D7).
    const repo = crearRepositorioLocal({ usuarioId: req.sesion?.usuarioId });
    const { registrarAccion } = await import("../../lib/business/audit");
    await registrarAccion(repo, {
      user_id: req.sesion?.usuarioId ?? null,
      accion: "regenerate_qr",
      entidad: TABLAS.clientes,
      entidad_id: req.body?.uuid ?? null,
      detalle: null,
    }).catch(() => undefined);

    res.json(qr);
  } catch (e) {
    const { estado, cuerpo } = errorAJSON(e);
    res.status(estado).json(cuerpo);
  }
});

export default router;
