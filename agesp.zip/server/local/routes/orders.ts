/**
 * Rutas de pedidos (M2/M5): crear desde carrito, listar, cambiar estado.
 * Paridad con supabase (D2): el frontend llama al mismo contrato de /lib/business.
 */
import { Router } from "express";
import { z } from "zod";
import {
  crearPedidoDesdeCarrito,
  listarPedidos,
  cambiarEstadoPedido,
  obtenerPedido,
  itemsDePedido,
} from "../../lib/business/orders";
import { ENTRADA_ITEM_SCHEMA, type Carrito } from "../../lib/business/cart";
import { crearRepositorioLocal } from "./repositorioLocal";
import { errorAJSON } from "../../lib/business/errores";

const router = Router();

function sesion(req: {
  sesion?: { usuarioId: string; rol: string };
}): string | null {
  return req.sesion?.usuarioId ?? null;
}

/** POST /orders — crea pedido desde carrito (req.body Carrito). */
router.post("/", async (req: any, res: any) => {
  try {
    const repo = crearRepositorioLocal({ usuarioId: sesion(req) ?? undefined });
    const resultado = await crearPedidoDesdeCarrito(
      repo,
      req.body as Carrito,
      { usuario_id: sesion(req) }
    );
    res.status(201).json(resultado);
  } catch (e) {
    const { estado, cuerpo } = errorAJSON(e);
    res.status(estado).json(cuerpo);
  }
});

/** GET /orders — lista con filtros ?customer_id=&estado=&limite=. */
router.get("/", async (req: any, res: any) => {
  try {
    const repo = crearRepositorioLocal({ usuarioId: sesion(req) ?? undefined });
    const pedidos = await listarPedidos(repo, {
      customer_id: typeof req.query.customer_id === "string" ? req.query.customer_id : undefined,
      estado: typeof req.query.estado === "string" ? req.query.estado as any : undefined,
      limite: req.query.limite ? Number(req.query.limite) : undefined,
    });
    res.json({ pedidos });
  } catch (e) {
    const { estado, cuerpo } = errorAJSON(e);
    res.status(estado).json(cuerpo);
  }
});

/** GET /orders/:id — pedidos + items snapshot con estado actual. */
router.get("/:id", async (req: any, res: any) => {
  try {
    const repo = crearRepositorioLocal({ usuarioId: sesion(req) ?? undefined });
    const [pedido, items] = await Promise.all([
      obtenerPedido(repo, req.params.id),
      itemsDePedido(repo, req.params.id),
    ]);
    res.json({ pedido, items });
  } catch (e) {
    const { estado, cuerpo } = errorAJSON(e);
    res.status(estado).json(cuerpo);
  }
});

/** POST /orders/:id/estado — cambia estado { nuevoEstado }; descuenta/devuelve stock. */
router.post("/:id/estado", async (req: any, res: any) => {
  try {
    const repo = crearRepositorioLocal({ usuarioId: sesion(req) ?? undefined });
    const resultado = await cambiarEstadoPedido(
      repo,
      req.params.id,
      req.body?.nuevoEstado,
      { usuarioId: sesion(req) }
    );
    res.json(resultado);
  } catch (e) {
    const { estado, cuerpo } = errorAJSON(e);
    res.status(estado).json(cuerpo);
  }
});

export default router;
void z;
void ENTRADA_ITEM_SCHEMA;
