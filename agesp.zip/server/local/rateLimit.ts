/**
 * Rate limit de Express (§7). Paridad con las funciones Deno
 * (LIMITES_SUGERIDOS en supabase/functions/_shared/rateLimit.ts): mismos
 *Conceptos (30/QR, 10/correo, 5/export, 30/analytics por minuto).
 */
import rateLimit from "express-rate-limit";

const MINUTO_MS = 60_000;

export const limiteQR = rateLimit({ windowMs: MINUTO_MS, limit: 30 });
export const limiteCorreo = rateLimit({ windowMs: MINUTO_MS, limit: 10 });
export const limiteExport = rateLimit({ windowMs: MINUTO_MS, limit: 5 });
export const limiteAnalytics = rateLimit({ windowMs: MINUTO_MS, limit: 30 });
export const limiteGlobal = rateLimit({
  windowMs: MINUTO_MS,
  limit: 120,
  message: { error: "Demasiadas peticiones; espere un minuto" },
});
