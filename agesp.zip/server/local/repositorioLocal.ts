/**
 * Adaptador PostgreSQL local → Repositorio (capa business) para Express.
 * Cada consulta fija `app.user_id` con set_config(..., true) (identidad
 * emulada por JWT propio, paridad con supabase según D11) para que las
 * políticas RLS de la BD local usen current_user_id().
 * Seguridad: solo se aceptan tablas/columnas que casen con ^[a-z_]+$ y
 * provienen de constantes del código (TABLAS), nunca del usuario.
 */
import type { PoolClient } from "pg";
import { getPool } from "../../lib/db/localClient";
import type { Repositorio, FiltrosSeleccionar } from "../../lib/business/repositorio";

function identificableSQL(nombre: string, tipo: string): string {
  if (!/^[a-z_]+$/.test(nombre)) {
    throw new Error(`Nombre de ${tipo} inválido: ${nombre}`);
  }
  return `"${nombre}"`;
}

const tablaSeguraSQL = (t: string) => identificableSQL(t, "tabla");
const columnaSeguraSQL = (c: string) => identificableSQL(c, "columna");

/** pg acepta strings; convertimos "true"/"false" a boolean cuando aplique. */
function valorPg(v: unknown): unknown {
  if (typeof v === "string" && /^(true|false)$/i.test(v.trim())) {
    return v.trim().toLowerCase() === "true";
  }
  return v;
}

export interface RepositorioLocalOpciones {
  /** Usuario autenticado de la petición (undefined = anónimo). */
  usuarioId?: string | null;
}

/* ---------- Construcción de SQL (segura) ---------- */

interface SelectSQL {
  conOrden: boolean;
}

function construirSelect(tabla: string, opts?: FiltrosSeleccionar): string {
  void ({} as SelectSQL); // documentado: WHERE siempre por eq; sin orden sin ack
  let sql = `SELECT * FROM ${tablaSeguraSQL(tabla)}`;
  const params = Object.values(opts?.eq ?? {}).map(valorPg);
  if (opts?.eq && Object.keys(opts.eq).length > 0) {
    const conds = Object.keys(opts.eq).map((col, i) => `${columnaSeguraSQL(col)} = $${i + 1}`);
    sql += ` WHERE ${conds.join(" AND ")}`;
  }
  if (opts?.ordenarPor) {
    const dir = opts.ordenarPor.asc !== false ? "ASC" : "DESC";
    sql += ` ORDER BY ${columnaSeguraSQL(opts.ordenarPor.columna)} ${dir}`;
  }
  if (opts?.limite) sql += ` LIMIT ${Math.max(1, Math.floor(opts.limite))}`;
  return `${sql};`;
}

function construirUpdate(
  tabla: string,
  valores: Record<string, unknown>,
  eq: Record<string, unknown>
): { sql: string; params: unknown[] } {
  const params: unknown[] = [];
  const sets = Object.entries(valores).map(([col, val]) => {
    params.push(val);
    return `${columnaSeguraSQL(col)} = $${params.length}`;
  });
  const conds = Object.entries(eq).map(([col, val]) => {
    params.push(valorPg(val));
    return `${columnaSeguraSQL(col)} = $${params.length}`;
  });
  const sql = `UPDATE ${tablaSeguraSQL(tabla)} SET ${sets.join(", ")} WHERE ${conds.join(" AND ")} RETURNING *;`;
  return { sql, params };
}

async function fijarContexto(client: PoolClient, usuarioId?: string | null): Promise<void> {
  if (usuarioId) {
    await client.query("SELECT set_config('app.user_id', $1, true)", [usuarioId]);
  }
}

async function insertarFila<T>(
  client: PoolClient,
  tabla: string,
  fila: Record<string, unknown>
): Promise<T> {
  const cols = Object.keys(fila).map(columnaSeguraSQL);
  const refs = cols.map((_, i) => `$${i + 1}`);
  const sql = `INSERT INTO ${tablaSeguraSQL(tabla)} (${cols.join(", ")}) VALUES (${refs.join(", ")}) RETURNING *;`;
  const result = await client.query(sql, Object.values(fila));
  return result.rows[0] as T;
}

/* ---------- Repositorio con transacción real (BEGIN/COMMIT) ---------- */

export function crearRepositorioLocal(opciones: RepositorioLocalOpciones = {}): Repositorio {
  const repo: Repositorio = {
    target: "local",
    async seleccionar<T>(tabla: string, opts?: FiltrosSeleccionar): Promise<T[]> {
      const client = await getPool().connect();
      try {
        await fijarContexto(client, opciones.usuarioId);
        const sql = construirSelect(tabla, opts);
        const params = opts?.eq ? Object.values(opts.eq).map(valorPg) : [];
        const result = await client.query(sql, params);
        return result.rows as T[];
      } finally {
        client.release();
      }
    },
    async insertar<T>(tabla: string, fila: Record<string, unknown>): Promise<T> {
      const client = await getPool().connect();
      try {
        await fijarContexto(client, opciones.usuarioId);
        return await insertarFila<T>(client, tabla, fila);
      } finally {
        client.release();
      }
    },
    async actualizar<T>(
      tabla: string,
      valores: Record<string, unknown>,
      eq: Record<string, unknown>
    ): Promise<T[]> {
      const client = await getPool().connect();
      try {
        await fijarContexto(client, opciones.usuarioId);
        const { sql, params } = construirUpdate(tabla, valores, eq);
        const result = await client.query(sql, params);
        return result.rows as T[];
      } finally {
        client.release();
      }
    },
    async transaccion<T>(fn: (trx: Repositorio) => Promise<T>): Promise<T> {
      const client = await getPool().connect();
      try {
        await client.query("BEGIN");
        // Repositorio sobre el mismo PoolClient: atomicidad real.
        const trx = repositorioSobreClient(client);
        const resultado = await fn(trx);
        await client.query("COMMIT");
        return resultado;
      } catch (e) {
        await client.query("ROLLBACK").catch(() => undefined);
        throw e;
      } finally {
        client.release();
      }
    },
  };
  return repo;
}

/** Repositorio sobre un PoolClient ya dentro de una transacción. */
function repositorioSobreClient(client: PoolClient): Repositorio {
  const repo: Repositorio = {
    target: "local (transacción)",
    async seleccionar<T>(tabla: string, opts?: FiltrosSeleccionar): Promise<T[]> {
      const sql = construirSelect(tabla, opts);
      const params = opts?.eq ? Object.values(opts.eq).map(valorPg) : [];
      const result = await client.query(sql, params);
      return result.rows as T[];
    },
    async insertar<T>(tabla: string, fila: Record<string, unknown>): Promise<T> {
      return insertarFila<T>(client, tabla, fila);
    },
    async actualizar<T>(
      tabla: string,
      valores: Record<string, unknown>,
      eq: Record<string, unknown>
    ): Promise<T[]> {
      const { sql, params } = construirUpdate(tabla, valores, eq);
      const result = await client.query(sql, params);
      return result.rows as T[];
    },
    // Ya estamos dentro de una transacción: no se reabre BEGIN.
    async transaccion<T>(fn: (trx: Repositorio) => Promise<T>): Promise<T> {
      return fn(repo);
    },
  };
  return repo;
}
