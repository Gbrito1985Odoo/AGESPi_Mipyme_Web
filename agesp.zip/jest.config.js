/**
 * Configuración de Jest con ts-jest (brief AGENTE-2 §5).
 * Pruebas unitarias de /lib/business con repositorios en memoria
 * (sin red ni PostgreSQL). Ejecutar: `npm run test`.
 */
/** @type {import('jest').Config} */
module.exports = {
  preset: "ts-jest",
  testEnvironment: "node",
  roots: ["<rootDir>/tests"],
  testMatch: ["**/*.test.ts"],
  moduleFileExtensions: ["ts", "js", "json"],
  clearMocks: true,
  verbose: true,
  errorOnDeprecated: false,
  reporters: ["default"],
  transform: {
    "^.+\\.tsx?$": ["ts-jest", { tsconfig: { module: "commonjs", esModuleInterop: true } }],
  },
};
