/**
 * db:local:init — aplica el esquema contra DATABASE_URL (SDD §3.4).
 * Orden: migraciones versionadas (fuente de verdad, D10) → RLS → seed.
 * Uso: npm run db:local:init
 */
const fs = require("node:fs");
const path = require("node:path");
const { Client } = require("pg");

const ROOT = path.resolve(__dirname, "..");

async function aplicar(client, archivo, carpeta) {
  const sql = fs.readFileSync(archivo, "utf8");
  try {
    await client.query(sql);
    console.log(`[db:local:init] OK ${carpeta}/${path.basename(archivo)}`);
  } catch (err) {
    console.error(`[db:local:init] Error en ${archivo}: ${err.message}`);
    process.exitCode = 1;
  }
}

async function main() {
  const url = process.env.DATABASE_URL;
  if (!url) {
    console.error("[db:local:init] Falta DATABASE_URL en el entorno (.env.local).");
    process.exit(1);
  }
  const client = new Client({ connectionString: url });
  await client.connect();
  console.log("[db:local:init] Conectado a la base de datos local.");

  const carpetas = [
    { dir: path.join(ROOT, "db", "migrations"), sufijo: ".sql" },
    { dir: path.join(ROOT, "db", "rls"), sufijo: ".sql" },
    { dir: path.join(ROOT, "db"), archivo: "seed.sql" },
  ];

  for (const c of carpetas) {
    if (c.archivo) {
      await aplicar(client, path.join(c.dir ?? c.dir, c.archivo), path.basename(c.dir));
      continue;
    }
    const archivos = fs
      .readdirSync(c.dir)
      .filter((f) => f.endsWith(c.sufijo))
      .sort();
    for (const f of archivos) await aplicar(client, path.join(c.dir, f), "migraciones/rls");
  }

  await client.end();
  console.log(process.exitCode === 1 ? "[db:local:init] Terminó con errores." : "[db:local:init] List.");
}

main().catch((e) => {
  console.error("[db:local:init] " + e.message);
  process.exit(1);
});
